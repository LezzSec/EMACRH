# -*- coding: utf-8 -*-
"""
TEST COMPLET DE L'APPLICATION EMAC
Teste toutes les fonctionnalites principales
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from datetime import date, datetime, timedelta
from core.db.configbd import DatabaseConnection, DatabaseCursor, get_connection

# Compteurs globaux
TESTS_PASSED = 0
TESTS_FAILED = 0
TESTS_SKIPPED = 0


def header(title):
    print()
    print("=" * 70)
    print(f" {title}")
    print("=" * 70)


def test(name, condition, details=""):
    global TESTS_PASSED, TESTS_FAILED
    if condition:
        TESTS_PASSED += 1
        print(f"  [OK] {name}")
    else:
        TESTS_FAILED += 1
        print(f"  [FAIL] {name}")
        if details:
            print(f"        -> {details}")


def skip(name, reason=""):
    global TESTS_SKIPPED
    TESTS_SKIPPED += 1
    print(f"  [SKIP] {name} - {reason}")


# ============================================================
# 1. CONNEXION BASE DE DONNEES
# ============================================================
def test_database():
    header("1. CONNEXION BASE DE DONNEES")

    # Test connexion
    try:
        conn = get_connection()
        test("Connexion MySQL", conn is not None)
        conn.close()
    except Exception as e:
        test("Connexion MySQL", False, str(e))
        return False

    # Test DatabaseCursor context manager
    try:
        with DatabaseCursor(dictionary=True) as cur:
            cur.execute("SELECT 1 as test")
            result = cur.fetchone()
        test("DatabaseCursor context manager", result['test'] == 1)
    except Exception as e:
        test("DatabaseCursor context manager", False, str(e))

    # Test DatabaseConnection context manager
    try:
        with DatabaseConnection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT VERSION()")
            version = cur.fetchone()[0]
        test("DatabaseConnection context manager", "8." in version or "5." in version)
    except Exception as e:
        test("DatabaseConnection context manager", False, str(e))

    return True


# ============================================================
# 2. PERSONNEL / OPERATEURS
# ============================================================
def test_personnel():
    header("2. PERSONNEL / OPERATEURS")

    try:
        from core.services.rh_service import (
            rechercher_operateurs,
            get_operateur_by_id
        )

        # Recherche operateurs
        operateurs = rechercher_operateurs("")
        test("Recherche tous operateurs", len(operateurs) > 0, f"Trouve: {len(operateurs)}")

        # Recherche avec filtre
        operateurs_filtre = rechercher_operateurs("Thomas")
        test("Recherche avec filtre 'Thomas'", isinstance(operateurs_filtre, list))

        # Get operateur by ID
        op = get_operateur_by_id(412)
        if op:
            test("Get operateur by ID (412)", op['id'] == 412)
            test("Operateur a nom/prenom", 'nom' in op and 'prenom' in op)
        else:
            skip("Get operateur by ID (412)", "Operateur non trouve")

    except Exception as e:
        test("Module personnel", False, str(e))


# ============================================================
# 3. EVALUATIONS
# ============================================================
def test_evaluations():
    header("3. EVALUATIONS")

    try:
        from core.services.evaluation_service import (
            get_evaluations_en_retard,
            get_evaluations_a_planifier
        )

        # Evaluations en retard
        retards = get_evaluations_en_retard()
        test("Get evaluations en retard", isinstance(retards, list))
        print(f"        -> {len(retards)} evaluation(s) en retard")

        # Evaluations a planifier
        a_planifier = get_evaluations_a_planifier(30)
        test("Get evaluations a planifier (30j)", isinstance(a_planifier, list))
        print(f"        -> {len(a_planifier)} evaluation(s) a planifier")

    except Exception as e:
        test("Module evaluations", False, str(e))


# ============================================================
# 4. POLYVALENCE
# ============================================================
def test_polyvalence():
    header("4. POLYVALENCE")

    try:
        with DatabaseCursor(dictionary=True) as cur:
            # Compter polyvalences
            cur.execute("SELECT COUNT(*) as count FROM polyvalence")
            count = cur.fetchone()['count']
            test("Table polyvalence accessible", count >= 0)
            print(f"        -> {count} enregistrement(s)")

            # Verifier structure
            cur.execute("DESCRIBE polyvalence")
            columns = [row['Field'] for row in cur.fetchall()]
            test("Colonnes polyvalence", 'niveau' in columns and 'operateur_id' in columns)

    except Exception as e:
        test("Module polyvalence", False, str(e))


# ============================================================
# 5. DOCUMENTS
# ============================================================
def test_documents():
    header("5. DOCUMENTS")

    try:
        from core.services.document_service import DocumentService
        from core.services.rh_service import get_documents_archives_operateur

        doc_service = DocumentService()

        # Test methodes existent
        test("DocumentService.archive_document existe", hasattr(doc_service, 'archive_document'))
        test("DocumentService.restore_document existe", hasattr(doc_service, 'restore_document'))
        test("DocumentService.get_document_path existe", hasattr(doc_service, 'get_document_path'))

        # Test get archives
        archives = get_documents_archives_operateur(412)
        test("get_documents_archives_operateur", isinstance(archives, list))
        print(f"        -> {len(archives)} archive(s) pour operateur 412")

        # Test categories
        categories = doc_service.get_categories()
        test("get_categories", len(categories) > 0)
        print(f"        -> {len(categories)} categorie(s)")

    except Exception as e:
        test("Module documents", False, str(e))


# ============================================================
# 6. FORMATIONS
# ============================================================
def test_formations():
    header("6. FORMATIONS")

    try:
        from core.services.formation_service import (
            get_all_formations,
            get_formations_personnel
        )

        # Get all formations
        formations = get_all_formations()
        test("get_all_formations", isinstance(formations, list))
        print(f"        -> {len(formations)} formation(s)")

        # Get formations operateur
        formations_op = get_formations_personnel(412)
        test("get_formations_personnel(412)", isinstance(formations_op, list))
        print(f"        -> {len(formations_op)} formation(s) pour operateur 412")

    except Exception as e:
        test("Module formations", False, str(e))


# ============================================================
# 7. CONTRATS
# ============================================================
def test_contrats():
    header("7. CONTRATS")

    try:
        from core.services.contrat_service import (
            get_contrats_expirant,
            get_contrat_actif
        )

        # Contrats expirant
        expirant = get_contrats_expirant(30)
        test("get_contrats_expirant(30)", isinstance(expirant, list))
        print(f"        -> {len(expirant)} contrat(s) expirant dans 30j")

        # Contrat actif operateur
        contrat = get_contrat_actif(412)
        test("get_contrat_actif(412)", contrat is None or isinstance(contrat, dict))

    except Exception as e:
        test("Module contrats", False, str(e))


# ============================================================
# 8. ABSENCES
# ============================================================
def test_absences():
    header("8. ABSENCES")

    try:
        from core.services.absence_service import get_absences_periode

        # Absences du mois
        debut = date.today().replace(day=1)
        fin = date.today()
        absences = get_absences_periode(debut, fin)
        test("get_absences_periode", isinstance(absences, list))
        print(f"        -> {len(absences)} absence(s) ce mois")

    except ImportError:
        skip("Module absences", "Module non disponible")
    except Exception as e:
        test("Module absences", False, str(e))


# ============================================================
# 9. PERMISSIONS / FEATURES
# ============================================================
def test_permissions():
    header("9. PERMISSIONS / FEATURES")

    try:
        from core.services.permission_manager import perm, can

        # Test can function
        test("Fonction can() disponible", callable(can))

        # Test features table
        with DatabaseCursor(dictionary=True) as cur:
            cur.execute("SELECT COUNT(*) as count FROM features")
            count = cur.fetchone()['count']
            test("Table features", count > 0)
            print(f"        -> {count} feature(s) definies")

            # Verifier features formations
            cur.execute("SELECT * FROM features WHERE key_code LIKE 'rh.formations%'")
            formations_features = cur.fetchall()
            test("Features formations existent", len(formations_features) >= 3)

            # Verifier role_features
            cur.execute("SELECT COUNT(*) as count FROM role_features")
            rf_count = cur.fetchone()['count']
            test("Table role_features", rf_count > 0)
            print(f"        -> {rf_count} attribution(s) role-feature")

    except Exception as e:
        test("Module permissions", False, str(e))


# ============================================================
# 10. DOMAINES RH
# ============================================================
def test_domaines_rh():
    header("10. DOMAINES RH")

    try:
        from core.services.rh_service import (
            get_domaines_rh,
            get_donnees_domaine,
            get_documents_domaine,
            DomaineRH
        )

        # Get domaines
        domaines = get_domaines_rh()
        test("get_domaines_rh", len(domaines) >= 6)
        print(f"        -> Domaines: {[d['nom'] for d in domaines]}")

        # Test chaque domaine pour operateur 412
        for domaine in domaines[:3]:  # Test 3 premiers
            code = DomaineRH(domaine['code'])
            donnees = get_donnees_domaine(412, code)
            test(f"get_donnees_domaine({domaine['nom']})", isinstance(donnees, dict))

    except Exception as e:
        test("Module domaines RH", False, str(e))


# ============================================================
# 11. MEDICAL
# ============================================================
def test_medical():
    header("11. MEDICAL")

    try:
        from core.services.medical_service import (
            get_visites,
            get_accidents,
            get_alertes_medicales
        )

        # Visites
        visites = get_visites(412)
        test("get_visites(412)", isinstance(visites, list))

        # Accidents
        accidents = get_accidents(412)
        test("get_accidents(412)", isinstance(accidents, list))

        # Alertes
        alertes = get_alertes_medicales(412)
        test("get_alertes_medicales(412)", isinstance(alertes, list))

    except ImportError:
        skip("Module medical", "Module non disponible")
    except Exception as e:
        test("Module medical", False, str(e))


# ============================================================
# 12. VIE SALARIE
# ============================================================
def test_vie_salarie():
    header("12. VIE SALARIE")

    try:
        from core.services.vie_salarie_service import (
            get_sanctions,
            get_entretiens,
            get_controles_alcool
        )

        # Sanctions
        sanctions = get_sanctions(412)
        test("get_sanctions(412)", isinstance(sanctions, list))

        # Entretiens
        entretiens = get_entretiens(412)
        test("get_entretiens(412)", isinstance(entretiens, list))

        # Controles alcool
        controles = get_controles_alcool(412)
        test("get_controles_alcool(412)", isinstance(controles, list))

    except ImportError:
        skip("Module vie salarie", "Module non disponible")
    except Exception as e:
        test("Module vie salarie", False, str(e))


# ============================================================
# 13. COMPETENCES TRANSVERSALES
# ============================================================
def test_competences():
    header("13. COMPETENCES TRANSVERSALES")

    try:
        from core.services.rh_service import get_catalogue_competences

        competences = get_catalogue_competences()
        test("get_catalogue_competences", isinstance(competences, list))
        print(f"        -> {len(competences)} competence(s) au catalogue")

    except Exception as e:
        test("Module competences", False, str(e))


# ============================================================
# 14. POSTES ET ATELIERS
# ============================================================
def test_postes():
    header("14. POSTES ET ATELIERS")

    try:
        with DatabaseCursor(dictionary=True) as cur:
            # Postes
            cur.execute("SELECT COUNT(*) as count FROM postes")
            postes_count = cur.fetchone()['count']
            test("Table postes", postes_count >= 0)
            print(f"        -> {postes_count} poste(s)")

            # Ateliers
            cur.execute("SELECT COUNT(*) as count FROM atelier")
            ateliers_count = cur.fetchone()['count']
            test("Table atelier", ateliers_count >= 0)
            print(f"        -> {ateliers_count} atelier(s)")

    except Exception as e:
        test("Module postes/ateliers", False, str(e))


# ============================================================
# 15. HISTORIQUE / AUDIT
# ============================================================
def test_historique():
    header("15. HISTORIQUE / AUDIT")

    try:
        with DatabaseCursor(dictionary=True) as cur:
            cur.execute("SELECT COUNT(*) as count FROM historique")
            count = cur.fetchone()['count']
            test("Table historique", count >= 0)
            print(f"        -> {count} entree(s) dans l'historique")

            # Verifier colonnes
            cur.execute("DESCRIBE historique")
            columns = [row['Field'] for row in cur.fetchall()]
            test("Colonnes historique", 'action' in columns)

    except Exception as e:
        test("Module historique", False, str(e))


# ============================================================
# 16. UTILISATEURS ET ROLES
# ============================================================
def test_utilisateurs():
    header("16. UTILISATEURS ET ROLES")

    try:
        with DatabaseCursor(dictionary=True) as cur:
            # Utilisateurs
            cur.execute("SELECT COUNT(*) as count FROM utilisateurs")
            users_count = cur.fetchone()['count']
            test("Table utilisateurs", users_count > 0)
            print(f"        -> {users_count} utilisateur(s)")

            # Roles
            cur.execute("SELECT id, nom FROM roles ORDER BY id")
            roles = cur.fetchall()
            test("Table roles", len(roles) > 0)
            print(f"        -> Roles: {[r['nom'] for r in roles]}")

    except Exception as e:
        test("Module utilisateurs/roles", False, str(e))


# ============================================================
# 17. IMPORTS GUI (sans affichage)
# ============================================================
def test_gui_imports():
    header("17. IMPORTS GUI")

    modules = [
        ("gestion_rh", "core.gui.gestion_rh"),
        ("gestion_evaluation", "core.gui.gestion_evaluation"),
        ("main_qt", "core.gui.main_qt"),
        ("ui_theme", "core.gui.ui_theme"),
        ("emac_ui_kit", "core.gui.emac_ui_kit"),
    ]

    for name, module_path in modules:
        try:
            __import__(module_path)
            test(f"Import {name}", True)
        except Exception as e:
            test(f"Import {name}", False, str(e)[:50])


# ============================================================
# 18. SERVICES IMPORTS
# ============================================================
def test_services_imports():
    header("18. IMPORTS SERVICES")

    modules = [
        ("rh_service", "core.services.rh_service"),
        ("evaluation_service", "core.services.evaluation_service"),
        ("document_service", "core.services.document_service"),
        ("formation_service", "core.services.formation_service"),
        ("contrat_service", "core.services.contrat_service"),
        ("permission_manager", "core.services.permission_manager"),
        ("logger", "core.services.logger"),
    ]

    for name, module_path in modules:
        try:
            __import__(module_path)
            test(f"Import {name}", True)
        except Exception as e:
            test(f"Import {name}", False, str(e)[:50])


# ============================================================
# MAIN
# ============================================================
def main():
    print()
    print("=" * 70)
    print("   TEST COMPLET APPLICATION EMAC")
    print("   Date:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print("=" * 70)

    # Executer tous les tests
    if not test_database():
        print("\n[FATAL] Connexion base de donnees impossible. Arret des tests.")
        return

    test_personnel()
    test_evaluations()
    test_polyvalence()
    test_documents()
    test_formations()
    test_contrats()
    test_absences()
    test_permissions()
    test_domaines_rh()
    test_medical()
    test_vie_salarie()
    test_competences()
    test_postes()
    test_historique()
    test_utilisateurs()
    test_gui_imports()
    test_services_imports()

    # Resume
    header("RESUME")
    total = TESTS_PASSED + TESTS_FAILED + TESTS_SKIPPED
    print(f"  Tests executes: {total}")
    print(f"  - Reussis:  {TESTS_PASSED}")
    print(f"  - Echoues:  {TESTS_FAILED}")
    print(f"  - Ignores:  {TESTS_SKIPPED}")
    print()

    if TESTS_FAILED == 0:
        print("  >>> TOUS LES TESTS SONT PASSES <<<")
    else:
        print(f"  >>> {TESTS_FAILED} TEST(S) EN ECHEC <<<")

    return TESTS_FAILED == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
