-- ============================================================
-- REQUÊTES SQL POUR CONSULTER LES FORMATIONS
-- À utiliser dans MySQL Workbench, phpMyAdmin, ou autre client SQL
-- ============================================================

-- 1. Voir TOUTES les formations avec les informations des employés
SELECT
    f.id,
    f.operateur_id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    p.statut AS statut_employe,
    f.intitule,
    f.organisme,
    f.date_debut,
    f.date_fin,
    f.duree_heures,
    f.statut,
    f.certificat_obtenu,
    f.commentaire
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
ORDER BY f.id DESC;


-- 2. Formations les plus récentes (10 dernières)
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.date_debut,
    f.statut
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
ORDER BY f.id DESC
LIMIT 10;


-- 3. Formations par statut
SELECT
    f.statut,
    COUNT(*) AS nombre_formations
FROM formation f
GROUP BY f.statut
ORDER BY nombre_formations DESC;


-- 4. Formations pour un employé spécifique (remplacer 'DUPONT' par le nom recherché)
SELECT
    f.id,
    f.intitule,
    f.organisme,
    f.date_debut,
    f.date_fin,
    f.statut,
    f.certificat_obtenu
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
WHERE p.nom LIKE '%DUPONT%'
ORDER BY f.date_debut DESC;


-- 5. Employés ayant suivi au moins une formation
SELECT
    p.id,
    p.nom,
    p.prenom,
    p.statut,
    COUNT(f.id) AS nombre_formations
FROM personnel p
INNER JOIN formation f ON p.id = f.operateur_id
GROUP BY p.id, p.nom, p.prenom, p.statut
ORDER BY nombre_formations DESC;


-- 6. Formations en cours ou planifiées
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.date_debut,
    f.date_fin,
    f.statut
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
WHERE f.statut IN ('Planifiée', 'En cours')
ORDER BY f.date_debut ASC;


-- 7. Formations terminées avec certificat obtenu
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.date_fin,
    f.certificat_obtenu
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
WHERE f.statut = 'Terminée' AND f.certificat_obtenu = 1
ORDER BY f.date_fin DESC;


-- 8. Formations programmées dans les 30 prochains jours
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.date_debut,
    DATEDIFF(f.date_debut, CURDATE()) AS jours_avant_debut
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
WHERE f.date_debut BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY f.date_debut ASC;


-- 9. Statistiques globales
SELECT
    (SELECT COUNT(*) FROM formation) AS total_formations,
    (SELECT COUNT(*) FROM formation WHERE statut = 'Planifiée') AS planifiees,
    (SELECT COUNT(*) FROM formation WHERE statut = 'En cours') AS en_cours,
    (SELECT COUNT(*) FROM formation WHERE statut = 'Terminée') AS terminees,
    (SELECT COUNT(*) FROM formation WHERE statut = 'Annulée') AS annulees,
    (SELECT COUNT(DISTINCT operateur_id) FROM formation) AS employes_formes;


-- 10. Formations par organisme
SELECT
    f.organisme,
    COUNT(*) AS nombre_formations,
    SUM(f.duree_heures) AS total_heures
FROM formation f
WHERE f.organisme IS NOT NULL
GROUP BY f.organisme
ORDER BY nombre_formations DESC;


-- 11. Dernière formation assignée (bulk assignment)
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.date_debut,
    f.statut
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
ORDER BY f.id DESC
LIMIT 1;


-- 12. Toutes les formations d'aujourd'hui (bulk ou manuel)
-- Si vous venez de faire un bulk assignment, elles devraient apparaître ici
SELECT
    f.id,
    CONCAT(p.nom, ' ', p.prenom) AS employe,
    f.intitule,
    f.organisme,
    f.statut
FROM formation f
INNER JOIN personnel p ON f.operateur_id = p.id
-- Filtre par date de création si la colonne existe
-- WHERE DATE(f.created_at) = CURDATE()
ORDER BY f.id DESC;
