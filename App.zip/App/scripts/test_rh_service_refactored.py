# -*- coding: utf-8 -*-
"""
Script de test pour valider rh_service_refactored.py

Tests les fonctions principales refactorisées:
- create_contrat / update_contrat
- create_formation / update_formation
- rechercher_operateurs
- update_infos_generales

Usage:
    cd App
    py -m scripts.test_rh_service_refactored
"""

import sys
from pathlib import Path
from datetime import date, timedelta

# Ajouter le répertoire App au PYTHONPATH
app_dir = Path(__file__).parent.parent
sys.path.insert(0, str(app_dir))

from core.services.rh_service_refactored import (
    create_contrat,
    update_contrat,
    delete_contrat,
    create_formation,
    update_formation,
    delete_formation,
    rechercher_operateurs,
    get_operateur_by_id,
    get_donnees_domaine,
    DomaineRH
)
from core.services.contrat_service_crud import ContratServiceCRUD


def print_section(title: str):
    """Affiche une section avec séparateur."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def test_rechercher_operateurs():
    """Test recherche d'opérateurs."""
    print_section("TEST 1: rechercher_operateurs()")

    try:
        # Test 1: Recherche par statut
        print("\n1. Recherche par statut ACTIF")
        results = rechercher_operateurs(statut='ACTIF')  # ✅ Arguments nommés
        print(f"   ✓ Trouvé {len(results)} opérateurs actifs")

        if results:
            first = results[0]
            print(f"   Premier: {first.get('nom')} {first.get('prenom')} (ID: {first.get('id')})")
            return first.get('id')  # Retourner l'ID pour les tests suivants
        else:
            print("   ⚠️ Aucun opérateur actif trouvé")
            return None

    except Exception as e:
        print(f"   ❌ ERREUR: {e}")
        import traceback
        traceback.print_exc()
        return None


def test_contrat_crud(operateur_id):
    """Test CRUD contrats."""
    print_section("TEST 2: Contrats CRUD")

    if not operateur_id:
        print("   ⚠️ Skipped - pas d'opérateur disponible")
        return None

    try:
        # Test 1: Créer un contrat
        print("\n1. create_contrat() - Créer un nouveau contrat")

        data = {
            'type_contrat': 'CDD',
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=365),
            'actif': 1  # ✅ La table contrat utilise 'actif' (tinyint), pas 'statut'
        }

        success, msg, contract_id = create_contrat(operateur_id, data)

        if success:
            print(f"   ✓ Contrat créé: ID {contract_id}")
            print(f"   Message: {msg}")
        else:
            print(f"   ❌ Échec: {msg}")
            return None

        # Test 2: Récupérer le contrat
        print("\n2. ContratServiceCRUD.get_by_id() - Récupérer le contrat créé")
        contrat = ContratServiceCRUD.get_by_id(contract_id)

        if contrat:
            print(f"   ✓ Contrat récupéré: Type={contrat.get('type_contrat')}")
            print(f"   Date début: {contrat.get('date_debut')}")
            print(f"   Actif: {contrat.get('actif')}")
        else:
            print(f"   ❌ Contrat {contract_id} introuvable")

        # Test 3: Modifier le contrat
        print("\n3. update_contrat() - Modifier le contrat")

        update_data = {
            'actif': 0,  # ✅ Désactiver le contrat (0 = inactif)
            'date_fin': date.today() + timedelta(days=180)
        }

        success, msg = update_contrat(contract_id, update_data)

        if success:
            print(f"   ✓ Contrat modifié")
            print(f"   Message: {msg}")

            # Vérifier modification
            contrat_updated = ContratServiceCRUD.get_by_id(contract_id)
            if contrat_updated:
                print(f"   Nouveau actif: {contrat_updated.get('actif')}")
        else:
            print(f"   ❌ Échec: {msg}")

        print("\n✅ TEST CONTRATS: PASSÉ")
        return contract_id

    except Exception as e:
        print(f"\n❌ TEST CONTRATS: ERREUR - {e}")
        import traceback
        traceback.print_exc()
        return None


def test_formation_crud(operateur_id):
    """Test CRUD formations."""
    print_section("TEST 3: Formations CRUD")

    if not operateur_id:
        print("   ⚠️ Skipped - pas d'opérateur disponible")
        return None

    try:
        # Test 1: Créer une formation
        print("\n1. create_formation() - Créer une nouvelle formation")

        data = {
            'intitule': 'Test Formation Sécurité',
            'organisme': 'AFPA',
            'date_debut': date.today() + timedelta(days=30),
            'date_fin': date.today() + timedelta(days=32),
            'duree_heures': 16.0,
            'statut': 'Planifiée'  # ✅ Enum: 'Planifiée', 'En cours', 'Terminée', 'Annulée'
            # ❌ 'type_formation' n'existe pas dans le schéma
        }

        success, msg, formation_id = create_formation(operateur_id, data)

        if success:
            print(f"   ✓ Formation créée: ID {formation_id}")
            print(f"   Message: {msg}")
        else:
            print(f"   ❌ Échec: {msg}")
            return None

        # Test 2: Modifier la formation
        print("\n2. update_formation() - Modifier la formation")

        update_data = {
            'statut': 'En cours',  # ✅ Enum: 'Planifiée', 'En cours', 'Terminée', 'Annulée'
            'duree_heures': 20.0
        }

        success, msg = update_formation(formation_id, update_data)

        if success:
            print(f"   ✓ Formation modifiée")
            print(f"   Message: {msg}")
        else:
            print(f"   ❌ Échec: {msg}")

        print("\n✅ TEST FORMATIONS: PASSÉ")
        return formation_id

    except Exception as e:
        print(f"\n❌ TEST FORMATIONS: ERREUR - {e}")
        import traceback
        traceback.print_exc()
        return None


def test_get_donnees_domaine(operateur_id):
    """Test récupération des données par domaine."""
    print_section("TEST 4: get_donnees_domaine()")

    if not operateur_id:
        print("   ⚠️ Skipped - pas d'opérateur disponible")
        return

    try:
        # Test 1: Données générales
        print(f"\n1. Récupérer données GENERAL de l'opérateur {operateur_id}")
        data_general = get_donnees_domaine(operateur_id, DomaineRH.GENERAL)

        if data_general.get('personnel'):
            personnel = data_general['personnel']
            print(f"   ✓ Personnel: {personnel.get('nom')} {personnel.get('prenom')}")
            print(f"   Matricule: {personnel.get('matricule')}")
            print(f"   Statut: {personnel.get('statut')}")

        # Test 2: Données contrats
        print(f"\n2. Récupérer données CONTRAT")
        data_contrat = get_donnees_domaine(operateur_id, DomaineRH.CONTRAT)
        contrats = data_contrat.get('contrats', [])
        print(f"   ✓ Contrats: {len(contrats)}")

        # Test 3: Données formations
        print(f"\n3. Récupérer données FORMATION")
        data_formation = get_donnees_domaine(operateur_id, DomaineRH.FORMATION)
        formations = data_formation.get('formations', [])
        print(f"   ✓ Formations: {len(formations)}")

        print("\n✅ TEST GET_DONNEES_DOMAINE: PASSÉ")

    except Exception as e:
        print(f"\n❌ TEST GET_DONNEES_DOMAINE: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_recherche_avancee():
    """Test recherches avancées."""
    print_section("TEST 5: Recherches avancées")

    try:
        # Test 1: Recherche par nom partiel
        print("\n1. Recherche par nom partiel (contient 'A')")
        results = rechercher_operateurs(recherche='A', statut='ACTIF')  # ✅ Corrigé
        print(f"   ✓ Trouvé {len(results)} résultats")

        # Test 2: Recherche par statut uniquement
        print("\n2. Recherche tous les ACTIFS")
        results = rechercher_operateurs(statut='ACTIF')  # ✅ Corrigé
        print(f"   ✓ Trouvé {len(results)} résultats")

        # Test 3: Recherche par terme spécifique
        print("\n3. Recherche par terme 'Jean'")
        results = rechercher_operateurs(recherche='Jean', statut='ACTIF')  # ✅ Corrigé
        print(f"   ✓ Trouvé {len(results)} résultats")

        print("\n✅ TEST RECHERCHES: PASSÉ")

    except Exception as e:
        print(f"\n❌ TEST RECHERCHES: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def main():
    """Exécute tous les tests."""
    print("\n" + "="*60)
    print("  TESTS rh_service_refactored.py (2026-02-09)")
    print("="*60)
    print("\nCe script teste les fonctions refactorisées:")
    print("  - rechercher_operateurs()")
    print("  - create_contrat() / update_contrat()")
    print("  - create_formation() / update_formation()")
    print("  - get_donnees_domaine() (GENERAL, CONTRAT, FORMATION)")

    # Test 1: Rechercher un opérateur
    operateur_id = test_rechercher_operateurs()

    # Test 2: CRUD contrats
    contract_id = test_contrat_crud(operateur_id)

    # Test 3: CRUD formations
    formation_id = test_formation_crud(operateur_id)

    # Test 4: Récupération par domaine
    test_get_donnees_domaine(operateur_id)

    # Test 5: Recherches avancées
    test_recherche_avancee()

    # Résumé
    print("\n" + "="*60)
    print("  RÉSUMÉ")
    print("="*60)
    print("\n✅ Tous les tests ont été exécutés")
    print("\n💡 Si aucune erreur n'est affichée ci-dessus,")
    print("   rh_service_refactored.py fonctionne correctement!")

    print("\n📚 Prochaines étapes:")
    print("  1. Vérifier la table 'historique' pour les logs automatiques")
    print("  2. Migrer les imports dans les fichiers UI:")
    print("     from core.services.rh_service_refactored import ...")
    print("  3. Tester chaque module UI après migration")
    print("  4. Remplacer rh_service.py quand confiant")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
