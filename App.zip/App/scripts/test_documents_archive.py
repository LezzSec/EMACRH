# -*- coding: utf-8 -*-
"""
Script de test: Archivage et restauration de documents
"""

import sys
import os

# Ajouter le répertoire App au path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.db.configbd import DatabaseConnection, DatabaseCursor
from core.services.document_service import DocumentService
from core.services.rh_service import get_documents_domaine, DomaineRH


def print_header(title):
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)


def test_1_structure_table():
    """Vérifie que la table documents a le champ statut."""
    print_header("TEST 1: Structure de la table documents")

    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("DESCRIBE documents")
        columns = {row['Field']: row for row in cur.fetchall()}

        if 'statut' in columns:
            print(f"  [OK] Champ 'statut' existe: {columns['statut']['Type']}")
            return True
        else:
            print("  [ERREUR] Champ 'statut' manquant!")
            return False


def test_2_document_service_methods():
    """Vérifie que les méthodes du service existent."""
    print_header("TEST 2: Méthodes du DocumentService")

    doc_service = DocumentService()

    methods = ['archive_document', 'restore_document', 'get_document_path', 'delete_document']
    all_ok = True

    for method in methods:
        if hasattr(doc_service, method):
            print(f"  [OK] Méthode '{method}' existe")
        else:
            print(f"  [ERREUR] Méthode '{method}' manquante!")
            all_ok = False

    return all_ok


def test_3_get_documents_with_archives():
    """Vérifie que get_documents_domaine supporte include_archives."""
    print_header("TEST 3: Récupération documents avec archives")

    # Trouver un opérateur avec des documents
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT DISTINCT d.operateur_id, p.nom, p.prenom, COUNT(*) as nb_docs
            FROM documents d
            JOIN personnel p ON d.operateur_id = p.id
            GROUP BY d.operateur_id
            ORDER BY nb_docs DESC
            LIMIT 1
        """)
        result = cur.fetchone()

    if not result:
        print("  [SKIP] Aucun document trouvé en base")
        return True

    operateur_id = result['operateur_id']
    print(f"  Opérateur testé: {result['prenom']} {result['nom']} (ID: {operateur_id})")

    # Test avec include_archives=False
    docs_sans_archives = get_documents_domaine(operateur_id, DomaineRH.FORMATION, include_archives=False)
    print(f"  [OK] Sans archives: {len(docs_sans_archives)} document(s)")

    # Test avec include_archives=True
    docs_avec_archives = get_documents_domaine(operateur_id, DomaineRH.FORMATION, include_archives=True)
    print(f"  [OK] Avec archives: {len(docs_avec_archives)} document(s)")

    return True


def test_4_archive_restore_cycle():
    """Teste le cycle complet archiver/restaurer."""
    print_header("TEST 4: Cycle archiver/restaurer")

    # Trouver un document actif
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT id, nom_affichage, statut
            FROM documents
            WHERE statut = 'actif' OR statut IS NULL
            LIMIT 1
        """)
        doc = cur.fetchone()

    if not doc:
        print("  [SKIP] Aucun document actif trouvé pour le test")
        return True

    doc_id = doc['id']
    print(f"  Document testé: '{doc['nom_affichage']}' (ID: {doc_id})")
    print(f"  Statut initial: {doc['statut'] or 'NULL (actif)'}")

    doc_service = DocumentService()

    # Archiver
    print("\n  >> Archivage...")
    success, msg = doc_service.archive_document(doc_id)
    if success:
        print(f"  [OK] {msg}")
    else:
        print(f"  [ERREUR] {msg}")
        return False

    # Vérifier le statut
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("SELECT statut FROM documents WHERE id = %s", (doc_id,))
        new_status = cur.fetchone()['statut']

    if new_status == 'archive':
        print(f"  [OK] Statut après archivage: {new_status}")
    else:
        print(f"  [ERREUR] Statut inattendu: {new_status}")
        return False

    # Restaurer
    print("\n  >> Restauration...")
    success, msg = doc_service.restore_document(doc_id)
    if success:
        print(f"  [OK] {msg}")
    else:
        print(f"  [ERREUR] {msg}")
        return False

    # Vérifier le statut final
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("SELECT statut FROM documents WHERE id = %s", (doc_id,))
        final_status = cur.fetchone()['statut']

    if final_status == 'actif':
        print(f"  [OK] Statut après restauration: {final_status}")
    else:
        print(f"  [ERREUR] Statut inattendu: {final_status}")
        return False

    return True


def test_5_list_all_documents():
    """Liste tous les documents avec leur statut."""
    print_header("TEST 5: Liste des documents en base")

    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT
                d.id, d.nom_affichage, d.statut,
                CONCAT(p.prenom, ' ', p.nom) as operateur,
                c.nom as categorie
            FROM documents d
            JOIN personnel p ON d.operateur_id = p.id
            LEFT JOIN categories_documents c ON d.categorie_id = c.id
            ORDER BY d.id
            LIMIT 20
        """)
        docs = cur.fetchall()

    if not docs:
        print("  Aucun document en base")
        return True

    print(f"  {len(docs)} document(s) trouvé(s):\n")

    for doc in docs:
        statut = doc['statut'] or 'actif'
        icon = "📦" if statut == 'archive' else "📄"
        print(f"    {icon} [{doc['id']}] {doc['nom_affichage']}")
        print(f"       └─ {doc['operateur']} | {doc['categorie']} | Statut: {statut}")

    return True


def test_6_ui_imports():
    """Vérifie que les imports UI sont corrects."""
    print_header("TEST 6: Vérification imports gestion_rh.py")

    try:
        # Vérifier la syntaxe du fichier
        import py_compile
        py_compile.compile(
            os.path.join(os.path.dirname(__file__), '..', 'core', 'gui', 'gestion_rh.py'),
            doraise=True
        )
        print("  [OK] Syntaxe gestion_rh.py correcte")

        # Vérifier les imports critiques
        from PyQt5.QtCore import Qt
        from PyQt5.QtWidgets import QCheckBox
        print("  [OK] Imports PyQt5 OK (Qt, QCheckBox)")

        return True
    except Exception as e:
        print(f"  [ERREUR] {e}")
        return False


def main():
    print("\n" + "=" * 60)
    print("   TESTS D'IMPLÉMENTATION - ARCHIVAGE DOCUMENTS")
    print("=" * 60)

    results = []

    results.append(("Structure table", test_1_structure_table()))
    results.append(("Méthodes service", test_2_document_service_methods()))
    results.append(("Get avec archives", test_3_get_documents_with_archives()))
    results.append(("Cycle archive/restore", test_4_archive_restore_cycle()))
    results.append(("Liste documents", test_5_list_all_documents()))
    results.append(("Imports UI", test_6_ui_imports()))

    # Résumé
    print_header("RÉSUMÉ DES TESTS")

    passed = 0
    failed = 0

    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status} - {name}")
        if result:
            passed += 1
        else:
            failed += 1

    print(f"\n  Total: {passed} réussi(s), {failed} échoué(s)")

    if failed == 0:
        print("\n  🎉 TOUS LES TESTS SONT PASSÉS!")
    else:
        print(f"\n  ⚠️  {failed} test(s) en échec")

    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
