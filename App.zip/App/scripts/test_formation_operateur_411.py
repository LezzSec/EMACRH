# -*- coding: utf-8 -*-
"""
Script de test: Ajouter des formations pour l'opérateur ID 411
"""

import sys
import os

# Ajouter le répertoire App au path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from datetime import date, timedelta
from core.db.configbd import DatabaseConnection, DatabaseCursor


def ensure_formation_features():
    """S'assure que les features formations existent dans la base de données."""
    print("=" * 60)
    print("1. Vérification/Ajout des features formations...")
    print("=" * 60)

    features_to_add = [
        ('rh.formations.view', 'Voir Formations', 'RH', 'Consulter les formations du personnel', 40),
        ('rh.formations.edit', 'Gérer Formations', 'RH', 'Ajouter et modifier les formations', 41),
        ('rh.formations.delete', 'Supprimer Formations', 'RH', 'Supprimer des formations', 42),
    ]

    with DatabaseConnection() as conn:
        cur = conn.cursor(dictionary=True)

        for key_code, label, module, description, display_order in features_to_add:
            # Vérifier si la feature existe
            cur.execute("SELECT id FROM features WHERE key_code = %s", (key_code,))
            existing = cur.fetchone()

            if existing:
                print(f"  [OK] Feature '{key_code}' existe déjà (ID: {existing['id']})")
            else:
                cur.execute("""
                    INSERT INTO features (key_code, label, module, description, display_order)
                    VALUES (%s, %s, %s, %s, %s)
                """, (key_code, label, module, description, display_order))
                print(f"  [+] Feature '{key_code}' ajoutée")

        # Ajouter les features au rôle Admin (ID=1)
        print("\n  Attribution au rôle Admin (ID=1)...")
        for key_code, *_ in features_to_add:
            cur.execute("""
                INSERT IGNORE INTO role_features (role_id, feature_key)
                VALUES (1, %s)
            """, (key_code,))

        # Ajouter les features au rôle gestion_rh (ID=3)
        print("  Attribution au rôle gestion_rh (ID=3)...")
        for key_code, *_ in features_to_add:
            cur.execute("""
                INSERT IGNORE INTO role_features (role_id, feature_key)
                VALUES (3, %s)
            """, (key_code,))

        # Ajouter lecture seule au rôle gestion_production (ID=2)
        print("  Attribution lecture au rôle gestion_production (ID=2)...")
        cur.execute("""
            INSERT IGNORE INTO role_features (role_id, feature_key)
            VALUES (2, 'rh.formations.view')
        """)

        conn.commit()
        print("\n  [OK] Features formations configurées avec succès!")


def get_operateur_info(operateur_id: int):
    """Récupère les informations de l'opérateur."""
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT id, nom, prenom, matricule, statut
            FROM personnel
            WHERE id = %s
        """, (operateur_id,))
        return cur.fetchone()


def get_formations_operateur(operateur_id: int):
    """Récupère les formations existantes de l'opérateur."""
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT id, intitule, organisme, date_debut, date_fin, statut
            FROM formation
            WHERE operateur_id = %s
            ORDER BY date_debut DESC
        """, (operateur_id,))
        return cur.fetchall()


def add_test_formation(operateur_id: int, intitule: str, organisme: str,
                       date_debut: date, date_fin: date, duree_heures: float,
                       statut: str = "Planifiée", certificat: bool = False):
    """Ajoute une formation de test."""
    with DatabaseConnection() as conn:
        cur = conn.cursor()

        sql = """
            INSERT INTO formation (
                operateur_id, intitule, organisme, date_debut, date_fin,
                duree_heures, statut, certificat_obtenu, commentaire
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cur.execute(sql, (
            operateur_id, intitule, organisme, date_debut, date_fin,
            duree_heures, statut, certificat, "Test automatisé"
        ))

        formation_id = cur.lastrowid
        conn.commit()
        return formation_id


def main():
    operateur_id = 411

    print("\n" + "=" * 60)
    print("TEST D'AJOUT DE FORMATIONS - OPÉRATEUR ID 411")
    print("=" * 60)

    # 1. S'assurer que les features existent
    ensure_formation_features()

    # 2. Vérifier que l'opérateur existe
    print("\n" + "=" * 60)
    print("2. Vérification de l'opérateur...")
    print("=" * 60)

    operateur = get_operateur_info(operateur_id)
    if not operateur:
        print(f"  [ERREUR] Opérateur ID {operateur_id} non trouvé!")
        return

    print(f"  [OK] Opérateur trouvé:")
    print(f"       - ID: {operateur['id']}")
    print(f"       - Nom: {operateur['prenom']} {operateur['nom']}")
    print(f"       - Matricule: {operateur['matricule']}")
    print(f"       - Statut: {operateur['statut']}")

    # 3. Afficher les formations existantes
    print("\n" + "=" * 60)
    print("3. Formations existantes...")
    print("=" * 60)

    formations_existantes = get_formations_operateur(operateur_id)
    if formations_existantes:
        print(f"  {len(formations_existantes)} formation(s) trouvée(s):")
        for f in formations_existantes:
            print(f"    - [{f['id']}] {f['intitule']} ({f['statut']})")
    else:
        print("  Aucune formation existante")

    # 4. Ajouter des formations de test
    print("\n" + "=" * 60)
    print("4. Ajout de formations de test...")
    print("=" * 60)

    today = date.today()

    formations_test = [
        {
            "intitule": "Formation SST (Test)",
            "organisme": "APAVE",
            "date_debut": today,
            "date_fin": today + timedelta(days=2),
            "duree_heures": 14.0,
            "statut": "Planifiée",
            "certificat": False
        },
        {
            "intitule": "Habilitation Électrique B0/H0 (Test)",
            "organisme": "SOCOTEC",
            "date_debut": today - timedelta(days=30),
            "date_fin": today - timedelta(days=28),
            "duree_heures": 7.0,
            "statut": "Terminée",
            "certificat": True
        },
        {
            "intitule": "CACES R489 Cat 3 (Test)",
            "organisme": "AFTRAL",
            "date_debut": today + timedelta(days=14),
            "date_fin": today + timedelta(days=18),
            "duree_heures": 35.0,
            "statut": "Planifiée",
            "certificat": False
        },
    ]

    for f in formations_test:
        try:
            formation_id = add_test_formation(
                operateur_id=operateur_id,
                intitule=f["intitule"],
                organisme=f["organisme"],
                date_debut=f["date_debut"],
                date_fin=f["date_fin"],
                duree_heures=f["duree_heures"],
                statut=f["statut"],
                certificat=f["certificat"]
            )
            print(f"  [+] Formation ajoutée (ID: {formation_id}): {f['intitule']}")
        except Exception as e:
            print(f"  [ERREUR] Échec ajout '{f['intitule']}': {e}")

    # 5. Vérifier les formations après ajout
    print("\n" + "=" * 60)
    print("5. Formations après ajout...")
    print("=" * 60)

    formations_apres = get_formations_operateur(operateur_id)
    print(f"  {len(formations_apres)} formation(s) totale(s):")
    for f in formations_apres:
        date_str = f['date_debut'].strftime('%d/%m/%Y') if f['date_debut'] else 'N/A'
        print(f"    - [{f['id']}] {f['intitule']} | {f['organisme']} | {date_str} | {f['statut']}")

    print("\n" + "=" * 60)
    print("TEST TERMINÉ AVEC SUCCÈS!")
    print("=" * 60)
    print("\nVous pouvez maintenant relancer l'application et vérifier")
    print(f"les formations de l'opérateur {operateur['prenom']} {operateur['nom']}.")


if __name__ == "__main__":
    main()
