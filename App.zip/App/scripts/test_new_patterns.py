# -*- coding: utf-8 -*-
"""
Script de test pour valider les nouveaux patterns:
- QueryExecutor
- CRUDService (PersonnelService, FormationService, etc.)

Usage:
    cd App
    py -m scripts.test_new_patterns
"""

import sys
from pathlib import Path

# Ajouter le répertoire App au PYTHONPATH
app_dir = Path(__file__).parent.parent
sys.path.insert(0, str(app_dir))

from core.db.query_executor import QueryExecutor
from core.services.personnel_service import PersonnelService
from core.services.formation_service_crud import FormationServiceCRUD
from core.services.contrat_service_crud import ContratServiceCRUD
from core.services.polyvalence_service_crud import PolyvalenceServiceCRUD
from core.services.absence_service_crud import AbsenceServiceCRUD


def print_section(title: str):
    """Affiche une section avec séparateur."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def test_query_executor():
    """Test QueryExecutor."""
    print_section("TEST 1: QueryExecutor")

    try:
        # Test fetch_all
        print("\n1. fetch_all() - Récupérer tous les personnels actifs")
        personnels = QueryExecutor.fetch_all(
            "SELECT id, nom, prenom, statut FROM personnel WHERE statut = %s LIMIT 5",
            ('ACTIF',),
            dictionary=True
        )
        print(f"   ✓ Trouvé {len(personnels)} personnels actifs")
        if personnels:
            print(f"   Premier: {personnels[0]['nom']} {personnels[0]['prenom']}")

        # Test fetch_one
        print("\n2. fetch_one() - Récupérer un personnel par ID")
        if personnels:
            first_id = personnels[0]['id']
            personnel = QueryExecutor.fetch_one(
                "SELECT * FROM personnel WHERE id = %s",
                (first_id,),
                dictionary=True
            )
            print(f"   ✓ Trouvé: {personnel['nom']} {personnel['prenom']}")

        # Test fetch_scalar
        print("\n3. fetch_scalar() - Compter le total de personnels")
        total = QueryExecutor.fetch_scalar(
            "SELECT COUNT(*) FROM personnel",
            default=0
        )
        print(f"   ✓ Total personnels: {total}")

        # Test count
        print("\n4. count() - Compter les personnels actifs")
        count_actifs = QueryExecutor.count('personnel', {'statut': 'ACTIF'})
        print(f"   ✓ Personnels actifs: {count_actifs}")

        # Test exists
        print("\n5. exists() - Vérifier si un personnel existe")
        if personnels:
            exists = QueryExecutor.exists('personnel', {'id': personnels[0]['id']})
            print(f"   ✓ Personnel ID {personnels[0]['id']} existe: {exists}")

        print("\n✅ QueryExecutor: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ QueryExecutor: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_personnel_service():
    """Test PersonnelService."""
    print_section("TEST 2: PersonnelService")

    try:
        # Test get_actifs
        print("\n1. get_actifs() - Récupérer les personnels actifs")
        actifs = PersonnelService.get_actifs()
        print(f"   ✓ Personnels actifs: {len(actifs)}")
        if actifs:
            print(f"   Premier: {actifs[0]['nom']} {actifs[0]['prenom']}")

        # Test count_actifs
        print("\n2. count_actifs() - Compter les actifs")
        count = PersonnelService.count_actifs()
        print(f"   ✓ Nombre d'actifs: {count}")

        # Test count_inactifs
        print("\n3. count_inactifs() - Compter les inactifs")
        count_inactifs = PersonnelService.count_inactifs()
        print(f"   ✓ Nombre d'inactifs: {count_inactifs}")

        # Test get_by_id
        print("\n4. get_by_id() - Récupérer un personnel par ID")
        if actifs:
            personnel = PersonnelService.get_by_id(actifs[0]['id'])
            if personnel:
                print(f"   ✓ Trouvé: {personnel['nom']} {personnel['prenom']}")

        print("\n✅ PersonnelService: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ PersonnelService: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_formation_service():
    """Test FormationServiceCRUD."""
    print_section("TEST 3: FormationServiceCRUD")

    try:
        # Test get_all
        print("\n1. get_all() - Récupérer toutes les formations (limit 5)")
        formations = FormationServiceCRUD.get_all(order_by='date_debut DESC', limit=5)
        print(f"   ✓ Formations trouvées: {len(formations)}")
        if formations:
            print(f"   Première: {formations[0].get('intitule', 'N/A')}")

        # Test count
        print("\n2. count() - Compter toutes les formations")
        total = FormationServiceCRUD.count()
        print(f"   ✓ Total formations: {total}")

        # Test get_planifiees
        print("\n3. get_planifiees() - Récupérer formations planifiées")
        planifiees = FormationServiceCRUD.get_planifiees()
        print(f"   ✓ Formations planifiées: {len(planifiees)}")

        print("\n✅ FormationServiceCRUD: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ FormationServiceCRUD: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_contrat_service():
    """Test ContratServiceCRUD."""
    print_section("TEST 4: ContratServiceCRUD")

    try:
        # Test get_actifs
        print("\n1. get_actifs() - Récupérer les contrats actifs (limit 5)")
        actifs = ContratServiceCRUD.get_actifs(order_by='date_debut DESC')
        if actifs:
            actifs = actifs[:5]
        print(f"   ✓ Contrats actifs: {len(actifs)}")
        if actifs:
            print(f"   Premier: Type={actifs[0].get('type_contrat', 'N/A')}")

        # Test count
        print("\n2. count() - Compter tous les contrats actifs")
        total_actifs = QueryExecutor.count('contrat', {'actif': 1})
        print(f"   ✓ Total contrats actifs: {total_actifs}")

        # Test get_by_type
        print("\n3. get_by_type('CDI') - Récupérer les CDI")
        cdis = ContratServiceCRUD.get_by_type('CDI', actif_only=True)
        print(f"   ✓ CDI actifs: {len(cdis)}")

        print("\n✅ ContratServiceCRUD: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ ContratServiceCRUD: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_polyvalence_service():
    """Test PolyvalenceServiceCRUD."""
    print_section("TEST 5: PolyvalenceServiceCRUD")

    try:
        # Test get_all
        print("\n1. get_all() - Récupérer toutes les polyvalences (limit 5)")
        polys = PolyvalenceServiceCRUD.get_all(order_by='niveau DESC', limit=5)
        print(f"   ✓ Polyvalences trouvées: {len(polys)}")
        if polys:
            print(f"   Première: Niveau={polys[0].get('niveau', 'N/A')}")

        # Test count
        print("\n2. count() - Compter toutes les polyvalences")
        total = PolyvalenceServiceCRUD.count()
        print(f"   ✓ Total polyvalences: {total}")

        # Test get_by_niveau
        print("\n3. get_by_niveau(4) - Récupérer les experts (niveau 4)")
        experts = PolyvalenceServiceCRUD.get_by_niveau(4)
        print(f"   ✓ Experts (niveau 4): {len(experts)}")

        print("\n✅ PolyvalenceServiceCRUD: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ PolyvalenceServiceCRUD: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def test_absence_service():
    """Test AbsenceServiceCRUD."""
    print_section("TEST 6: AbsenceServiceCRUD")

    try:
        # Test get_all
        print("\n1. get_all() - Récupérer toutes les absences (limit 5)")
        absences = AbsenceServiceCRUD.get_all(order_by='date_debut DESC', limit=5)
        print(f"   ✓ Absences trouvées: {len(absences)}")
        if absences:
            print(f"   Première: Statut={absences[0].get('statut', 'N/A')}")

        # Test count
        print("\n2. count() - Compter toutes les absences")
        total = AbsenceServiceCRUD.count()
        print(f"   ✓ Total absences: {total}")

        # Test get_en_attente
        print("\n3. get_en_attente() - Récupérer absences en attente")
        en_attente = AbsenceServiceCRUD.get_en_attente()
        print(f"   ✓ Absences en attente: {len(en_attente)}")

        print("\n✅ AbsenceServiceCRUD: TOUS LES TESTS PASSÉS")

    except Exception as e:
        print(f"\n❌ AbsenceServiceCRUD: ERREUR - {e}")
        import traceback
        traceback.print_exc()


def main():
    """Exécute tous les tests."""
    print("\n" + "="*60)
    print("  TESTS DES NOUVEAUX PATTERNS (2026-02-09)")
    print("="*60)
    print("\nCe script teste QueryExecutor et les 5 services CRUD:")
    print("  - QueryExecutor (accès DB centralisé)")
    print("  - PersonnelService")
    print("  - FormationServiceCRUD")
    print("  - ContratServiceCRUD")
    print("  - PolyvalenceServiceCRUD")
    print("  - AbsenceServiceCRUD")

    # Exécuter tous les tests
    test_query_executor()
    test_personnel_service()
    test_formation_service()
    test_contrat_service()
    test_polyvalence_service()
    test_absence_service()

    print("\n" + "="*60)
    print("  RÉSUMÉ")
    print("="*60)
    print("\n✅ Tous les tests ont été exécutés")
    print("\n💡 Si aucune erreur n'est affichée ci-dessus,")
    print("   tous les patterns fonctionnent correctement!")

    print("\n📚 Prochaines étapes:")
    print("  1. Utiliser ces services pour tous les nouveaux développements")
    print("  2. Refactoriser progressivement les fichiers existants")
    print("  3. Consulter: docs/dev/refactoring-guide-2026-02-09.md")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
