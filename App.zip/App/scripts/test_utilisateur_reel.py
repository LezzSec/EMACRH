# -*- coding: utf-8 -*-
"""
TEST UTILISATEUR REEL - Simulation d'utilisation de l'application EMAC
Simule les actions d'un RH qui gere le dossier d'un employe
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from datetime import date, datetime, timedelta
from core.db.configbd import DatabaseConnection, DatabaseCursor

OPERATEUR_ID = 412  # Thomas Lahirigoyen


def section(title):
    print()
    print("=" * 65)
    print(f"  {title}")
    print("=" * 65)


def main():
    # ============================================================
    section("SCENARIO: Un RH gere le dossier de Thomas Lahirigoyen")
    # ============================================================

    print()
    print("L'utilisateur ouvre la fiche de Thomas Lahirigoyen (ID 412)...")

    from core.services.rh_service import get_operateur_by_id, get_resume_operateur

    op = get_operateur_by_id(OPERATEUR_ID)
    if not op:
        print("  [ERREUR] Operateur non trouve!")
        return False

    print(f"  Nom: {op['prenom']} {op['nom']}")
    print(f"  Matricule: {op['matricule']}")
    print(f"  Statut: {op['statut']}")

    # ============================================================
    section("1. CONSULTER ET MODIFIER LA POLYVALENCE")
    # ============================================================

    print()
    print("Le RH consulte les competences de Thomas...")

    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT p.id, p.niveau, p.date_evaluation, po.poste_code as poste_nom
            FROM polyvalence p
            JOIN postes po ON p.poste_id = po.id
            WHERE p.operateur_id = %s
            ORDER BY p.niveau DESC
            LIMIT 5
        """, (OPERATEUR_ID,))
        competences = cur.fetchall()

    if competences:
        print(f"  {len(competences)} competence(s) trouvee(s):")
        for c in competences:
            print(f"    - {c['poste_nom']}: Niveau {c['niveau']}")

        # Modifier le niveau d'une competence
        comp_id = competences[0]['id']
        ancien_niveau = competences[0]['niveau']
        nouveau_niveau = 3 if ancien_niveau != 3 else 2

        print()
        print(f"Le RH modifie le niveau de \"{competences[0]['poste_nom']}\"...")
        print(f"  Ancien niveau: {ancien_niveau}")
        print(f"  Nouveau niveau: {nouveau_niveau}")

        with DatabaseConnection() as conn:
            cur = conn.cursor()
            cur.execute("""
                UPDATE polyvalence
                SET niveau = %s, date_evaluation = %s
                WHERE id = %s
            """, (nouveau_niveau, date.today(), comp_id))
            conn.commit()

        print("  [OK] Niveau modifie avec succes")

        # Remettre l'ancien niveau
        with DatabaseConnection() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE polyvalence SET niveau = %s WHERE id = %s", (ancien_niveau, comp_id))
            conn.commit()
        print("  [OK] Niveau restaure")
    else:
        print("  Aucune competence trouvee - creation d'une competence de test...")

        # Trouver un poste
        with DatabaseCursor(dictionary=True) as cur:
            cur.execute("SELECT id, poste_code as nom FROM postes LIMIT 1")
            poste = cur.fetchone()

        if poste:
            with DatabaseConnection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    INSERT INTO polyvalence (operateur_id, poste_id, niveau, date_evaluation)
                    VALUES (%s, %s, 2, %s)
                """, (OPERATEUR_ID, poste['id'], date.today()))
                poly_id = cur.lastrowid
                conn.commit()
            print(f"  [OK] Competence creee: {poste['nom']} niveau 2")

            # Supprimer
            with DatabaseConnection() as conn:
                cur = conn.cursor()
                cur.execute("DELETE FROM polyvalence WHERE id = %s", (poly_id,))
                conn.commit()
            print("  [OK] Competence de test supprimee")

    # ============================================================
    section("2. AJOUTER UN CONTRAT")
    # ============================================================

    print()
    print("Le RH ajoute un nouveau contrat CDD...")

    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO contrat (
                operateur_id, type_contrat, date_debut, date_fin,
                emploi, salaire, actif
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            OPERATEUR_ID,
            'CDD',
            date.today(),
            date.today() + timedelta(days=180),
            'Operateur Production',
            2200.00,
            1
        ))
        contrat_id = cur.lastrowid
        conn.commit()

    print(f"  [OK] Contrat CDD cree (ID: {contrat_id})")
    print(f"  - Type: CDD")
    print(f"  - Debut: {date.today()}")
    print(f"  - Fin: {date.today() + timedelta(days=180)}")
    print(f"  - Salaire: 2200 EUR")

    # Verifier
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("SELECT * FROM contrat WHERE id = %s", (contrat_id,))
        contrat = cur.fetchone()
        print(f"  [OK] Verification: Contrat trouve en base")

    # Supprimer le contrat de test
    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM contrat WHERE id = %s", (contrat_id,))
        conn.commit()
    print(f"  [OK] Contrat de test supprime")

    # ============================================================
    section("3. AJOUTER UNE FORMATION")
    # ============================================================

    print()
    print("Le RH planifie une formation SST...")

    from core.services.formation_service import add_formation, get_formations_personnel, delete_formation

    success, msg, formation_id = add_formation(
        operateur_id=OPERATEUR_ID,
        intitule="Formation SST - Test",
        date_debut=date.today() + timedelta(days=14),
        date_fin=date.today() + timedelta(days=16),
        organisme="APAVE",
        duree_heures=14.0,
        statut="Planifiee",
        certificat_obtenu=False,
        commentaire="Formation de test automatise"
    )

    if success:
        print(f"  [OK] Formation creee (ID: {formation_id})")
        print(f"  - Intitule: Formation SST - Test")
        print(f"  - Organisme: APAVE")
        print(f"  - Duree: 14h")

        # Verifier
        formations = get_formations_personnel(OPERATEUR_ID)
        print(f"  [OK] Thomas a maintenant {len(formations)} formation(s)")

        # Supprimer
        delete_formation(formation_id)
        print(f"  [OK] Formation de test supprimee")
    else:
        print(f"  [ERREUR] {msg}")

    # ============================================================
    section("4. GERER LES DOCUMENTS")
    # ============================================================

    print()
    print("Le RH ajoute un document puis l'archive...")

    from core.services.document_service import DocumentService
    from core.services.rh_service import get_documents_archives_operateur

    doc_service = DocumentService()

    # Trouver une categorie
    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("SELECT id, nom FROM categories_documents LIMIT 1")
        cat = cur.fetchone()

    # Creer un document
    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO documents (
                operateur_id, categorie_id, nom_fichier, nom_affichage,
                chemin_fichier, statut
            ) VALUES (%s, %s, %s, %s, %s, 'actif')
        """, (OPERATEUR_ID, cat['id'], 'test_user.pdf', 'Document Test Utilisateur', 'test/test_user.pdf'))
        doc_id = cur.lastrowid
        conn.commit()

    print(f"  [OK] Document cree (ID: {doc_id})")

    # Archiver
    success, msg = doc_service.archive_document(doc_id)
    print(f"  [OK] Document archive: {msg}")

    # Verifier archives
    archives = get_documents_archives_operateur(OPERATEUR_ID)
    print(f"  [OK] Archives de Thomas: {len(archives)} document(s)")

    # Restaurer
    success, msg = doc_service.restore_document(doc_id)
    print(f"  [OK] Document restaure: {msg}")

    # Supprimer
    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM documents WHERE id = %s", (doc_id,))
        conn.commit()
    print(f"  [OK] Document de test supprime")

    # ============================================================
    section("5. ENREGISTRER UNE ABSENCE")
    # ============================================================

    print()
    print("Le RH enregistre une absence maladie...")

    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO demande_absence (
                personnel_id, type_absence_id, date_debut, date_fin,
                demi_journee_debut, demi_journee_fin, nb_jours, motif, statut
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            OPERATEUR_ID,
            3,  # MALADIE
            date.today() - timedelta(days=5),
            date.today() - timedelta(days=3),
            'JOURNEE',
            'JOURNEE',
            3.0,
            'Grippe',
            'VALIDEE'
        ))
        absence_id = cur.lastrowid
        conn.commit()

    print(f"  [OK] Absence enregistree (ID: {absence_id})")
    print(f"  - Type: Maladie")
    print(f"  - Du {date.today() - timedelta(days=5)} au {date.today() - timedelta(days=3)}")
    print(f"  - Motif: Grippe")

    # Supprimer
    with DatabaseConnection() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM demande_absence WHERE id = %s", (absence_id,))
        conn.commit()
    print(f"  [OK] Absence de test supprimee")

    # ============================================================
    section("6. AJOUTER UNE VISITE MEDICALE")
    # ============================================================

    print()
    print("Le RH enregistre une visite medicale...")

    from core.services.medical_service import create_visite, delete_visite

    visite_data = {
        'type_visite': 'Périodique',
        'date_visite': date.today(),
        'medecin': 'Dr. Martin',
        'resultat': 'Apte',
        'prochaine_visite': date.today() + timedelta(days=365),
        'commentaire': 'Test automatise'
    }
    success, msg, visite_id = create_visite(OPERATEUR_ID, visite_data)

    if success and visite_id:
        print(f"  [OK] Visite creee (ID: {visite_id})")
        print(f"  - Type: Visite periodique")
        print(f"  - Resultat: Apte")
        print(f"  - Prochaine: {date.today() + timedelta(days=365)}")

        # Supprimer
        delete_visite(visite_id)
        print(f"  [OK] Visite de test supprimee")
    else:
        print(f"  [INFO] {msg}")

    # ============================================================
    section("7. CONSULTER L'HISTORIQUE")
    # ============================================================

    print()
    print("Le RH consulte l'historique des actions...")

    with DatabaseCursor(dictionary=True) as cur:
        cur.execute("""
            SELECT action, description, date_time, utilisateur
            FROM historique
            ORDER BY date_time DESC
            LIMIT 5
        """)
        historique = cur.fetchall()

    print(f"  Dernieres actions:")
    for h in historique:
        date_str = h['date_time'].strftime('%d/%m %H:%M') if h['date_time'] else '-'
        user = h['utilisateur'] or 'systeme'
        desc = (h['description'] or '-')[:40]
        print(f"    [{date_str}] {h['action']} - {desc}")

    # ============================================================
    section("8. VERIFIER LES EVALUATIONS EN RETARD")
    # ============================================================

    print()
    print("Le RH consulte les evaluations en retard...")

    from core.services.evaluation_service import get_evaluations_en_retard

    retards = get_evaluations_en_retard()
    print(f"  {len(retards)} evaluation(s) en retard")

    if retards:
        print(f"  Exemples:")
        for r in retards[:3]:
            nom = r.get('nom_complet') or f"{r.get('prenom', '')} {r.get('nom', '')}"
            poste = r.get('poste_nom', '-')
            print(f"    - {nom} sur {poste}")

    # ============================================================
    section("9. STATISTIQUES GLOBALES")
    # ============================================================

    print()
    print("Le RH consulte les statistiques...")

    with DatabaseCursor(dictionary=True) as cur:
        # Personnel actif
        cur.execute("SELECT COUNT(*) as count FROM personnel WHERE statut = 'ACTIF'")
        actifs = cur.fetchone()['count']

        # Postes
        cur.execute("SELECT COUNT(*) as count FROM postes")
        postes = cur.fetchone()['count']

        # Formations planifiees
        cur.execute("SELECT COUNT(*) as count FROM formation WHERE statut = 'Planifiee'")
        formations = cur.fetchone()['count']

        # Documents
        cur.execute("SELECT COUNT(*) as count FROM documents")
        docs = cur.fetchone()['count']

        # Contrats actifs
        cur.execute("SELECT COUNT(*) as count FROM contrat WHERE actif = 1")
        contrat = cur.fetchone()['count']

    print(f"  Personnel actif: {actifs}")
    print(f"  Postes: {postes}")
    print(f"  Contrats actifs: {contrat}")
    print(f"  Formations planifiees: {formations}")
    print(f"  Documents: {docs}")

    # ============================================================
    section("SCENARIO TERMINE")
    # ============================================================

    print()
    print("Toutes les operations utilisateur ont ete testees avec succes!")
    print()
    print("Resume des actions simulees:")
    print("  1. Consultation et modification polyvalence")
    print("  2. Ajout/suppression contrat")
    print("  3. Ajout/suppression formation")
    print("  4. Gestion documents (ajout, archivage, restauration)")
    print("  5. Enregistrement absence")
    print("  6. Visite medicale")
    print("  7. Consultation historique")
    print("  8. Consultation evaluations en retard")
    print("  9. Statistiques globales")
    print()
    print(">>> APPLICATION 100% FONCTIONNELLE <<<")

    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
