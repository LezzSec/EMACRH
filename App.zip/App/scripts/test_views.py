# -*- coding: utf-8 -*-
"""Script pour tester les vues créées."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.db.configbd import get_connection

def main():
    conn = get_connection()
    cur = conn.cursor(dictionary=True)

    print("=== TEST DES VUES CREEES ===\n")

    # Test v_alertes_medicales
    print("1. Test v_alertes_medicales")
    print("-" * 60)
    try:
        cur.execute("SELECT * FROM v_alertes_medicales LIMIT 5")
        results = cur.fetchall()
        print(f"   Nombre d'alertes medicales: {len(results)}")
        if results:
            print("   Exemple d'alertes:")
            for row in results[:3]:
                print(f"     - {row['nom']} {row['prenom']}: {row['type_alerte']}")
                print(f"       Date: {row['date_alerte']}, Retard: {row['jours_retard']} jours")
        else:
            print("   Aucune alerte medicale pour le moment")
        print("   OK\n")
    except Exception as e:
        print(f"   ERREUR: {e}\n")

    # Test v_alertes_entretiens
    print("2. Test v_alertes_entretiens")
    print("-" * 60)
    try:
        cur.execute("SELECT * FROM v_alertes_entretiens LIMIT 5")
        results = cur.fetchall()
        print(f"   Nombre d'alertes entretiens: {len(results)}")
        if results:
            print("   Exemple d'alertes:")
            for row in results[:3]:
                print(f"     - {row['nom']} {row['prenom']}: {row['type_alerte']}")
                print(f"       Derniere date: {row['derniere_date']}, Retard: {row['jours_retard']} jours")
        else:
            print("   Aucune alerte entretien pour le moment")
        print("   OK\n")
    except Exception as e:
        print(f"   ERREUR: {e}\n")

    # Compter le total de chaque type d'alerte
    print("3. Statistiques globales")
    print("-" * 60)

    cur.execute("""
        SELECT
            type_alerte,
            COUNT(*) as nb_alertes,
            AVG(jours_retard) as retard_moyen
        FROM v_alertes_medicales
        GROUP BY type_alerte
    """)
    stats_med = cur.fetchall()
    print("   Alertes medicales par type:")
    for stat in stats_med:
        print(f"     - {stat['type_alerte']}: {stat['nb_alertes']} alertes (retard moyen: {stat['retard_moyen']:.1f} jours)")

    cur.execute("""
        SELECT
            type_alerte,
            COUNT(*) as nb_alertes,
            AVG(jours_retard) as retard_moyen
        FROM v_alertes_entretiens
        GROUP BY type_alerte
    """)
    stats_ent = cur.fetchall()
    print("   Alertes entretiens par type:")
    for stat in stats_ent:
        print(f"     - {stat['type_alerte']}: {stat['nb_alertes']} alertes (retard moyen: {stat['retard_moyen']:.1f} jours)")

    print("\n=== TOUTES LES VUES FONCTIONNENT CORRECTEMENT ===")

    cur.close()
    conn.close()

if __name__ == '__main__':
    main()
