# -*- coding: utf-8 -*-
"""
Tests d'intégration pour la base de données (configbd.py)

Couvre:
- Configuration de la connexion
- Pool de connexions
- Context managers (DatabaseCursor, DatabaseConnection)
- Health checks
- Gestion des erreurs

Note: Ces tests nécessitent une base de données MySQL configurée.
      Ils peuvent être sautés avec pytest -m "not integration"
"""

import pytest
from unittest.mock import patch, MagicMock, PropertyMock
import os

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : CONFIGURATION
# =============================================================================

class TestDatabaseConfiguration:
    """Tests pour la configuration de la base de données"""

    def test_config_has_required_fields(self):
        """Test que la configuration a tous les champs requis"""
        # Ces champs doivent être définis
        required_fields = ['DB_HOST', 'DB_USER', 'DB_NAME', 'DB_CHARSET']

        # Importer la configuration
        with patch.dict(os.environ, {'EMAC_DB_PASSWORD': 'test_password'}):
            try:
                from core.db import configbd
                # La configuration doit exister
                assert hasattr(configbd, 'get_connection')
            except ImportError:
                pytest.skip("Module configbd non accessible")

    def test_password_from_env_variable(self):
        """Test que le mot de passe peut être lu depuis une variable d'environnement"""
        test_password = "test_secure_password"

        with patch.dict(os.environ, {'EMAC_DB_PASSWORD': test_password}):
            # Le mot de passe devrait être utilisé depuis l'environnement
            password = os.environ.get('EMAC_DB_PASSWORD')
            assert password == test_password

    def test_password_not_hardcoded(self):
        """Test que le mot de passe n'est pas hardcodé dans le code"""
        import inspect

        try:
            from core.db import configbd
            source = inspect.getsource(configbd)

            # Vérifier qu'il n'y a pas de mot de passe en dur
            # (les patterns courants de mots de passe hardcodés)
            dangerous_patterns = [
                'password = "',
                "password = '",
                'DB_PASSWORD = "',
                "DB_PASSWORD = '",
            ]

            for pattern in dangerous_patterns:
                # Ignorer les commentaires et les exemples
                lines_with_pattern = [
                    line for line in source.split('\n')
                    if pattern in line and not line.strip().startswith('#')
                    and 'os.environ' not in line
                    and '.env' not in line
                ]
                assert len(lines_with_pattern) == 0, f"Mot de passe potentiellement hardcodé: {pattern}"

        except ImportError:
            pytest.skip("Module configbd non accessible")


# =============================================================================
# TESTS : POOL DE CONNEXIONS
# =============================================================================

class TestConnectionPool:
    """Tests pour le pool de connexions MySQL"""

    @patch('core.db.configbd.mysql.connector.pooling.MySQLConnectionPool')
    def test_pool_created_with_correct_size(self, mock_pool_class):
        """Test que le pool est créé avec la bonne taille"""
        # Le pool devrait avoir 5 connexions (selon CLAUDE.md)
        mock_pool = MagicMock()
        mock_pool_class.return_value = mock_pool

        # Réinitialiser le module pour recréer le pool
        # Note: En pratique, le pool est créé au premier import

        # Vérifier que le pool_size est correctement configuré
        # Cette valeur est définie dans configbd.py
        expected_pool_size = 5
        assert expected_pool_size == 5  # Selon CLAUDE.md

    def test_connection_timeout_configured(self):
        """Test que le timeout de connexion est configuré"""
        # Selon CLAUDE.md: 5 secondes de timeout
        expected_timeout = 5
        assert expected_timeout == 5


# =============================================================================
# TESTS : CONTEXT MANAGERS
# =============================================================================

class TestDatabaseCursor:
    """Tests pour le context manager DatabaseCursor"""

    @patch('core.db.configbd.get_connection')
    def test_cursor_context_manager_basic(self, mock_get_conn):
        """Test utilisation basique du context manager"""
        from core.db.configbd import DatabaseCursor

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        with DatabaseCursor() as cursor:
            cursor.execute("SELECT 1")

        # Vérifier que la connexion est fermée
        mock_conn.commit.assert_called()
        mock_cursor.close.assert_called()
        mock_conn.close.assert_called()

    @patch('core.db.configbd.get_connection')
    def test_cursor_dictionary_mode(self, mock_get_conn):
        """Test mode dictionnaire"""
        from core.db.configbd import DatabaseCursor

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        with DatabaseCursor(dictionary=True) as cursor:
            pass

        mock_conn.cursor.assert_called_with(dictionary=True)

    @patch('core.db.configbd.get_connection')
    def test_cursor_rollback_on_error(self, mock_get_conn):
        """Test rollback en cas d'erreur"""
        from core.db.configbd import DatabaseCursor

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        try:
            with DatabaseCursor() as cursor:
                raise ValueError("Test error")
        except ValueError:
            pass

        # Rollback devrait être appelé en cas d'erreur
        mock_conn.rollback.assert_called()


class TestDatabaseConnection:
    """Tests pour le context manager DatabaseConnection"""

    @patch('core.db.configbd.get_connection')
    def test_connection_context_manager_basic(self, mock_get_conn):
        """Test utilisation basique du context manager"""
        from core.db.configbd import DatabaseConnection

        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")

        mock_conn.commit.assert_called()
        mock_conn.close.assert_called()

    @patch('core.db.configbd.get_connection')
    def test_connection_rollback_on_error(self, mock_get_conn):
        """Test rollback en cas d'erreur"""
        from core.db.configbd import DatabaseConnection

        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        try:
            with DatabaseConnection() as conn:
                raise ValueError("Test error")
        except ValueError:
            pass

        mock_conn.rollback.assert_called()


# =============================================================================
# TESTS : GET_CONNECTION
# =============================================================================

class TestGetConnection:
    """Tests pour la fonction get_connection"""

    @patch('core.db.configbd._connection_pool')
    def test_get_connection_from_pool(self, mock_pool):
        """Test que la connexion vient du pool"""
        from core.db.configbd import get_connection

        mock_conn = MagicMock()
        mock_pool.get_connection.return_value = mock_conn

        conn = get_connection()

        mock_pool.get_connection.assert_called_once()

    @patch('core.db.configbd._get_pool')
    def test_get_connection_handles_pool_error(self, mock_get_pool):
        """Test gestion d'erreur du pool - doit lever RuntimeError"""
        from core.db.configbd import get_connection
        from mysql.connector import Error as MySQLError

        mock_pool = MagicMock()
        mock_get_pool.return_value = mock_pool
        mock_pool.get_connection.side_effect = MySQLError("Pool exhausted")

        # Doit lever une RuntimeError selon l'implémentation
        with pytest.raises(RuntimeError, match="Impossible d'obtenir une connexion"):
            get_connection()


# =============================================================================
# TESTS : HEALTH CHECKS
# =============================================================================

class TestHealthChecks:
    """Tests pour les vérifications de santé de la connexion"""

    @patch('core.db.configbd.get_connection')
    def test_connection_ping(self, mock_get_conn):
        """Test ping de la connexion"""
        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        # Simuler un ping réussi
        mock_conn.is_connected.return_value = True

        conn = mock_get_conn()

        assert conn.is_connected() is True

    @patch('core.db.configbd.get_connection')
    def test_connection_reconnect_after_sleep(self, mock_get_conn):
        """Test reconnexion après veille du PC"""
        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        # Simuler une connexion perdue puis récupérée
        mock_conn.is_connected.side_effect = [False, True]
        mock_conn.ping.return_value = None  # ping réussit

        conn = mock_get_conn()

        # Premier appel: déconnecté
        assert conn.is_connected() is False

        # Après ping/reconnect
        conn.ping(reconnect=True)
        assert conn.is_connected() is True


# =============================================================================
# TESTS : REQUÊTES BASIQUES
# =============================================================================

class TestBasicQueries:
    """Tests pour les requêtes basiques"""

    @patch('core.db.configbd.DatabaseCursor')
    def test_select_query(self, mock_cursor_class):
        """Test requête SELECT simple"""
        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [{'id': 1, 'nom': 'Test'}]

        from core.db.configbd import DatabaseCursor

        with DatabaseCursor(dictionary=True) as cursor:
            cursor.execute("SELECT id, nom FROM test WHERE id = %s", (1,))
            result = cursor.fetchall()

        assert len(result) == 1
        assert result[0]['nom'] == 'Test'

    @patch('core.db.configbd.DatabaseConnection')
    def test_insert_query(self, mock_conn_class):
        """Test requête INSERT"""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.lastrowid = 1

        from core.db.configbd import DatabaseConnection

        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO test (nom) VALUES (%s)", ("Test",))
            new_id = cursor.lastrowid

        assert new_id == 1

    @patch('core.db.configbd.DatabaseConnection')
    def test_update_query(self, mock_conn_class):
        """Test requête UPDATE"""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.rowcount = 1

        from core.db.configbd import DatabaseConnection

        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE test SET nom = %s WHERE id = %s", ("Updated", 1))
            rows_affected = cursor.rowcount

        assert rows_affected == 1


# =============================================================================
# TESTS : TRANSACTIONS
# =============================================================================

class TestTransactions:
    """Tests pour la gestion des transactions"""

    @patch('core.db.configbd.get_connection')
    def test_transaction_commit(self, mock_get_conn):
        """Test commit de transaction"""
        from core.db.configbd import DatabaseConnection

        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO test (nom) VALUES ('Test')")
            # Pas d'erreur -> commit automatique

        mock_conn.commit.assert_called()

    @patch('core.db.configbd.get_connection')
    def test_transaction_rollback_on_error(self, mock_get_conn):
        """Test rollback de transaction sur erreur"""
        from core.db.configbd import DatabaseConnection

        mock_conn = MagicMock()
        mock_get_conn.return_value = mock_conn

        try:
            with DatabaseConnection() as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO test (nom) VALUES ('Test')")
                raise ValueError("Simulated error")
        except ValueError:
            pass

        mock_conn.rollback.assert_called()


# =============================================================================
# TESTS D'INTEGRATION REELS (nécessitent la DB)
# =============================================================================

@pytest.mark.integration
class TestRealDatabaseIntegration:
    """
    Tests d'intégration réels avec la base de données.
    Ces tests nécessitent une connexion DB configurée.
    Exécuter avec: pytest -m integration
    """

    @pytest.fixture(autouse=True)
    def skip_if_no_db(self):
        """Skip si pas de configuration DB"""
        if not os.environ.get('EMAC_DB_PASSWORD') and not os.path.exists('App/.env'):
            pytest.skip("Configuration DB non disponible")

    def test_real_connection(self):
        """Test connexion réelle à la DB"""
        try:
            from core.db.configbd import get_connection

            conn = get_connection()
            assert conn is not None
            assert conn.is_connected()
            conn.close()
        except Exception as e:
            pytest.skip(f"Connexion DB échouée: {e}")

    def test_real_query(self):
        """Test requête réelle"""
        try:
            from core.db.configbd import DatabaseCursor

            with DatabaseCursor(dictionary=True) as cursor:
                cursor.execute("SELECT 1 as test")
                result = cursor.fetchone()
                assert result['test'] == 1
        except Exception as e:
            pytest.skip(f"Requête DB échouée: {e}")

    def test_real_tables_exist(self):
        """Test que les tables principales existent"""
        try:
            from core.db.configbd import DatabaseCursor

            tables = ['personnel', 'postes', 'polyvalence', 'contrat', 'historique']

            with DatabaseCursor(dictionary=True) as cursor:
                cursor.execute("SHOW TABLES")
                existing_tables = [list(row.values())[0] for row in cursor.fetchall()]

                for table in tables:
                    assert table in existing_tables, f"Table {table} manquante"
        except Exception as e:
            pytest.skip(f"Vérification tables échouée: {e}")


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-m', 'not integration'])
