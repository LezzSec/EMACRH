# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service d'authentification (auth_service.py)

Couvre:
- Validation des mots de passe (complexité)
- Hash et vérification des mots de passe (bcrypt)
- Authentification des utilisateurs
- Gestion de la session utilisateur
- Vérification des permissions
- Gestion des utilisateurs (CRUD)
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : VALIDATION MOT DE PASSE
# =============================================================================

class TestValidatePassword:
    """Tests pour la fonction validate_password"""

    def test_password_valid(self):
        """Test mot de passe valide respectant toutes les règles"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("Test1234!")
        assert valid is True
        assert message == ""

    def test_password_too_short(self):
        """Test mot de passe trop court (< 8 caractères)"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("Test1!")
        assert valid is False
        assert "8 caractères" in message

    def test_password_no_uppercase(self):
        """Test mot de passe sans majuscule"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("test1234!")
        assert valid is False
        assert "majuscule" in message

    def test_password_no_lowercase(self):
        """Test mot de passe sans minuscule"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("TEST1234!")
        assert valid is False
        assert "minuscule" in message

    def test_password_no_digit(self):
        """Test mot de passe sans chiffre"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("TestTest!")
        assert valid is False
        assert "chiffre" in message

    def test_password_no_special_char(self):
        """Test mot de passe sans caractère spécial"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("Test12345")
        assert valid is False
        assert "spécial" in message

    def test_password_complex_valid(self):
        """Test mot de passe complexe valide"""
        from core.services.auth_service import validate_password

        valid, message = validate_password("MyP@ssw0rd#2024")
        assert valid is True
        assert message == ""

    def test_password_special_chars_variety(self):
        """Test avec différents caractères spéciaux"""
        from core.services.auth_service import validate_password

        special_chars = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '+', '=']
        for char in special_chars:
            valid, message = validate_password(f"Test123{char}")
            assert valid is True, f"Le caractère {char} devrait être accepté"


class TestGetPasswordRequirements:
    """Tests pour get_password_requirements"""

    def test_requirements_contains_all_rules(self):
        """Test que les exigences contiennent toutes les règles"""
        from core.services.auth_service import get_password_requirements

        requirements = get_password_requirements()
        assert "8 caractères" in requirements
        assert "majuscule" in requirements
        assert "minuscule" in requirements
        assert "chiffre" in requirements
        assert "spécial" in requirements


# =============================================================================
# TESTS : HASH ET VERIFICATION MOT DE PASSE
# =============================================================================

class TestPasswordHashing:
    """Tests pour hash_password et verify_password"""

    def test_hash_password(self):
        """Test que le hash est différent du mot de passe original"""
        from core.services.auth_service import hash_password

        password = "Test1234!"
        hashed = hash_password(password)

        assert hashed != password
        assert hashed.startswith("$2b$")  # bcrypt prefix

    def test_hash_password_unique(self):
        """Test que deux hash du même mot de passe sont différents (salt)"""
        from core.services.auth_service import hash_password

        password = "Test1234!"
        hash1 = hash_password(password)
        hash2 = hash_password(password)

        assert hash1 != hash2

    def test_verify_password_correct(self):
        """Test vérification mot de passe correct"""
        from core.services.auth_service import hash_password, verify_password

        password = "Test1234!"
        hashed = hash_password(password)

        assert verify_password(password, hashed) is True

    def test_verify_password_incorrect(self):
        """Test vérification mot de passe incorrect"""
        from core.services.auth_service import hash_password, verify_password

        password = "Test1234!"
        hashed = hash_password(password)

        assert verify_password("WrongPassword!", hashed) is False

    def test_verify_password_invalid_hash(self):
        """Test vérification avec un hash invalide"""
        from core.services.auth_service import verify_password

        result = verify_password("Test1234!", "invalid_hash")
        assert result is False


# =============================================================================
# TESTS : SESSION UTILISATEUR
# =============================================================================

class TestUserSession:
    """Tests pour la classe UserSession"""

    def test_session_singleton(self):
        """Test que UserSession est un singleton"""
        from core.services.auth_service import UserSession

        session1 = UserSession()
        session2 = UserSession()

        assert session1 is session2

    def test_session_set_and_get_user(self):
        """Test set et get user"""
        from core.services.auth_service import UserSession

        user_data = {'id': 1, 'username': 'test', 'nom': 'Test', 'prenom': 'User'}
        permissions = {'module1': {'lecture': True}}
        session_id = 123

        UserSession.set_user(user_data, permissions, session_id)

        assert UserSession.get_user() == user_data
        assert UserSession.get_permissions() == permissions
        assert UserSession.get_session_id() == session_id

    def test_session_is_authenticated(self):
        """Test is_authenticated"""
        from core.services.auth_service import UserSession

        # Vider la session d'abord
        UserSession.clear()
        assert UserSession.is_authenticated() is False

        # Définir un utilisateur
        UserSession.set_user({'id': 1}, {}, 1)
        assert UserSession.is_authenticated() is True

    def test_session_clear(self):
        """Test clear session"""
        from core.services.auth_service import UserSession

        UserSession.set_user({'id': 1}, {}, 1)
        UserSession.clear()

        assert UserSession.get_user() is None
        assert UserSession.get_permissions() is None
        assert UserSession.get_session_id() is None
        assert UserSession.is_authenticated() is False


# =============================================================================
# TESTS : AUTHENTIFICATION
# =============================================================================

class TestAuthenticateUser:
    """Tests pour la fonction authenticate_user"""

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.log_hist_async')
    def test_authenticate_user_success(self, mock_log, mock_get_conn):
        """Test authentification réussie"""
        from core.services.auth_service import authenticate_user, hash_password, UserSession

        # Nettoyer la session
        UserSession.clear()

        # Mock de la connexion
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        # Données utilisateur simulées
        password_hash = hash_password("Test1234!")
        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'username': 'testuser',
                'password_hash': password_hash,
                'nom': 'Test',
                'prenom': 'User',
                'role_id': 1,
                'actif': True,
                'role_nom': 'admin',
                'module': 'personnel',
                'lecture': True,
                'ecriture': True,
                'suppression': False
            }
        ]
        mock_cursor.lastrowid = 1

        success, error = authenticate_user("testuser", "Test1234!")

        assert success is True
        assert error is None
        assert UserSession.is_authenticated() is True

    @patch('core.services.auth_service.get_connection')
    def test_authenticate_user_wrong_password(self, mock_get_conn):
        """Test authentification avec mauvais mot de passe"""
        from core.services.auth_service import authenticate_user, hash_password, UserSession

        UserSession.clear()

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        password_hash = hash_password("Test1234!")
        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'username': 'testuser',
                'password_hash': password_hash,
                'nom': 'Test',
                'prenom': 'User',
                'role_id': 1,
                'actif': True,
                'role_nom': 'admin',
                'module': None,
                'lecture': None,
                'ecriture': None,
                'suppression': None
            }
        ]

        success, error = authenticate_user("testuser", "WrongPassword!")

        assert success is False
        assert "incorrect" in error

    @patch('core.services.auth_service.get_connection')
    def test_authenticate_user_not_found(self, mock_get_conn):
        """Test authentification utilisateur inexistant"""
        from core.services.auth_service import authenticate_user, UserSession

        UserSession.clear()

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.fetchall.return_value = []

        success, error = authenticate_user("unknown", "Test1234!")

        assert success is False
        assert "incorrect" in error

    @patch('core.services.auth_service.get_connection')
    def test_authenticate_user_inactive(self, mock_get_conn):
        """Test authentification utilisateur désactivé"""
        from core.services.auth_service import authenticate_user, hash_password, UserSession

        UserSession.clear()

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'username': 'testuser',
                'password_hash': hash_password("Test1234!"),
                'nom': 'Test',
                'prenom': 'User',
                'role_id': 1,
                'actif': False,  # Désactivé
                'role_nom': 'admin',
                'module': None,
                'lecture': None,
                'ecriture': None,
                'suppression': None
            }
        ]

        success, error = authenticate_user("testuser", "Test1234!")

        assert success is False
        assert "désactivé" in error

    @patch('core.services.auth_service.get_connection')
    def test_authenticate_user_db_error(self, mock_get_conn):
        """Test authentification avec erreur DB"""
        from core.services.auth_service import authenticate_user

        mock_get_conn.return_value = None

        success, error = authenticate_user("testuser", "Test1234!")

        assert success is False
        assert "base de données" in error


# =============================================================================
# TESTS : PERMISSIONS
# =============================================================================

class TestPermissions:
    """Tests pour les fonctions de vérification des permissions"""

    def test_has_permission_not_authenticated(self):
        """Test has_permission sans authentification"""
        from core.services.auth_service import has_permission, UserSession

        UserSession.clear()

        result = has_permission('personnel', 'lecture')
        assert result is False

    def test_has_permission_with_permission(self):
        """Test has_permission avec permission accordée"""
        from core.services.auth_service import has_permission, UserSession

        permissions = {
            'personnel': {'lecture': True, 'ecriture': True, 'suppression': False}
        }
        UserSession.set_user({'id': 1, 'role_nom': 'admin'}, permissions, 1)

        assert has_permission('personnel', 'lecture') is True
        assert has_permission('personnel', 'ecriture') is True
        assert has_permission('personnel', 'suppression') is False

    def test_has_permission_module_not_found(self):
        """Test has_permission avec module inexistant"""
        from core.services.auth_service import has_permission, UserSession

        permissions = {
            'personnel': {'lecture': True}
        }
        UserSession.set_user({'id': 1, 'role_nom': 'admin'}, permissions, 1)

        assert has_permission('unknown_module', 'lecture') is False

    def test_is_admin_true(self):
        """Test is_admin pour un administrateur"""
        from core.services.auth_service import is_admin, UserSession

        UserSession.set_user({'id': 1, 'role_nom': 'admin'}, {}, 1)

        assert is_admin() is True

    def test_is_admin_false(self):
        """Test is_admin pour un non-administrateur"""
        from core.services.auth_service import is_admin, UserSession

        UserSession.set_user({'id': 2, 'role_nom': 'lecteur'}, {}, 1)

        assert is_admin() is False

    def test_is_admin_not_authenticated(self):
        """Test is_admin sans authentification"""
        from core.services.auth_service import is_admin, UserSession

        UserSession.clear()

        assert is_admin() is False


# =============================================================================
# TESTS : GESTION UTILISATEURS
# =============================================================================

class TestUserManagement:
    """Tests pour les fonctions de gestion des utilisateurs"""

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.is_admin')
    def test_get_all_users_as_admin(self, mock_is_admin, mock_get_conn):
        """Test get_all_users en tant qu'admin"""
        from core.services.auth_service import get_all_users

        mock_is_admin.return_value = True

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.fetchall.return_value = [
            {'id': 1, 'username': 'admin', 'nom': 'Admin', 'prenom': 'Test'},
            {'id': 2, 'username': 'user', 'nom': 'User', 'prenom': 'Test'}
        ]

        users = get_all_users()

        assert len(users) == 2
        assert users[0]['username'] == 'admin'

    @patch('core.services.auth_service.is_admin')
    def test_get_all_users_not_admin(self, mock_is_admin):
        """Test get_all_users en tant que non-admin"""
        from core.services.auth_service import get_all_users

        mock_is_admin.return_value = False

        users = get_all_users()

        assert users == []

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.is_admin')
    @patch('core.services.auth_service.log_hist_async')
    @patch('core.services.auth_service.get_current_user')
    def test_create_user_success(self, mock_get_user, mock_log, mock_is_admin, mock_get_conn):
        """Test création d'utilisateur réussie"""
        from core.services.auth_service import create_user

        mock_is_admin.return_value = True
        mock_get_user.return_value = {'username': 'admin'}

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.fetchone.return_value = None  # Utilisateur n'existe pas
        mock_cursor.lastrowid = 1

        success, error = create_user('newuser', 'Test1234!', 'New', 'User', 1)

        assert success is True
        assert error is None

    @patch('core.services.auth_service.is_admin')
    def test_create_user_not_admin(self, mock_is_admin):
        """Test création d'utilisateur par non-admin"""
        from core.services.auth_service import create_user

        mock_is_admin.return_value = False

        success, error = create_user('newuser', 'Test1234!', 'New', 'User', 1)

        assert success is False
        assert "administrateurs" in error

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.is_admin')
    def test_create_user_already_exists(self, mock_is_admin, mock_get_conn):
        """Test création d'utilisateur existant"""
        from core.services.auth_service import create_user

        mock_is_admin.return_value = True

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.fetchone.return_value = {'id': 1}  # Utilisateur existe

        success, error = create_user('existinguser', 'Test1234!', 'Existing', 'User', 1)

        assert success is False
        assert "existe déjà" in error


# =============================================================================
# TESTS : PROTECTION DERNIER ADMIN
# =============================================================================

class TestLastAdminProtection:
    """Tests pour la protection du dernier administrateur"""

    @patch('core.services.auth_service.get_connection')
    def test_count_active_admins(self, mock_get_conn):
        """Test comptage des admins actifs"""
        from core.services.auth_service import count_active_admins

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.fetchone.return_value = (2,)

        count = count_active_admins()

        assert count == 2

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.is_admin')
    @patch('core.services.auth_service.is_user_admin')
    @patch('core.services.auth_service.count_active_admins')
    def test_update_user_status_last_admin(self, mock_count, mock_is_user_admin, mock_is_admin, mock_get_conn):
        """Test désactivation du dernier admin bloquée"""
        from core.services.auth_service import update_user_status

        mock_is_admin.return_value = True
        mock_is_user_admin.return_value = True  # L'utilisateur est admin
        mock_count.return_value = 1  # Dernier admin

        success, error = update_user_status(1, False)  # Tenter de désactiver

        assert success is False
        assert "dernier administrateur" in error

    @patch('core.services.auth_service.get_connection')
    @patch('core.services.auth_service.is_admin')
    @patch('core.services.auth_service.get_current_user')
    @patch('core.services.auth_service.is_user_admin')
    @patch('core.services.auth_service.count_active_admins')
    def test_delete_user_last_admin(self, mock_count, mock_is_user_admin, mock_get_user, mock_is_admin, mock_get_conn):
        """Test suppression du dernier admin bloquée"""
        from core.services.auth_service import delete_user

        mock_is_admin.return_value = True
        mock_get_user.return_value = {'id': 2, 'username': 'admin2'}  # Utilisateur actuel
        mock_is_user_admin.return_value = True  # L'utilisateur à supprimer est admin
        mock_count.return_value = 1  # Dernier admin

        success, error = delete_user(1)

        assert success is False
        assert "dernier administrateur" in error

    @patch('core.services.auth_service.is_admin')
    @patch('core.services.auth_service.get_current_user')
    def test_delete_self_blocked(self, mock_get_user, mock_is_admin):
        """Test auto-suppression bloquée"""
        from core.services.auth_service import delete_user

        mock_is_admin.return_value = True
        mock_get_user.return_value = {'id': 1, 'username': 'admin'}

        success, error = delete_user(1)  # Tenter de se supprimer

        assert success is False
        assert "propre compte" in error


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
