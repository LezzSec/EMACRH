# -*- coding: utf-8 -*-
"""
Tests de sécurité pour valider les corrections de vulnérabilités.

Ce fichier teste:
1. Protection contre l'injection SQL (rh_service.py)
2. Protection contre le path traversal (template_service.py)
3. Protection contre l'injection de commandes (template_service.py)

Date: 2026-02-02
"""

import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path
import tempfile
import os


# ============================================================
# 1. TESTS SQL INJECTION - rh_service.get_documents_entite
# ============================================================

class TestSQLInjectionPrevention:
    """Tests pour valider la protection contre l'injection SQL."""

    def test_allowed_entity_types_accepted(self):
        """Les types d'entité autorisés doivent être acceptés."""
        from core.services.rh_service import get_documents_entite

        # Ces types sont dans la whitelist
        allowed_types = ['contrat', 'formation', 'declaration']

        for entity_type in allowed_types:
            with patch('core.services.rh_service.DatabaseCursor') as mock_cursor:
                mock_ctx = MagicMock()
                mock_ctx.__enter__ = MagicMock(return_value=MagicMock())
                mock_ctx.__exit__ = MagicMock(return_value=False)
                mock_ctx.__enter__().fetchall.return_value = []
                mock_cursor.return_value = mock_ctx

                # Ne doit pas lever d'exception
                result = get_documents_entite(entity_type, 1)
                assert isinstance(result, list)

    def test_sql_injection_column_rejected(self):
        """Une tentative d'injection SQL via le type d'entité doit être rejetée."""
        from core.services.rh_service import get_documents_entite

        # Tentatives d'injection SQL
        malicious_inputs = [
            "contrat; DROP TABLE documents; --",
            "contrat' OR '1'='1",
            "contrat UNION SELECT * FROM users --",
            "1=1; DELETE FROM personnel",
            "formation'; UPDATE users SET role='admin' WHERE '1'='1",
            "../../../etc/passwd",
            "contrat\"; DROP TABLE --",
        ]

        for malicious in malicious_inputs:
            result = get_documents_entite(malicious, 1)
            # Doit retourner une liste vide (rejeté silencieusement)
            assert result == [], f"Injection non bloquée: {malicious}"

    def test_unknown_entity_type_rejected(self):
        """Un type d'entité inconnu doit être rejeté."""
        from core.services.rh_service import get_documents_entite

        unknown_types = [
            'utilisateur',
            'personnel',
            'admin',
            'user',
            '',
            None,
            123,
        ]

        for unknown in unknown_types:
            result = get_documents_entite(unknown, 1)
            assert result == [], f"Type inconnu non rejeté: {unknown}"

    def test_whitelist_is_exhaustive(self):
        """La whitelist ne doit contenir que les colonnes attendues."""
        # Import direct pour tester la constante
        # Note: On ne peut pas importer ALLOWED_COLUMNS directement car c'est local
        # Mais on vérifie via les types acceptés
        from core.services.rh_service import get_documents_entite

        # Seuls ces 3 types sont autorisés
        expected_allowed = {'contrat', 'formation', 'declaration'}

        # Test exhaustif
        all_possible = ['contrat', 'formation', 'declaration',
                        'personnel', 'utilisateur', 'admin', 'poste', 'atelier']

        for entity_type in all_possible:
            with patch('core.services.rh_service.DatabaseCursor') as mock_cursor:
                mock_ctx = MagicMock()
                mock_ctx.__enter__ = MagicMock(return_value=MagicMock())
                mock_ctx.__exit__ = MagicMock(return_value=False)
                mock_ctx.__enter__().fetchall.return_value = [{'id': 1}]
                mock_cursor.return_value = mock_ctx

                result = get_documents_entite(entity_type, 1)

                if entity_type in expected_allowed:
                    # Doit avoir appelé le curseur (requête exécutée)
                    assert mock_cursor.called or result == []
                else:
                    # Ne doit PAS avoir appelé le curseur (rejeté avant)
                    assert result == []


# ============================================================
# 2. TESTS PATH TRAVERSAL - template_service
# ============================================================

class TestPathTraversalPrevention:
    """Tests pour valider la protection contre le path traversal."""

    def test_path_traversal_double_dots_blocked(self):
        """Les chemins avec .. doivent être bloqués."""
        from core.services.template_service import generate_filled_template

        # Mock du template avec un chemin malicieux
        malicious_paths = [
            '../../../etc/passwd',
            '..\\..\\..\\windows\\system32\\config\\sam',
            'templates/../../../secret.txt',
            '....//....//....//etc/passwd',
            './../.../../etc/shadow',
        ]

        for malicious_path in malicious_paths:
            with patch('core.services.template_service.DatabaseCursor') as mock_cursor:
                mock_ctx = MagicMock()
                mock_ctx.__enter__ = MagicMock(return_value=MagicMock())
                mock_ctx.__exit__ = MagicMock(return_value=False)
                mock_ctx.__enter__().fetchone.return_value = {
                    'id': 1,
                    'nom': 'Test',
                    'fichier_source': malicious_path,
                    'champ_operateur': 'A1',
                    'champ_auditeur': 'B1',
                    'champ_date': 'C1',
                }
                mock_cursor.return_value = mock_ctx

                success, message, _ = generate_filled_template(
                    template_id=1,
                    operateur_nom='Test',
                    operateur_prenom='User'
                )

                assert success is False, f"Path traversal non bloqué: {malicious_path}"
                assert "invalide" in message.lower() or "refuse" in message.lower() or "non trouve" in message.lower()

    def test_absolute_path_blocked(self):
        """Les chemins absolus doivent être bloqués."""
        from core.services.template_service import generate_filled_template

        absolute_paths = [
            '/etc/passwd',
            '/var/log/syslog',
            'C:\\Windows\\System32\\config\\SAM',
        ]

        for abs_path in absolute_paths:
            with patch('core.services.template_service.DatabaseCursor') as mock_cursor:
                mock_ctx = MagicMock()
                mock_ctx.__enter__ = MagicMock(return_value=MagicMock())
                mock_ctx.__exit__ = MagicMock(return_value=False)
                mock_ctx.__enter__().fetchone.return_value = {
                    'id': 1,
                    'nom': 'Test',
                    'fichier_source': abs_path,
                    'champ_operateur': 'A1',
                    'champ_auditeur': 'B1',
                    'champ_date': 'C1',
                }
                mock_cursor.return_value = mock_ctx

                success, message, _ = generate_filled_template(
                    template_id=1,
                    operateur_nom='Test',
                    operateur_prenom='User'
                )

                # Note: Certains chemins absolus seront traités comme "fichier non trouvé"
                # L'important est que success soit False
                assert success is False, f"Chemin absolu non bloqué: {abs_path}"


# ============================================================
# 3. TESTS COMMAND INJECTION - template_service.open_template_file
# ============================================================

class TestCommandInjectionPrevention:
    """Tests pour valider la protection contre l'injection de commandes."""

    def test_file_outside_allowed_dirs_blocked(self):
        """Les fichiers hors des répertoires autorisés doivent être bloqués."""
        from core.services.template_service import open_template_file

        # Créer un fichier dans un répertoire différent de temp_dir et templates_dir
        # On utilise le répertoire home de l'utilisateur qui ne devrait pas être autorisé
        home_dir = Path.home()
        test_file = home_dir / 'emac_security_test_file.txt'

        try:
            # Créer le fichier
            test_file.write_text('test content')

            # Ce fichier existe mais n'est pas dans temp_dir ou templates_dir
            success, message = open_template_file(str(test_file))

            # Doit être refusé
            assert success is False
            assert "refuse" in message.lower()
        finally:
            if test_file.exists():
                test_file.unlink()

    def test_nonexistent_file_rejected(self):
        """Les fichiers inexistants doivent être rejetés."""
        from core.services.template_service import open_template_file

        fake_paths = [
            '/nonexistent/path/file.txt',
            'C:\\fake\\path\\file.exe',
            '../../../nonexistent.txt',
        ]

        for fake_path in fake_paths:
            success, message = open_template_file(fake_path)
            assert success is False
            assert "non trouve" in message.lower() or "invalide" in message.lower()

    def test_directory_path_rejected(self):
        """Les chemins vers des répertoires doivent être rejetés."""
        from core.services.template_service import open_template_file

        # Utiliser un répertoire existant
        dir_path = tempfile.gettempdir()

        success, message = open_template_file(dir_path)

        assert success is False
        assert "invalide" in message.lower()

    def test_symlink_attack_consideration(self):
        """
        Test de considération des attaques par lien symbolique.
        Note: Ce test vérifie que is_file() est utilisé, ce qui détecte
        certains types de liens symboliques malicieux.
        """
        from core.services.template_service import open_template_file

        # Test avec un chemin qui ressemble à un lien symbolique
        # mais qui n'existe pas (devrait être rejeté)
        success, message = open_template_file('/tmp/fake_symlink_to_sensitive_file')
        assert success is False


# ============================================================
# 4. TESTS D'INTÉGRATION SÉCURITÉ
# ============================================================

class TestSecurityIntegration:
    """Tests d'intégration pour la sécurité globale."""

    def test_error_messages_do_not_leak_info(self):
        """Les messages d'erreur ne doivent pas divulguer d'informations sensibles."""
        from core.services.template_service import open_template_file
        from core.services.rh_service import get_documents_entite

        # Test open_template_file - le message ne doit pas contenir de détails système
        success, message = open_template_file('/etc/passwd')
        # Le message doit être générique
        assert success is False
        assert len(message) < 50  # Message court et générique

        # Test get_documents_entite - ne devrait pas inclure les détails SQL
        result = get_documents_entite("malicious'; DROP TABLE --", 1)
        assert result == []  # Rejeté silencieusement

    def test_logging_on_security_events(self):
        """Les événements de sécurité doivent être loggés."""
        from core.services.rh_service import get_documents_entite

        with patch('core.services.rh_service.logger') as mock_logger:
            # Tentative d'injection
            get_documents_entite("malicious_type", 1)

            # Doit avoir loggé un warning
            assert mock_logger.warning.called


# ============================================================
# MAIN
# ============================================================

if __name__ == '__main__':
    pytest.main([__file__, '-v'])
