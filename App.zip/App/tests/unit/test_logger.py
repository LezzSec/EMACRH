# -*- coding: utf-8 -*-
"""
Tests unitaires pour le système de logging/audit (logger.py)

Couvre:
- Fonction log_hist pour l'audit trail
- Formatage des détails JSON
- Récupération automatique de l'utilisateur
- Gestion des erreurs silencieuses
"""

import pytest
from unittest.mock import patch, MagicMock
import json

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : LOG_HIST BASIQUE
# =============================================================================

class TestLogHist:
    """Tests pour la fonction log_hist"""

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_basic(self, mock_get_conn):
        """Test log basique avec paramètres minimaux"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="INSERT",
            table_name="personnel",
            record_id=1,
            description="Création d'un nouvel employé"
        )

        # Vérifier que l'INSERT a été appelé
        mock_cursor.execute.assert_called_once()
        call_args = mock_cursor.execute.call_args
        assert "INSERT INTO historique" in call_args[0][0]
        mock_conn.commit.assert_called_once()

    @patch('core.services.logger.get_db_connection')
    @patch('core.services.logger._get_current_username')
    def test_log_hist_with_user(self, mock_get_user, mock_get_conn):
        """Test log avec utilisateur spécifié"""
        from core.services.logger import log_hist

        mock_get_user.return_value = None  # Pas d'utilisateur connecté
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="UPDATE",
            table_name="postes",
            record_id=5,
            description="Modification du poste",
            utilisateur="admin"
        )

        # Vérifier que l'utilisateur est passé
        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "admin" in params

    @patch('core.services.logger.get_db_connection')
    @patch('core.services.logger._get_current_username')
    def test_log_hist_auto_user(self, mock_get_user, mock_get_conn):
        """Test récupération automatique de l'utilisateur"""
        from core.services.logger import log_hist

        mock_get_user.return_value = "current_user"
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="DELETE",
            table_name="contrat",
            record_id=10
        )

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "current_user" in params


# =============================================================================
# TESTS : PARAMETRES OPTIONNELS
# =============================================================================

class TestLogHistOptionalParams:
    """Tests pour les paramètres optionnels de log_hist"""

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_with_operateur_id(self, mock_get_conn):
        """Test log avec operateur_id"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="UPDATE",
            table_name="polyvalence",
            record_id=1,
            description="Évaluation mise à jour",
            operateur_id=42
        )

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert 42 in params

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_with_poste_id(self, mock_get_conn):
        """Test log avec poste_id"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="INSERT",
            table_name="polyvalence",
            record_id=1,
            description="Nouvelle compétence",
            operateur_id=1,
            poste_id=5
        )

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert 5 in params


# =============================================================================
# TESTS : DETAILS JSON
# =============================================================================

class TestLogHistDetails:
    """Tests pour le formatage des détails"""

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_with_dict_details(self, mock_get_conn):
        """Test log avec détails dictionnaire"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        details = {
            'ancien_niveau': 2,
            'nouveau_niveau': 3,
            'raison': 'Progression'
        }

        log_hist(
            action="UPDATE",
            table_name="polyvalence",
            record_id=1,
            description="Changement de niveau",
            details=details
        )

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        # Les détails devraient être sérialisés en JSON
        description_param = params[4]  # description est le 5ème paramètre
        assert "ancien_niveau" in description_param

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_with_string_details(self, mock_get_conn):
        """Test log avec détails string"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(
            action="UPDATE",
            table_name="personnel",
            record_id=1,
            description="Modification",
            details="Détails en string"
        )

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        description_param = params[4]
        assert "Détails en string" in description_param


# =============================================================================
# TESTS : CONVERSION JSON
# =============================================================================

class TestToJsonStr:
    """Tests pour la fonction _to_json_str"""

    def test_to_json_str_none(self):
        """Test conversion None"""
        from core.services.logger import _to_json_str

        result = _to_json_str(None)
        assert result is None

    def test_to_json_str_string(self):
        """Test conversion string"""
        from core.services.logger import _to_json_str

        result = _to_json_str("test string")
        assert result == "test string"

    def test_to_json_str_dict(self):
        """Test conversion dictionnaire"""
        from core.services.logger import _to_json_str

        data = {'key': 'value', 'number': 42}
        result = _to_json_str(data)

        assert result is not None
        parsed = json.loads(result)
        assert parsed['key'] == 'value'
        assert parsed['number'] == 42

    def test_to_json_str_list(self):
        """Test conversion liste"""
        from core.services.logger import _to_json_str

        data = [1, 2, 3, 'test']
        result = _to_json_str(data)

        assert result is not None
        parsed = json.loads(result)
        assert parsed == [1, 2, 3, 'test']

    def test_to_json_str_bytes(self):
        """Test conversion bytes"""
        from core.services.logger import _to_json_str

        data = b"test bytes"
        result = _to_json_str(data)

        assert result == "test bytes"


# =============================================================================
# TESTS : GESTION DES ERREURS
# =============================================================================

class TestLogHistErrorHandling:
    """Tests pour la gestion des erreurs dans log_hist"""

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_db_error_silent(self, mock_get_conn):
        """Test que les erreurs DB ne cassent pas le flux"""
        from core.services.logger import log_hist

        mock_get_conn.return_value = None  # Connexion échouée

        # Ne devrait pas lever d'exception
        log_hist(
            action="INSERT",
            table_name="test",
            record_id=1,
            description="Test"
        )

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_cursor_error_silent(self, mock_get_conn):
        """Test erreur cursor gérée silencieusement"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.execute.side_effect = Exception("SQL Error")

        # Ne devrait pas lever d'exception
        log_hist(
            action="INSERT",
            table_name="test",
            record_id=1,
            description="Test"
        )

        # Rollback devrait être appelé
        mock_conn.rollback.assert_called()

    @patch('core.services.logger.get_db_connection')
    def test_log_hist_commit_error_silent(self, mock_get_conn):
        """Test erreur commit gérée silencieusement"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        mock_conn.commit.side_effect = Exception("Commit Error")

        # Ne devrait pas lever d'exception
        log_hist(
            action="INSERT",
            table_name="test",
            record_id=1,
            description="Test"
        )


# =============================================================================
# TESTS : RECUPERATION UTILISATEUR
# =============================================================================

class TestGetCurrentUsername:
    """Tests pour _get_current_username"""

    @patch('core.services.auth_service.get_current_user')
    def test_get_username_from_session(self, mock_get_user):
        """Test récupération username depuis la session"""
        from core.services.logger import _get_current_username

        mock_get_user.return_value = {'username': 'test_user', 'nom': 'Test'}

        result = _get_current_username()

        assert result == 'test_user'

    @patch('core.services.auth_service.get_current_user')
    def test_get_username_fallback_to_nom(self, mock_get_user):
        """Test fallback vers 'nom' si pas de 'username'"""
        from core.services.logger import _get_current_username

        mock_get_user.return_value = {'nom': 'TestNom'}

        result = _get_current_username()

        assert result == 'TestNom'

    @patch('core.services.auth_service.get_current_user')
    def test_get_username_no_user(self, mock_get_user):
        """Test quand aucun utilisateur connecté"""
        from core.services.logger import _get_current_username

        mock_get_user.return_value = None

        result = _get_current_username()

        assert result is None

    @patch('core.services.auth_service.get_current_user')
    def test_get_username_import_error(self, mock_get_user):
        """Test gestion d'erreur d'import"""
        from core.services.logger import _get_current_username

        mock_get_user.side_effect = ImportError("Module not found")

        result = _get_current_username()

        assert result is None


# =============================================================================
# TESTS : ACTIONS SPECIFIQUES
# =============================================================================

class TestLogHistActions:
    """Tests pour les différentes actions de log"""

    @patch('core.services.logger.get_db_connection')
    def test_log_insert_action(self, mock_get_conn):
        """Test action INSERT"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="INSERT", table_name="test", record_id=1)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "INSERT" in params

    @patch('core.services.logger.get_db_connection')
    def test_log_update_action(self, mock_get_conn):
        """Test action UPDATE"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="UPDATE", table_name="test", record_id=1)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "UPDATE" in params

    @patch('core.services.logger.get_db_connection')
    def test_log_delete_action(self, mock_get_conn):
        """Test action DELETE"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="DELETE", table_name="test", record_id=1)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "DELETE" in params

    @patch('core.services.logger.get_db_connection')
    def test_log_custom_action(self, mock_get_conn):
        """Test action personnalisée"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="CONNEXION", table_name="utilisateurs", record_id=1)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "CONNEXION" in params


# =============================================================================
# TESTS : RECORD_ID TYPES
# =============================================================================

class TestRecordIdTypes:
    """Tests pour les différents types de record_id"""

    @patch('core.services.logger.get_db_connection')
    def test_record_id_integer(self, mock_get_conn):
        """Test record_id entier"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="UPDATE", table_name="test", record_id=123)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "123" in params

    @patch('core.services.logger.get_db_connection')
    def test_record_id_string(self, mock_get_conn):
        """Test record_id string"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="UPDATE", table_name="test", record_id="ABC123")

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert "ABC123" in params

    @patch('core.services.logger.get_db_connection')
    def test_record_id_none(self, mock_get_conn):
        """Test record_id None"""
        from core.services.logger import log_hist

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_get_conn.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor

        log_hist(action="ERROR", table_name="system", record_id=None)

        call_args = mock_cursor.execute.call_args
        params = call_args[0][1]
        assert None in params


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
