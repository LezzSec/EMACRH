# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service d'évaluation (evaluation_service.py)

Couvre:
- Récupération des évaluations en retard
- Récupération des évaluations à venir
- Évaluations par opérateur
- Mise à jour des évaluations
- Statistiques des évaluations
- Validation des niveaux (1-4)
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : GET EVALUATIONS EN RETARD
# =============================================================================

class TestGetEvaluationsEnRetard:
    """Tests pour get_evaluations_en_retard"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_evaluations_en_retard_with_results(self, mock_cursor_class):
        """Test récupération des évaluations en retard"""
        from core.services.evaluation_service import get_evaluations_en_retard

        # Setup mock
        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'operateur_id': 1,
                'nom': 'Martin',
                'prenom': 'Pierre',
                'matricule': 'OP001',
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 2,
                'date_evaluation': date.today() - timedelta(days=400),
                'prochaine_evaluation': date.today() - timedelta(days=35),
                'jours_retard': 35
            },
            {
                'polyvalence_id': 2,
                'operateur_id': 2,
                'nom': 'Durand',
                'prenom': 'Marie',
                'matricule': 'OP002',
                'poste_id': 2,
                'poste_code': '0830',
                'nom_atelier': 'Atelier B',
                'niveau': 3,
                'date_evaluation': date.today() - timedelta(days=380),
                'prochaine_evaluation': date.today() - timedelta(days=15),
                'jours_retard': 15
            }
        ]

        result = get_evaluations_en_retard()

        assert len(result) == 2
        assert result[0]['jours_retard'] == 35  # Le plus en retard en premier
        assert result[0]['nom'] == 'Martin'
        assert result[1]['jours_retard'] == 15

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_evaluations_en_retard_empty(self, mock_cursor_class):
        """Test quand aucune évaluation n'est en retard"""
        from core.services.evaluation_service import get_evaluations_en_retard

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = get_evaluations_en_retard()

        assert result == []


# =============================================================================
# TESTS : GET PROCHAINES EVALUATIONS
# =============================================================================

class TestGetProchainesEvaluations:
    """Tests pour get_prochaines_evaluations"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_prochaines_evaluations_default(self, mock_cursor_class):
        """Test récupération des évaluations à venir (30 jours par défaut)"""
        from core.services.evaluation_service import get_prochaines_evaluations

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'operateur_id': 1,
                'nom': 'Martin',
                'prenom': 'Pierre',
                'matricule': 'OP001',
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 2,
                'date_evaluation': date.today() - timedelta(days=335),
                'prochaine_evaluation': date.today() + timedelta(days=15),
                'jours_restants': 15
            }
        ]

        result = get_prochaines_evaluations()

        assert len(result) == 1
        assert result[0]['jours_restants'] == 15

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_prochaines_evaluations_custom_days(self, mock_cursor_class):
        """Test récupération avec nombre de jours personnalisé"""
        from core.services.evaluation_service import get_prochaines_evaluations

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = []

        result = get_prochaines_evaluations(jours=7)

        # Vérifier que la requête a été appelée
        mock_cursor.execute.assert_called_once()
        args = mock_cursor.execute.call_args[0]
        # La date limite devrait être calculée avec 7 jours
        assert result == []


# =============================================================================
# TESTS : GET EVALUATIONS PAR OPERATEUR
# =============================================================================

class TestGetEvaluationsParOperateur:
    """Tests pour get_evaluations_par_operateur"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_evaluations_par_operateur_with_results(self, mock_cursor_class):
        """Test récupération des évaluations d'un opérateur"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 2,
                'date_evaluation': date.today() - timedelta(days=100),
                'prochaine_evaluation': date.today() + timedelta(days=265),
                'statut': 'OK'
            },
            {
                'polyvalence_id': 2,
                'poste_id': 2,
                'poste_code': '0830',
                'nom_atelier': 'Atelier B',
                'niveau': 3,
                'date_evaluation': date.today() - timedelta(days=400),
                'prochaine_evaluation': date.today() - timedelta(days=35),
                'statut': 'RETARD'
            }
        ]

        result = get_evaluations_par_operateur(operateur_id=1)

        assert len(result) == 2
        assert result[1]['statut'] == 'RETARD'

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_evaluations_par_operateur_empty(self, mock_cursor_class):
        """Test opérateur sans évaluation"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = get_evaluations_par_operateur(operateur_id=999)

        assert result == []


# =============================================================================
# TESTS : METTRE A JOUR EVALUATION
# =============================================================================

class TestMettreAJourEvaluation:
    """Tests pour mettre_a_jour_evaluation"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    @patch('core.services.logger.log_hist')
    def test_mettre_a_jour_evaluation_success(self, mock_log, mock_cursor_class):
        """Test mise à jour réussie d'une évaluation"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        # Mock des anciennes valeurs
        mock_cursor.fetchone.return_value = (1, 1, 2, date.today() - timedelta(days=365))

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=3,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is True
        mock_log.assert_called_once()

    def test_mettre_a_jour_evaluation_invalid_niveau(self):
        """Test avec niveau invalide (hors 1-4)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=5,  # Invalide
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False

    def test_mettre_a_jour_evaluation_niveau_zero(self):
        """Test avec niveau 0 (invalide)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=0,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_mettre_a_jour_evaluation_db_error(self, mock_cursor_class):
        """Test erreur base de données"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        mock_cursor_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=3,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False


# =============================================================================
# TESTS : NIVEAUX DE COMPETENCE
# =============================================================================

class TestNiveauxCompetence:
    """Tests pour la validation des niveaux de compétence"""

    @pytest.mark.parametrize("niveau", [1, 2, 3, 4])
    @patch('core.services.evaluation_service.DatabaseCursor')
    @patch('core.services.logger.log_hist')
    def test_niveaux_valides(self, mock_log, mock_cursor_class, niveau):
        """Test tous les niveaux valides (1-4)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = (1, 1, 2, date.today())

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=niveau,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is True

    @pytest.mark.parametrize("niveau", [-1, 0, 5, 10, 100])
    def test_niveaux_invalides(self, niveau):
        """Test tous les niveaux invalides"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=niveau,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False


# =============================================================================
# TESTS : STATISTIQUES
# =============================================================================

class TestGetStatistiquesEvaluations:
    """Tests pour get_statistiques_evaluations"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_statistiques_evaluations(self, mock_cursor_class):
        """Test récupération des statistiques"""
        from core.services.evaluation_service import get_statistiques_evaluations

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        # Mock des résultats successifs
        mock_cursor.fetchone.side_effect = [
            {'total': 100},  # Total évaluations
            {'total': 10},   # En retard
            {'total': 15}    # À venir 30j
        ]
        mock_cursor.fetchall.return_value = [
            {'niveau': 1, 'count': 20},
            {'niveau': 2, 'count': 35},
            {'niveau': 3, 'count': 30},
            {'niveau': 4, 'count': 15}
        ]

        stats = get_statistiques_evaluations()

        assert 'total' in stats
        assert 'en_retard' in stats
        assert 'a_venir_30j' in stats
        assert 'par_niveau' in stats

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_get_statistiques_evaluations_empty(self, mock_cursor_class):
        """Test statistiques avec base vide"""
        from core.services.evaluation_service import get_statistiques_evaluations

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.side_effect = [
            {'total': 0},
            {'total': 0},
            {'total': 0}
        ]
        mock_cursor.fetchall.return_value = []

        stats = get_statistiques_evaluations()

        assert stats['total'] == 0
        assert stats['en_retard'] == 0


# =============================================================================
# TESTS : STATUTS D'EVALUATION
# =============================================================================

class TestStatutsEvaluation:
    """Tests pour la logique des statuts d'évaluation"""

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_statut_retard(self, mock_cursor_class):
        """Test statut RETARD pour évaluation en retard"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 2,
                'date_evaluation': date.today() - timedelta(days=400),
                'prochaine_evaluation': date.today() - timedelta(days=35),
                'statut': 'RETARD'
            }
        ]

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'RETARD'

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_statut_urgent(self, mock_cursor_class):
        """Test statut URGENT pour évaluation dans les 30 prochains jours"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 2,
                'date_evaluation': date.today() - timedelta(days=335),
                'prochaine_evaluation': date.today() + timedelta(days=15),
                'statut': 'URGENT'
            }
        ]

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'URGENT'

    @patch('core.services.evaluation_service.DatabaseCursor')
    def test_statut_ok(self, mock_cursor_class):
        """Test statut OK pour évaluation dans plus de 30 jours"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'polyvalence_id': 1,
                'poste_id': 1,
                'poste_code': '0506',
                'nom_atelier': 'Atelier A',
                'niveau': 4,
                'date_evaluation': date.today() - timedelta(days=100),
                'prochaine_evaluation': date.today() + timedelta(days=265),
                'statut': 'OK'
            }
        ]

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'OK'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
