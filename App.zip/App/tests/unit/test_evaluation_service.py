# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service d'évaluation (evaluation_service.py)

Couvre:
- Récupération des évaluations en retard
- Récupération des évaluations à venir
- Évaluations par opérateur
- Mise à jour des évaluations
- Statistiques des évaluations
- Validation des niveaux (1-4)
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : GET EVALUATIONS EN RETARD
# =============================================================================

class TestGetEvaluationsEnRetard:
    """Tests pour get_evaluations_en_retard"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'operateur_id': 1,
            'nom': 'Martin',
            'prenom': 'Pierre',
            'matricule': 'OP001',
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 2,
            'date_evaluation': date.today() - timedelta(days=400),
            'prochaine_evaluation': date.today() - timedelta(days=35),
            'jours_retard': 35
        },
        {
            'polyvalence_id': 2,
            'operateur_id': 2,
            'nom': 'Durand',
            'prenom': 'Marie',
            'matricule': 'OP002',
            'poste_id': 2,
            'poste_code': '0830',
            'nom_atelier': 'Atelier B',
            'niveau': 3,
            'date_evaluation': date.today() - timedelta(days=380),
            'prochaine_evaluation': date.today() - timedelta(days=15),
            'jours_retard': 15
        }
    ])
    def test_get_evaluations_en_retard_with_results(self, mock_fetch):
        """Test récupération des évaluations en retard"""
        from core.services.evaluation_service import get_evaluations_en_retard

        result = get_evaluations_en_retard()

        assert len(result) == 2
        assert result[0]['jours_retard'] == 35
        assert result[0]['nom'] == 'Martin'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_evaluations_en_retard_empty(self, mock_fetch):
        """Test quand aucune évaluation n'est en retard"""
        from core.services.evaluation_service import get_evaluations_en_retard

        result = get_evaluations_en_retard()

        assert result == []


# =============================================================================
# TESTS : GET PROCHAINES EVALUATIONS
# =============================================================================

class TestGetProchainesEvaluations:
    """Tests pour get_prochaines_evaluations"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'operateur_id': 1,
            'nom': 'Martin',
            'prenom': 'Pierre',
            'matricule': 'OP001',
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 2,
            'date_evaluation': date.today() - timedelta(days=335),
            'prochaine_evaluation': date.today() + timedelta(days=15),
            'jours_restants': 15
        }
    ])
    def test_get_prochaines_evaluations_default(self, mock_fetch):
        """Test récupération des évaluations à venir (30 jours par défaut)"""
        from core.services.evaluation_service import get_prochaines_evaluations

        result = get_prochaines_evaluations()

        assert len(result) == 1
        assert result[0]['jours_restants'] == 15

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_prochaines_evaluations_custom_days(self, mock_fetch):
        """Test récupération avec nombre de jours personnalisé"""
        from core.services.evaluation_service import get_prochaines_evaluations

        result = get_prochaines_evaluations(jours=7)

        assert result == []


# =============================================================================
# TESTS : GET EVALUATIONS PAR OPERATEUR
# =============================================================================

class TestGetEvaluationsParOperateur:
    """Tests pour get_evaluations_par_operateur"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 2,
            'date_evaluation': date.today() - timedelta(days=100),
            'prochaine_evaluation': date.today() + timedelta(days=265),
            'statut': 'OK'
        },
        {
            'polyvalence_id': 2,
            'poste_id': 2,
            'poste_code': '0830',
            'nom_atelier': 'Atelier B',
            'niveau': 3,
            'date_evaluation': date.today() - timedelta(days=400),
            'prochaine_evaluation': date.today() - timedelta(days=35),
            'statut': 'RETARD'
        }
    ])
    def test_get_evaluations_par_operateur_with_results(self, mock_fetch):
        """Test récupération des évaluations d'un opérateur"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        result = get_evaluations_par_operateur(operateur_id=1)

        assert len(result) == 2
        assert result[1]['statut'] == 'RETARD'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_evaluations_par_operateur_empty(self, mock_fetch):
        """Test opérateur sans évaluation"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        result = get_evaluations_par_operateur(operateur_id=999)

        assert result == []


# =============================================================================
# TESTS : METTRE A JOUR EVALUATION
# =============================================================================

class TestMettreAJourEvaluation:
    """Tests pour mettre_a_jour_evaluation"""

    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    @patch('core.db.query_executor.QueryExecutor.fetch_one', return_value={
        'operateur_id': 1,
        'poste_id': 1,
        'niveau': 2,
        'date_evaluation': date.today() - timedelta(days=365)
    })
    @patch('core.services.logger.log_hist')
    def test_mettre_a_jour_evaluation_success(self, mock_log, mock_fetch, mock_write):
        """Test mise à jour réussie d'une évaluation"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=3,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is True
        mock_log.assert_called_once()

    def test_mettre_a_jour_evaluation_invalid_niveau(self):
        """Test avec niveau invalide (hors 1-4)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=5,  # Invalide
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False

    def test_mettre_a_jour_evaluation_niveau_zero(self):
        """Test avec niveau 0 (invalide)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=0,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False

    @patch('core.db.query_executor.QueryExecutor.fetch_one', side_effect=Exception("DB Error"))
    def test_mettre_a_jour_evaluation_db_error(self, mock_fetch):
        """Test erreur base de données"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=3,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False


# =============================================================================
# TESTS : NIVEAUX DE COMPETENCE
# =============================================================================

class TestNiveauxCompetence:
    """Tests pour la validation des niveaux de compétence"""

    @pytest.mark.parametrize("niveau", [1, 2, 3, 4])
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    @patch('core.db.query_executor.QueryExecutor.fetch_one', return_value={
        'operateur_id': 1, 'poste_id': 1, 'niveau': 2,
        'date_evaluation': date.today()
    })
    @patch('core.services.logger.log_hist')
    def test_niveaux_valides(self, mock_log, mock_fetch, mock_write, niveau):
        """Test tous les niveaux valides (1-4)"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=niveau,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is True

    @pytest.mark.parametrize("niveau", [-1, 0, 5, 10, 100])
    def test_niveaux_invalides(self, niveau):
        """Test tous les niveaux invalides"""
        from core.services.evaluation_service import mettre_a_jour_evaluation

        result = mettre_a_jour_evaluation(
            polyvalence_id=1,
            nouveau_niveau=niveau,
            date_evaluation=date.today(),
            prochaine_evaluation=date.today() + timedelta(days=365)
        )

        assert result is False


# =============================================================================
# TESTS : STATISTIQUES
# =============================================================================

class TestGetStatistiquesEvaluations:
    """Tests pour get_statistiques_evaluations"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'niveau': 1, 'count': 20},
        {'niveau': 2, 'count': 35},
        {'niveau': 3, 'count': 30},
        {'niveau': 4, 'count': 15}
    ])
    @patch('core.db.query_executor.QueryExecutor.fetch_scalar', side_effect=[100, 10, 15])
    def test_get_statistiques_evaluations(self, mock_scalar, mock_fetch_all):
        """Test récupération des statistiques"""
        from core.services.evaluation_service import get_statistiques_evaluations

        stats = get_statistiques_evaluations()

        assert 'total' in stats
        assert 'en_retard' in stats
        assert 'a_venir_30j' in stats
        assert 'par_niveau' in stats

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    @patch('core.db.query_executor.QueryExecutor.fetch_scalar', side_effect=[0, 0, 0])
    def test_get_statistiques_evaluations_empty(self, mock_scalar, mock_fetch_all):
        """Test statistiques avec base vide"""
        from core.services.evaluation_service import get_statistiques_evaluations

        stats = get_statistiques_evaluations()

        assert stats['total'] == 0
        assert stats['en_retard'] == 0


# =============================================================================
# TESTS : STATUTS D'EVALUATION
# =============================================================================

class TestStatutsEvaluation:
    """Tests pour la logique des statuts d'évaluation"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 2,
            'date_evaluation': date.today() - timedelta(days=400),
            'prochaine_evaluation': date.today() - timedelta(days=35),
            'statut': 'RETARD'
        }
    ])
    def test_statut_retard(self, mock_fetch):
        """Test statut RETARD pour évaluation en retard"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'RETARD'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 2,
            'date_evaluation': date.today() - timedelta(days=335),
            'prochaine_evaluation': date.today() + timedelta(days=25),
            'statut': 'URGENT'
        }
    ])
    def test_statut_urgent(self, mock_fetch):
        """Test statut URGENT pour évaluation dans les 30 prochains jours"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'URGENT'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'polyvalence_id': 1,
            'poste_id': 1,
            'poste_code': '0506',
            'nom_atelier': 'Atelier A',
            'niveau': 3,
            'date_evaluation': date.today() - timedelta(days=100),
            'prochaine_evaluation': date.today() + timedelta(days=265),
            'statut': 'OK'
        }
    ])
    def test_statut_ok(self, mock_fetch):
        """Test statut OK pour évaluation dans les temps"""
        from core.services.evaluation_service import get_evaluations_par_operateur

        result = get_evaluations_par_operateur(operateur_id=1)

        assert result[0]['statut'] == 'OK'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
