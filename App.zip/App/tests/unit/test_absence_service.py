# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service d'absence (absence_service.py)

Couvre:
- Calcul des jours ouvrés
- Gestion des jours fériés
- Création de demandes d'absence
- Validation/Refus des demandes
- Gestion des soldes de congés
- Récupération des demandes et absences
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : CALCUL DES JOURS OUVRES
# =============================================================================

class TestCalculerJoursOuvres:
    """Tests pour calculer_jours_ouvres"""

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_semaine_complete(self, mock_feries):
        """Test calcul d'une semaine complète (lundi-vendredi = 5 jours)"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain lundi
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)
        vendredi = lundi + timedelta(days=4)

        result = calculer_jours_ouvres(lundi, vendredi)

        assert result == 5

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_avec_weekend(self, mock_feries):
        """Test calcul avec weekend inclus (ne compte pas)"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain vendredi
        today = date.today()
        days_until_friday = (4 - today.weekday()) % 7
        if days_until_friday == 0:
            days_until_friday = 7
        vendredi = today + timedelta(days=days_until_friday)
        lundi_suivant = vendredi + timedelta(days=3)

        # Du vendredi au lundi suivant = 2 jours ouvrés (vendredi + lundi)
        result = calculer_jours_ouvres(vendredi, lundi_suivant)

        assert result == 2

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_demi_journee_debut(self, mock_feries):
        """Test avec demi-journée au début"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain lundi
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)
        mardi = lundi + timedelta(days=1)

        result = calculer_jours_ouvres(lundi, mardi, demi_journee_debut='APRES_MIDI')

        assert result == 1.5  # 0.5 + 1

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_demi_journee_fin(self, mock_feries):
        """Test avec demi-journée à la fin"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain lundi
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)
        mardi = lundi + timedelta(days=1)

        result = calculer_jours_ouvres(lundi, mardi, demi_journee_fin='MATIN')

        assert result == 1.5  # 1 + 0.5

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_meme_jour(self, mock_feries):
        """Test pour une seule journée"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain lundi (jour ouvré)
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)

        result = calculer_jours_ouvres(lundi, lundi)

        assert result == 1

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_meme_jour_demi_journee(self, mock_feries):
        """Test pour une demi-journée"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        # Trouver le prochain lundi
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)

        result = calculer_jours_ouvres(
            lundi, lundi,
            demi_journee_debut='MATIN',
            demi_journee_fin='MATIN'
        )

        assert result == 0.5

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_avec_ferie(self, mock_feries):
        """Test avec jour férié"""
        from core.services.absence_service import calculer_jours_ouvres

        # Trouver le prochain lundi
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        lundi = today + timedelta(days=days_until_monday)
        mardi = lundi + timedelta(days=1)
        mercredi = lundi + timedelta(days=2)

        # Le mardi est férié
        mock_feries.return_value = {mardi}

        result = calculer_jours_ouvres(lundi, mercredi)

        assert result == 2  # lundi + mercredi (mardi férié exclu)

    @patch('core.services.absence_service.get_jours_feries')
    def test_calcul_jours_ouvres_date_fin_avant_debut(self, mock_feries):
        """Test avec date fin avant date début"""
        from core.services.absence_service import calculer_jours_ouvres

        mock_feries.return_value = set()

        result = calculer_jours_ouvres(
            date.today() + timedelta(days=5),
            date.today()
        )

        assert result == 0


# =============================================================================
# TESTS : JOURS FERIES
# =============================================================================

class TestGetJoursFeries:
    """Tests pour get_jours_feries"""

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_jours_feries_with_results(self, mock_cursor_class):
        """Test récupération des jours fériés"""
        from core.services.absence_service import get_jours_feries

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            (date(2026, 1, 1),),   # Jour de l'an
            (date(2026, 5, 1),),   # Fête du travail
            (date(2026, 7, 14),),  # Fête nationale
            (date(2026, 12, 25),)  # Noël
        ]

        result = get_jours_feries(2026, 2026)

        assert isinstance(result, set)
        assert len(result) == 4
        assert date(2026, 7, 14) in result

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_jours_feries_empty(self, mock_cursor_class):
        """Test sans jour férié"""
        from core.services.absence_service import get_jours_feries

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = get_jours_feries(2026, 2026)

        assert result == set()


# =============================================================================
# TESTS : CREATION DEMANDE ABSENCE
# =============================================================================

class TestCreerDemandeAbsence:
    """Tests pour creer_demande_absence"""

    @patch('core.services.absence_service.require')  # Mock permission check
    @patch('core.services.absence_service.DatabaseConnection')
    @patch('core.services.absence_service.calculer_jours_ouvres')
    def test_creer_demande_success(self, mock_calc, mock_conn_class, mock_require):
        """Test création de demande réussie"""
        from core.services.absence_service import creer_demande_absence

        mock_calc.return_value = 5  # 5 jours ouvrés

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # Le type d'absence existe
        mock_cursor.fetchone.return_value = (1,)  # type_absence_id = 1
        mock_cursor.lastrowid = 1

        result = creer_demande_absence(
            personnel_id=1,
            type_absence_code='CP',
            date_debut=date.today() + timedelta(days=7),
            date_fin=date.today() + timedelta(days=14)
        )

        assert result == 1
        mock_require.assert_called_once_with('planning.absences.edit')

    @patch('core.services.absence_service.require')  # Mock permission check
    @patch('core.services.absence_service.DatabaseConnection')
    def test_creer_demande_type_inexistant(self, mock_conn_class, mock_require):
        """Test avec type d'absence inexistant"""
        from core.services.absence_service import creer_demande_absence

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        mock_cursor.fetchone.return_value = None  # Type n'existe pas

        with pytest.raises(ValueError, match="introuvable"):
            creer_demande_absence(
                personnel_id=1,
                type_absence_code='INVALID',
                date_debut=date.today() + timedelta(days=7),
                date_fin=date.today() + timedelta(days=14)
            )


# =============================================================================
# TESTS : VALIDATION DEMANDE
# =============================================================================

class TestValiderDemande:
    """Tests pour valider_demande"""

    @patch('core.services.absence_service.require')  # Mock permission check
    @patch('core.services.absence_service.DatabaseConnection')
    @patch('core.services.absence_service.decompter_solde')
    def test_valider_demande_acceptee(self, mock_decompte, mock_conn_class, mock_require):
        """Test validation d'une demande acceptée"""
        from core.services.absence_service import valider_demande

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # Retour pour la requête de type décompté
        mock_cursor.fetchone.return_value = (1, 5.0, 'CP', 2026)  # personnel_id, nb_jours, type_code, annee

        valider_demande(
            demande_id=1,
            validateur_id=2,
            valide=True,
            commentaire="Accepté"
        )

        # Vérifier que le décompte a été appelé
        mock_decompte.assert_called_once_with(1, 2026, 'CP', 5.0)
        mock_require.assert_called_once_with('planning.absences.edit')

    @patch('core.services.absence_service.require')  # Mock permission check
    @patch('core.services.absence_service.DatabaseConnection')
    def test_valider_demande_refusee(self, mock_conn_class, mock_require):
        """Test refus d'une demande"""
        from core.services.absence_service import valider_demande

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # Pas de décompte pour un refus
        mock_cursor.fetchone.return_value = None

        valider_demande(
            demande_id=1,
            validateur_id=2,
            valide=False,
            commentaire="Refusé - période non couverte"
        )

        # Vérifier que UPDATE a été appelé avec statut REFUSEE
        calls = mock_cursor.execute.call_args_list
        assert any("REFUSEE" in str(call) for call in calls)
        mock_require.assert_called_once_with('planning.absences.edit')


# =============================================================================
# TESTS : SOLDE CONGES
# =============================================================================

class TestDecompterSolde:
    """Tests pour decompter_solde"""

    @patch('core.services.absence_service.DatabaseConnection')
    def test_decompter_solde_cp(self, mock_conn_class):
        """Test décompte de congés payés"""
        from core.services.absence_service import decompter_solde

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # Solde existe
        mock_cursor.fetchone.return_value = (1,)

        decompter_solde(personnel_id=1, annee=2026, type_code='CP', nb_jours=5)

        # Vérifier l'UPDATE des CP
        calls = mock_cursor.execute.call_args_list
        assert any("cp_pris" in str(call) for call in calls)

    @patch('core.services.absence_service.DatabaseConnection')
    def test_decompter_solde_rtt(self, mock_conn_class):
        """Test décompte de RTT"""
        from core.services.absence_service import decompter_solde

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        mock_cursor.fetchone.return_value = (1,)

        decompter_solde(personnel_id=1, annee=2026, type_code='RTT', nb_jours=1)

        calls = mock_cursor.execute.call_args_list
        assert any("rtt_pris" in str(call) for call in calls)

    @patch('core.services.absence_service.DatabaseConnection')
    def test_decompter_solde_creation_si_inexistant(self, mock_conn_class):
        """Test création du solde s'il n'existe pas"""
        from core.services.absence_service import decompter_solde

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # Solde n'existe pas
        mock_cursor.fetchone.return_value = None

        decompter_solde(personnel_id=1, annee=2026, type_code='CP', nb_jours=5)

        # Vérifier l'INSERT pour créer le solde
        calls = mock_cursor.execute.call_args_list
        assert any("INSERT INTO solde_conges" in str(call) for call in calls)


class TestGetSoldeConges:
    """Tests pour get_solde_conges"""

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_solde_conges_exists(self, mock_cursor_class):
        """Test récupération solde existant"""
        from core.services.absence_service import get_solde_conges

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'cp_acquis': 25,
            'cp_n_1': 5,
            'cp_pris': 10,
            'cp_restant': 20,
            'rtt_acquis': 10,
            'rtt_pris': 2,
            'rtt_restant': 8
        }

        result = get_solde_conges(personnel_id=1, annee=2026)

        assert result['cp_acquis'] == 25
        assert result['cp_restant'] == 20
        assert result['rtt_restant'] == 8

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_solde_conges_not_exists(self, mock_cursor_class):
        """Test récupération solde inexistant (retourne zéros)"""
        from core.services.absence_service import get_solde_conges

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = None

        result = get_solde_conges(personnel_id=999, annee=2026)

        assert result['cp_acquis'] == 0
        assert result['cp_restant'] == 0
        assert result['rtt_restant'] == 0


# =============================================================================
# TESTS : RECUPERATION DEMANDES
# =============================================================================

class TestGetDemandesPersonnel:
    """Tests pour get_demandes_personnel"""

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_demandes_all(self, mock_cursor_class):
        """Test récupération de toutes les demandes"""
        from core.services.absence_service import get_demandes_personnel

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'date_debut': date.today(),
                'date_fin': date.today() + timedelta(days=5),
                'nb_jours': 5,
                'statut': 'VALIDEE',
                'type_code': 'CP'
            },
            {
                'id': 2,
                'date_debut': date.today() + timedelta(days=30),
                'date_fin': date.today() + timedelta(days=35),
                'nb_jours': 5,
                'statut': 'EN_ATTENTE',
                'type_code': 'CP'
            }
        ]

        result = get_demandes_personnel(personnel_id=1)

        assert len(result) == 2

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_demandes_filter_annee(self, mock_cursor_class):
        """Test filtrage par année"""
        from core.services.absence_service import get_demandes_personnel

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'statut': 'VALIDEE'}
        ]

        result = get_demandes_personnel(personnel_id=1, annee=2026)

        # Vérifier que le filtre année est dans la requête
        call_args = mock_cursor.execute.call_args
        assert "YEAR" in str(call_args)

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_demandes_filter_statut(self, mock_cursor_class):
        """Test filtrage par statut"""
        from core.services.absence_service import get_demandes_personnel

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'statut': 'EN_ATTENTE'}
        ]

        result = get_demandes_personnel(personnel_id=1, statut='EN_ATTENTE')

        assert len(result) == 1


class TestGetAbsencesPeriode:
    """Tests pour get_absences_periode"""

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_absences_periode(self, mock_cursor_class):
        """Test récupération des absences sur une période"""
        from core.services.absence_service import get_absences_periode

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'personnel_id': 1,
                'nom_complet': 'Jean Dupont',
                'date_debut': date.today(),
                'date_fin': date.today() + timedelta(days=5),
                'type_code': 'CP',
                'couleur': '#4CAF50'
            }
        ]

        result = get_absences_periode(
            date_debut=date.today() - timedelta(days=7),
            date_fin=date.today() + timedelta(days=30)
        )

        assert len(result) == 1
        assert result[0]['nom_complet'] == 'Jean Dupont'


# =============================================================================
# TESTS : INITIALISATION SOLDES
# =============================================================================

class TestInitialiserSoldesAnnee:
    """Tests pour initialiser_soldes_annee"""

    @patch('core.services.absence_service.DatabaseConnection')
    def test_initialiser_soldes_success(self, mock_conn_class):
        """Test initialisation des soldes pour l'année"""
        from core.services.absence_service import initialiser_soldes_annee

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        # 3 personnel actifs
        mock_cursor.fetchall.return_value = [(1,), (2,), (3,)]
        # Aucun solde existant
        mock_cursor.fetchone.return_value = None

        result = initialiser_soldes_annee(annee=2026)

        assert result == 3

    @patch('core.services.absence_service.DatabaseConnection')
    def test_initialiser_soldes_custom_values(self, mock_conn_class):
        """Test initialisation avec valeurs personnalisées"""
        from core.services.absence_service import initialiser_soldes_annee

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        mock_cursor.fetchall.return_value = [(1,)]
        mock_cursor.fetchone.return_value = None

        initialiser_soldes_annee(annee=2026, cp_standard=30, rtt_standard=12)

        # Vérifier les valeurs dans l'INSERT
        calls = mock_cursor.execute.call_args_list
        insert_call = [c for c in calls if "INSERT INTO solde_conges" in str(c)]
        assert len(insert_call) > 0


# =============================================================================
# TESTS : TYPES ABSENCE
# =============================================================================

class TestGetTypesAbsence:
    """Tests pour get_types_absence"""

    @patch('core.services.absence_service.DatabaseCursor')
    def test_get_types_absence(self, mock_cursor_class):
        """Test récupération des types d'absence actifs"""
        from core.services.absence_service import get_types_absence

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'code': 'CP', 'libelle': 'Congés payés', 'decompte_solde': True, 'couleur': '#4CAF50'},
            {'id': 2, 'code': 'RTT', 'libelle': 'RTT', 'decompte_solde': True, 'couleur': '#2196F3'},
            {'id': 3, 'code': 'MAL', 'libelle': 'Maladie', 'decompte_solde': False, 'couleur': '#F44336'}
        ]

        result = get_types_absence()

        assert len(result) == 3
        assert result[0]['code'] == 'CP'


# =============================================================================
# TESTS : ALIAS
# =============================================================================

class TestAbsenceAliases:
    """Tests pour les alias de compatibilité"""

    @patch('core.services.absence_service.get_absences_periode')
    def test_alias_get_absences_actuelles(self, mock_func):
        """Test alias get_absences_actuelles"""
        from core.services.absence_service import get_absences_actuelles

        mock_func.return_value = [{'id': 1}]

        result = get_absences_actuelles()

        mock_func.assert_called_once()
        assert result == [{'id': 1}]


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
