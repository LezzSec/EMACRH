# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service d'absence (absence_service_crud.py)

Couvre:
- Récupération des absences par personnel
- Récupération par statut
- Validation/Refus/Annulation des demandes
- Comptage des absences
- Récupération des types d'absence
- Récupération des absences avec détails
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : GET BY PERSONNEL
# =============================================================================

class TestGetByPersonnel:
    """Tests pour AbsenceServiceCRUD.get_by_personnel"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'id': 1,
            'personnel_id': 1,
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=5),
            'nb_jours': 5.0,
            'statut': 'VALIDEE',
            'type_absence_code': 'CP'
        },
        {
            'id': 2,
            'personnel_id': 1,
            'date_debut': date.today() + timedelta(days=30),
            'date_fin': date.today() + timedelta(days=35),
            'nb_jours': 5.0,
            'statut': 'EN_ATTENTE',
            'type_absence_code': 'CP'
        }
    ])
    def test_get_by_personnel_with_results(self, mock_fetch):
        """Test récupération des absences d'un personnel"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_by_personnel(personnel_id=1)

        assert len(result) == 2
        assert result[0]['personnel_id'] == 1

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_by_personnel_empty(self, mock_fetch):
        """Test personnel sans absence"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_by_personnel(personnel_id=999)

        assert result == []


# =============================================================================
# TESTS : GET BY STATUT
# =============================================================================

class TestGetByStatut:
    """Tests pour AbsenceServiceCRUD.get_by_statut"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'statut': 'EN_ATTENTE', 'personnel_id': 1},
        {'id': 2, 'statut': 'EN_ATTENTE', 'personnel_id': 2}
    ])
    def test_get_en_attente(self, mock_fetch):
        """Test récupération des absences en attente"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_en_attente()

        assert len(result) == 2
        assert all(r['statut'] == 'EN_ATTENTE' for r in result)

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'statut': 'VALIDEE', 'personnel_id': 1}
    ])
    def test_get_validees(self, mock_fetch):
        """Test récupération des absences validées"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_validees()

        assert len(result) == 1
        assert result[0]['statut'] == 'VALIDEE'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'statut': 'REFUSEE', 'personnel_id': 1}
    ])
    def test_get_refusees(self, mock_fetch):
        """Test récupération des absences refusées"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_refusees()

        assert len(result) == 1
        assert result[0]['statut'] == 'REFUSEE'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_by_statut_empty(self, mock_fetch):
        """Test statut sans résultat"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_by_statut('EN_ATTENTE')

        assert result == []


# =============================================================================
# TESTS : VALIDER ABSENCE
# =============================================================================

class TestValiderAbsence:
    """Tests pour AbsenceServiceCRUD.valider"""

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_valider_success(self, mock_write, mock_log):
        """Test validation réussie d'une absence"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.valider(record_id=1, valideur_id=5)

        assert success is True
        assert mock_write.called

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_valider_sans_valideur(self, mock_write, mock_log):
        """Test validation sans spécifier de valideur"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.valider(record_id=1)

        assert success is True

    @patch('core.db.query_executor.QueryExecutor.execute_write',
           side_effect=Exception("DB Error"))
    def test_valider_db_error(self, mock_write):
        """Test erreur DB lors de la validation"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.valider(record_id=1)

        assert success is False


# =============================================================================
# TESTS : REFUSER ABSENCE
# =============================================================================

class TestRefuserAbsence:
    """Tests pour AbsenceServiceCRUD.refuser"""

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_refuser_success(self, mock_write, mock_log):
        """Test refus réussi d'une absence"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.refuser(
            record_id=1,
            commentaire="Période non couverte",
            valideur_id=5
        )

        assert success is True

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_refuser_sans_commentaire(self, mock_write, mock_log):
        """Test refus sans commentaire"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.refuser(record_id=1)

        assert success is True


# =============================================================================
# TESTS : ANNULER ABSENCE
# =============================================================================

class TestAnnulerAbsence:
    """Tests pour AbsenceServiceCRUD.annuler"""

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_annuler_success(self, mock_write, mock_log):
        """Test annulation réussie"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.annuler(record_id=1)

        assert success is True

    @patch('core.services.logger.log_hist')
    @patch('core.db.query_executor.QueryExecutor.execute_write', return_value=None)
    def test_annuler_avec_commentaire(self, mock_write, mock_log):
        """Test annulation avec commentaire"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        success, message = AbsenceServiceCRUD.annuler(
            record_id=1,
            commentaire="Annulation à la demande du salarié"
        )

        assert success is True


# =============================================================================
# TESTS : COMPTAGE
# =============================================================================

class TestComptage:
    """Tests pour les méthodes de comptage"""

    @patch('core.db.query_executor.QueryExecutor.count', return_value=5)
    def test_count_by_personnel(self, mock_count):
        """Test comptage des absences d'un personnel"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.count_by_personnel(personnel_id=1)

        assert result == 5
        assert mock_count.called

    @patch('core.db.query_executor.QueryExecutor.count', return_value=3)
    def test_count_by_personnel_avec_statut(self, mock_count):
        """Test comptage avec filtre de statut"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.count_by_personnel(personnel_id=1, statut='VALIDEE')

        assert result == 3

    @patch('core.db.query_executor.QueryExecutor.count', return_value=0)
    def test_count_by_personnel_zero(self, mock_count):
        """Test comptage avec zéro résultat"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.count_by_personnel(personnel_id=999)

        assert result == 0

    @patch('core.db.query_executor.QueryExecutor.count', return_value=7)
    def test_count_by_statut(self, mock_count):
        """Test comptage par statut"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.count_by_statut('EN_ATTENTE')

        assert result == 7
        assert mock_count.called


# =============================================================================
# TESTS : TYPES D'ABSENCE
# =============================================================================

class TestTypesAbsence:
    """Tests pour get_types_absence"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'code': 'CP', 'libelle': 'Congés payés'},
        {'id': 2, 'code': 'RTT', 'libelle': 'RTT'},
        {'id': 3, 'code': 'MAL', 'libelle': 'Maladie'}
    ])
    def test_get_types_absence(self, mock_fetch):
        """Test récupération des types d'absence actifs"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_types_absence()

        assert len(result) == 3
        assert result[0]['code'] == 'CP'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_types_absence_empty(self, mock_fetch):
        """Test sans types d'absence"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_types_absence()

        assert result == []


# =============================================================================
# TESTS : ABSENCES AVEC DETAILS
# =============================================================================

class TestAbsencesAvecDetails:
    """Tests pour get_en_attente_with_details et get_validees_pour_mois"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'id': 1,
            'nom_complet': 'Jean Dupont',
            'type_libelle': 'Congés payés',
            'date_debut': date.today() + timedelta(days=7),
            'date_fin': date.today() + timedelta(days=14),
            'nb_jours': 5.0,
            'motif': 'Vacances'
        }
    ])
    def test_get_en_attente_with_details(self, mock_fetch):
        """Test récupération des demandes en attente avec détails"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_en_attente_with_details()

        assert len(result) == 1
        assert result[0]['nom_complet'] == 'Jean Dupont'
        assert result[0]['type_libelle'] == 'Congés payés'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=5),
            'nom_complet': 'Marie Martin',
            'type_libelle': 'RTT',
            'statut': 'VALIDEE'
        }
    ])
    def test_get_validees_pour_mois(self, mock_fetch):
        """Test récupération des absences validées pour un mois"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        from datetime import date
        first_day = date.today().replace(day=1)
        last_day = date.today()

        result = AbsenceServiceCRUD.get_validees_pour_mois(first_day, last_day)

        assert len(result) == 1
        assert result[0]['statut'] == 'VALIDEE'


# =============================================================================
# TESTS : STATUTS DISPONIBLES
# =============================================================================

class TestStatutsDisponibles:
    """Tests pour les différents statuts d'absence"""

    @pytest.mark.parametrize("statut", ['EN_ATTENTE', 'VALIDEE', 'REFUSEE', 'ANNULEE'])
    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_get_by_statuts_valides(self, mock_fetch, statut):
        """Test que tous les statuts sont acceptés"""
        from core.services.absence_service_crud import AbsenceServiceCRUD

        result = AbsenceServiceCRUD.get_by_statut(statut)

        assert isinstance(result, list)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
