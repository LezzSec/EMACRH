# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service de contrat (contrat_service.py)

Couvre:
- Validation des dates de contrat
- Validation de l'ETP
- Opérations CRUD (Create, Read, Update, Delete)
- Récupération des contrats actifs
- Détection des contrats expirant
- Statistiques des contrats
- Types de contrats et catégories
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : VALIDATION DES DATES
# =============================================================================

class TestValidateContractDates:
    """Tests pour validate_contract_dates"""

    def test_dates_valid_no_end_date(self):
        """Test dates valides sans date de fin (CDI)"""
        from core.services.contrat_service import validate_contract_dates

        valid, message = validate_contract_dates(
            date_debut=date.today() - timedelta(days=30),
            date_fin=None
        )

        assert valid is True
        assert message == ""

    def test_dates_valid_with_end_date(self):
        """Test dates valides avec date de fin"""
        from core.services.contrat_service import validate_contract_dates

        valid, message = validate_contract_dates(
            date_debut=date.today(),
            date_fin=date.today() + timedelta(days=180)
        )

        assert valid is True
        assert message == ""

    def test_dates_invalid_no_start(self):
        """Test date de début manquante"""
        from core.services.contrat_service import validate_contract_dates

        valid, message = validate_contract_dates(
            date_debut=None,
            date_fin=date.today() + timedelta(days=30)
        )

        assert valid is False
        assert "début" in message.lower()

    def test_dates_invalid_end_before_start(self):
        """Test date de fin avant date de début"""
        from core.services.contrat_service import validate_contract_dates

        valid, message = validate_contract_dates(
            date_debut=date.today(),
            date_fin=date.today() - timedelta(days=30)
        )

        assert valid is False
        assert "antérieure" in message

    def test_dates_invalid_end_in_past(self):
        """Test date de fin dans le passé"""
        from core.services.contrat_service import validate_contract_dates

        valid, message = validate_contract_dates(
            date_debut=date.today() - timedelta(days=60),
            date_fin=date.today() - timedelta(days=1)
        )

        assert valid is False
        assert "passé" in message


# =============================================================================
# TESTS : VALIDATION ETP
# =============================================================================

class TestValidateEtp:
    """Tests pour validate_etp"""

    def test_etp_valid_full_time(self):
        """Test ETP temps plein (1.0)"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(1.0)

        assert valid is True
        assert message == ""

    def test_etp_valid_part_time(self):
        """Test ETP temps partiel (0.5)"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(0.5)

        assert valid is True
        assert message == ""

    def test_etp_valid_null(self):
        """Test ETP null (optionnel)"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(None)

        assert valid is True
        assert message == ""

    def test_etp_invalid_zero(self):
        """Test ETP égal à 0 (invalide)"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(0)

        assert valid is False
        assert "0 et 1" in message

    def test_etp_invalid_negative(self):
        """Test ETP négatif"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(-0.5)

        assert valid is False

    def test_etp_invalid_over_one(self):
        """Test ETP supérieur à 1"""
        from core.services.contrat_service import validate_etp

        valid, message = validate_etp(1.5)

        assert valid is False


# =============================================================================
# TESTS : VALIDATION CONTRAT COMPLET
# =============================================================================

class TestValidateContractData:
    """Tests pour validate_contract_data"""

    def test_valid_contract_cdi(self):
        """Test contrat CDI valide"""
        from core.services.contrat_service import validate_contract_data

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDI',
            'date_debut': date.today(),
            'date_fin': None,
            'etp': 1.0
        }

        valid, message = validate_contract_data(data)

        assert valid is True
        assert message == ""

    def test_valid_contract_cdd(self):
        """Test contrat CDD valide"""
        from core.services.contrat_service import validate_contract_data

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDD',
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=180),
            'etp': 1.0
        }

        valid, message = validate_contract_data(data)

        assert valid is True
        assert message == ""

    def test_invalid_contract_no_type(self):
        """Test contrat sans type"""
        from core.services.contrat_service import validate_contract_data

        data = {
            'operateur_id': 1,
            'type_contrat': None,
            'date_debut': date.today()
        }

        valid, message = validate_contract_data(data)

        assert valid is False
        assert "type" in message.lower()

    def test_invalid_contract_no_operateur(self):
        """Test contrat sans opérateur"""
        from core.services.contrat_service import validate_contract_data

        data = {
            'type_contrat': 'CDI',
            'date_debut': date.today()
        }

        valid, message = validate_contract_data(data)

        assert valid is False
        assert "opérateur" in message.lower()


# =============================================================================
# TESTS : CRUD OPERATIONS
# =============================================================================

class TestCreateContract:
    """Tests pour create_contract"""

    @patch('core.services.contrat_service.DatabaseConnection')
    def test_create_contract_success(self, mock_conn_class):
        """Test création de contrat réussie"""
        from core.services.contrat_service import create_contract

        # Setup mock
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.lastrowid = 1

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDI',
            'date_debut': date.today(),
            'date_fin': None,
            'etp': 1.0
        }

        success, message, contract_id = create_contract(data)

        assert success is True
        assert contract_id == 1
        assert "succès" in message

    def test_create_contract_invalid_data(self):
        """Test création avec données invalides"""
        from core.services.contrat_service import create_contract

        data = {
            'type_contrat': 'CDI',
            # operateur_id manquant
            'date_debut': date.today()
        }

        success, message, contract_id = create_contract(data)

        assert success is False
        assert contract_id is None

    @patch('core.services.contrat_service.DatabaseConnection')
    def test_create_contract_db_error(self, mock_conn_class):
        """Test création avec erreur DB"""
        from core.services.contrat_service import create_contract

        mock_conn_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDI',
            'date_debut': date.today()
        }

        success, message, contract_id = create_contract(data)

        assert success is False
        assert contract_id is None


class TestUpdateContract:
    """Tests pour update_contract"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_update_contract_success(self, mock_cursor_class):
        """Test mise à jour réussie"""
        from core.services.contrat_service import update_contract

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDD',
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=180),
            'etp': 0.8
        }

        success, message = update_contract(1, data)

        assert success is True
        assert "succès" in message

    def test_update_contract_invalid_data(self):
        """Test mise à jour avec données invalides"""
        from core.services.contrat_service import update_contract

        data = {
            # operateur_id manquant
            'type_contrat': 'CDD',
            'date_debut': date.today()
        }

        success, message = update_contract(1, data)

        assert success is False


class TestDeleteContract:
    """Tests pour delete_contract"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_delete_contract_success(self, mock_cursor_class):
        """Test suppression (soft delete) réussie"""
        from core.services.contrat_service import delete_contract

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        success, message = delete_contract(1)

        assert success is True
        assert "désactivé" in message

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_delete_contract_db_error(self, mock_cursor_class):
        """Test suppression avec erreur DB"""
        from core.services.contrat_service import delete_contract

        mock_cursor_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        success, message = delete_contract(1)

        assert success is False


# =============================================================================
# TESTS : QUERIES
# =============================================================================

class TestGetActiveContract:
    """Tests pour get_active_contract"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_active_contract_found(self, mock_cursor_class):
        """Test récupération contrat actif existant"""
        from core.services.contrat_service import get_active_contract

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'operateur_id': 1,
                'type_contrat': 'CDI',
                'date_debut': date.today() - timedelta(days=365),
                'date_fin': None,
                'actif': 1,
                'nom': 'Dupont',
                'prenom': 'Jean'
            }
        ]

        result = get_active_contract(operateur_id=1)

        assert result is not None
        assert result['type_contrat'] == 'CDI'

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_active_contract_not_found(self, mock_cursor_class):
        """Test récupération contrat actif inexistant"""
        from core.services.contrat_service import get_active_contract

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = get_active_contract(operateur_id=999)

        assert result is None


class TestGetAllContracts:
    """Tests pour get_all_contracts"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_all_contracts_active_only(self, mock_cursor_class):
        """Test récupération contrats actifs uniquement"""
        from core.services.contrat_service import get_all_contracts

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'type_contrat': 'CDI', 'actif': 1},
            {'id': 2, 'type_contrat': 'CDD', 'actif': 1}
        ]

        result = get_all_contracts(operateur_id=1, include_inactive=False)

        assert len(result) == 2

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_all_contracts_include_inactive(self, mock_cursor_class):
        """Test récupération tous contrats (actifs et inactifs)"""
        from core.services.contrat_service import get_all_contracts

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'type_contrat': 'CDI', 'actif': 1},
            {'id': 2, 'type_contrat': 'CDD', 'actif': 0},
            {'id': 3, 'type_contrat': 'CDD', 'actif': 1}
        ]

        result = get_all_contracts(operateur_id=1, include_inactive=True)

        assert len(result) == 3


# =============================================================================
# TESTS : CONTRATS EXPIRANTS
# =============================================================================

class TestGetExpiringContracts:
    """Tests pour get_expiring_contracts"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_expiring_contracts_default(self, mock_cursor_class):
        """Test récupération contrats expirant (30 jours par défaut)"""
        from core.services.contrat_service import get_expiring_contracts

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'type_contrat': 'CDD',
                'date_fin': date.today() + timedelta(days=15),
                'jours_restants': 15,
                'nom': 'Dupont',
                'prenom': 'Jean'
            },
            {
                'id': 2,
                'type_contrat': 'CDD',
                'date_fin': date.today() + timedelta(days=25),
                'jours_restants': 25,
                'nom': 'Martin',
                'prenom': 'Marie'
            }
        ]

        result = get_expiring_contracts()

        assert len(result) == 2
        # Triés par date de fin (le plus proche en premier)
        assert result[0]['jours_restants'] == 15

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_expiring_contracts_custom_days(self, mock_cursor_class):
        """Test avec nombre de jours personnalisé"""
        from core.services.contrat_service import get_expiring_contracts

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {
                'id': 1,
                'type_contrat': 'CDD',
                'date_fin': date.today() + timedelta(days=5),
                'jours_restants': 5,
                'nom': 'Dupont',
                'prenom': 'Jean'
            }
        ]

        result = get_expiring_contracts(days=7)

        assert len(result) == 1
        assert result[0]['jours_restants'] == 5

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_expiring_contracts_empty(self, mock_cursor_class):
        """Test quand aucun contrat n'expire"""
        from core.services.contrat_service import get_expiring_contracts

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = get_expiring_contracts()

        assert result == []


# =============================================================================
# TESTS : STATISTIQUES
# =============================================================================

class TestGetContractStatistics:
    """Tests pour get_contract_statistics"""

    @patch('core.services.contrat_service.DatabaseCursor')
    def test_get_contract_statistics(self, mock_cursor_class):
        """Test récupération des statistiques"""
        from core.services.contrat_service import get_contract_statistics

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        # Mock des résultats successifs
        mock_cursor.fetchall.side_effect = [
            [{'total': 50}],  # Total actifs
            [
                {'type_contrat': 'CDI', 'count': 30},
                {'type_contrat': 'CDD', 'count': 15},
                {'type_contrat': 'Intérimaire', 'count': 5}
            ],  # Par type
            [{'total': 3}],  # Expiration 30j
            [{'total': 1}]   # Expirés
        ]

        stats = get_contract_statistics()

        assert 'total_actifs' in stats
        assert 'par_type' in stats
        assert 'expiration_30j' in stats
        assert 'expires' in stats


# =============================================================================
# TESTS : HELPERS
# =============================================================================

class TestContractHelpers:
    """Tests pour les fonctions helper"""

    def test_get_contract_types(self):
        """Test récupération des types de contrat"""
        from core.services.contrat_service import get_contract_types

        types = get_contract_types()

        assert isinstance(types, list)
        assert 'CDI' in types
        assert 'CDD' in types
        assert 'Intérimaire' in types
        assert 'Apprentissage' in types

    def test_get_categories(self):
        """Test récupération des catégories"""
        from core.services.contrat_service import get_categories

        categories = get_categories()

        assert isinstance(categories, list)
        assert 'Ouvrier' in categories
        assert 'Cadre' in categories


# =============================================================================
# TESTS : ALIASES
# =============================================================================

class TestContractAliases:
    """Tests pour les alias de compatibilité"""

    @patch('core.services.contrat_service.get_expiring_contracts')
    def test_alias_get_contrats_expirant_bientot(self, mock_func):
        """Test alias get_contrats_expirant_bientot"""
        from core.services.contrat_service import get_contrats_expirant_bientot

        mock_func.return_value = [{'id': 1}]

        result = get_contrats_expirant_bientot(days=30)

        mock_func.assert_called_once_with(30)
        assert result == [{'id': 1}]

    @patch('core.services.contrat_service.get_all_active_contracts')
    def test_alias_get_tous_contrats(self, mock_func):
        """Test alias get_tous_contrats"""
        from core.services.contrat_service import get_tous_contrats

        mock_func.return_value = [{'id': 1}, {'id': 2}]

        result = get_tous_contrats()

        mock_func.assert_called_once()
        assert len(result) == 2


# =============================================================================
# TESTS : SCENARIOS METIER
# =============================================================================

class TestBusinessScenarios:
    """Tests pour les scénarios métier"""

    @patch('core.services.contrat_service.DatabaseConnection')
    def test_create_contract_deactivates_previous(self, mock_conn_class):
        """Test que créer un contrat désactive les précédents"""
        from core.services.contrat_service import create_contract

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn_class.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor
        mock_cursor.lastrowid = 2

        data = {
            'operateur_id': 1,
            'type_contrat': 'CDD',
            'date_debut': date.today(),
            'date_fin': date.today() + timedelta(days=180)
        }

        success, _, _ = create_contract(data)

        # Vérifier que UPDATE pour désactiver a été appelé
        calls = mock_cursor.execute.call_args_list
        assert any("actif = 0" in str(call) for call in calls)

    def test_contract_types_comprehensive(self):
        """Test que tous les types de contrats attendus sont présents"""
        from core.services.contrat_service import get_contract_types

        types = get_contract_types()
        expected_types = ['CDI', 'CDD', 'Stagiaire', 'Apprentissage', 'Intérimaire']

        for expected in expected_types:
            assert expected in types, f"Type {expected} manquant"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
