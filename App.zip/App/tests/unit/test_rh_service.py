# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service RH (rh_service.py)

Couvre:
- Recherche d'opérateurs
- Récupération des données par domaine (général, contrat, compétences, etc.)
- Mapping des catégories de documents
- Gestion des différents domaines RH
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : DOMAINES RH
# =============================================================================

class TestDomaineRH:
    """Tests pour l'énumération DomaineRH"""

    def test_domaines_disponibles(self):
        """Test que tous les domaines RH sont disponibles"""
        from core.services.rh_service import DomaineRH

        expected_domaines = [
            'GENERAL', 'CONTRAT', 'DECLARATION',
            'COMPETENCES', 'FORMATION', 'MEDICAL', 'VIE_SALARIE'
        ]

        for domaine in expected_domaines:
            assert hasattr(DomaineRH, domaine), f"Domaine {domaine} manquant"

    def test_domaine_values(self):
        """Test les valeurs des domaines"""
        from core.services.rh_service import DomaineRH

        assert DomaineRH.GENERAL.value == "general"
        assert DomaineRH.CONTRAT.value == "contrat"
        assert DomaineRH.COMPETENCES.value == "competences"


class TestCategorieMapping:
    """Tests pour le mapping catégories -> domaines"""

    def test_mapping_contrat(self):
        """Test mapping catégorie contrat"""
        from core.services.rh_service import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Contrats de travail"] == DomaineRH.CONTRAT

    def test_mapping_medical(self):
        """Test mapping catégorie médical"""
        from core.services.rh_service import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Certificats médicaux"] == DomaineRH.MEDICAL

    def test_mapping_formation(self):
        """Test mapping catégorie formation"""
        from core.services.rh_service import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Diplômes et formations"] == DomaineRH.FORMATION


# =============================================================================
# TESTS : RECHERCHE OPERATEURS
# =============================================================================

class TestRechercherOperateurs:
    """Tests pour rechercher_operateurs"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_tous_actifs(self, mock_cursor_class):
        """Test recherche de tous les opérateurs actifs"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'},
            {'id': 2, 'nom': 'Martin', 'prenom': 'Marie', 'matricule': 'OP002', 'statut': 'ACTIF'}
        ]

        result = rechercher_operateurs()

        assert len(result) == 2
        assert result[0]['nom'] == 'Dupont'

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_par_nom(self, mock_cursor_class):
        """Test recherche par nom"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'}
        ]

        result = rechercher_operateurs(recherche="Dupont")

        assert len(result) == 1
        # Vérifier que la recherche LIKE est utilisée
        call_args = mock_cursor.execute.call_args
        assert "LIKE" in call_args[0][0]

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_par_matricule(self, mock_cursor_class):
        """Test recherche par matricule"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'}
        ]

        result = rechercher_operateurs(recherche="OP001")

        assert len(result) == 1

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_inactifs(self, mock_cursor_class):
        """Test recherche des inactifs uniquement"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 3, 'nom': 'Durand', 'prenom': 'Pierre', 'matricule': 'OP003', 'statut': 'INACTIF'}
        ]

        result = rechercher_operateurs(statut="INACTIF")

        assert len(result) == 1
        assert result[0]['statut'] == 'INACTIF'

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_tous_statuts(self, mock_cursor_class):
        """Test recherche sans filtre de statut"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'nom': 'Dupont', 'statut': 'ACTIF'},
            {'id': 2, 'nom': 'Martin', 'statut': 'INACTIF'}
        ]

        result = rechercher_operateurs(statut=None)

        assert len(result) == 2

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_avec_limite(self, mock_cursor_class):
        """Test recherche avec limite personnalisée"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [{'id': 1}]

        result = rechercher_operateurs(limit=10)

        # Vérifier que LIMIT est dans la requête
        call_args = mock_cursor.execute.call_args
        assert "LIMIT" in call_args[0][0]

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_vide(self, mock_cursor_class):
        """Test recherche sans résultat"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        result = rechercher_operateurs(recherche="Inexistant")

        assert result == []


# =============================================================================
# TESTS : GET OPERATEUR
# =============================================================================

class TestGetOperateurById:
    """Tests pour get_operateur_by_id"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_operateur_found(self, mock_cursor_class):
        """Test récupération opérateur existant"""
        from core.services.rh_service import get_operateur_by_id

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'id': 1,
            'nom': 'Dupont',
            'prenom': 'Jean',
            'matricule': 'OP001',
            'statut': 'ACTIF',
            'nom_complet': 'Jean Dupont'
        }

        result = get_operateur_by_id(1)

        assert result is not None
        assert result['nom'] == 'Dupont'
        assert result['nom_complet'] == 'Jean Dupont'

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_operateur_not_found(self, mock_cursor_class):
        """Test opérateur non trouvé"""
        from core.services.rh_service import get_operateur_by_id

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = None

        result = get_operateur_by_id(999)

        assert result is None

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_operateur_db_error(self, mock_cursor_class):
        """Test gestion erreur DB"""
        from core.services.rh_service import get_operateur_by_id

        mock_cursor_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        result = get_operateur_by_id(1)

        assert result is None


class TestGetOperateurByMatricule:
    """Tests pour get_operateur_by_matricule"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_by_matricule_found(self, mock_cursor_class):
        """Test récupération par matricule existant"""
        from core.services.rh_service import get_operateur_by_matricule

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'id': 1,
            'nom': 'Dupont',
            'matricule': 'OP001'
        }

        result = get_operateur_by_matricule('OP001')

        assert result is not None
        assert result['matricule'] == 'OP001'

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_by_matricule_not_found(self, mock_cursor_class):
        """Test matricule non trouvé"""
        from core.services.rh_service import get_operateur_by_matricule

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = None

        result = get_operateur_by_matricule('UNKNOWN')

        assert result is None


# =============================================================================
# TESTS : DONNEES GENERALES
# =============================================================================

class TestGetDonneesGenerales:
    """Tests pour la récupération des données générales"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_donnees_generales(self, mock_cursor_class):
        """Test récupération données générales"""
        # Import dynamique car la fonction peut avoir un nom différent
        try:
            from core.services.rh_service import get_donnees_generales
        except ImportError:
            pytest.skip("Fonction get_donnees_generales non disponible")

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'id': 1,
            'nom': 'Dupont',
            'prenom': 'Jean',
            'date_naissance': date(1985, 5, 15),
            'adresse': '123 Rue Test'
        }

        result = get_donnees_generales(1)

        assert result is not None


# =============================================================================
# TESTS : CONTRATS
# =============================================================================

class TestGetContratOperateur:
    """Tests pour la récupération des contrats via service RH"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_contrat_actif(self, mock_cursor_class):
        """Test récupération contrat actif"""
        try:
            from core.services.rh_service import get_contrat_actif
        except ImportError:
            pytest.skip("Fonction get_contrat_actif non disponible")

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'id': 1,
            'type_contrat': 'CDI',
            'date_debut': date.today() - timedelta(days=365),
            'actif': 1
        }

        result = get_contrat_actif(1)

        assert result is not None
        assert result['type_contrat'] == 'CDI'


# =============================================================================
# TESTS : COMPETENCES
# =============================================================================

class TestGetCompetences:
    """Tests pour la récupération des compétences"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_competences_operateur(self, mock_cursor_class):
        """Test récupération compétences/polyvalence"""
        try:
            from core.services.rh_service import get_competences_operateur
        except ImportError:
            pytest.skip("Fonction get_competences_operateur non disponible")

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'poste_code': '0506', 'niveau': 3, 'nom_atelier': 'Atelier A'},
            {'poste_code': '0830', 'niveau': 2, 'nom_atelier': 'Atelier B'}
        ]

        result = get_competences_operateur(1)

        assert len(result) == 2


# =============================================================================
# TESTS : FORMATIONS
# =============================================================================

class TestGetFormations:
    """Tests pour la récupération des formations"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_formations_operateur(self, mock_cursor_class):
        """Test récupération des formations"""
        try:
            from core.services.rh_service import get_formations_operateur
        except ImportError:
            pytest.skip("Fonction get_formations_operateur non disponible")

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchall.return_value = [
            {'id': 1, 'nom_formation': 'Sécurité', 'date_formation': date.today()},
            {'id': 2, 'nom_formation': 'Qualité', 'date_formation': date.today() - timedelta(days=30)}
        ]

        result = get_formations_operateur(1)

        assert len(result) == 2


# =============================================================================
# TESTS : GESTION ERREURS
# =============================================================================

class TestErrorHandling:
    """Tests pour la gestion des erreurs"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_recherche_erreur_db(self, mock_cursor_class):
        """Test gestion erreur DB dans recherche"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        result = rechercher_operateurs()

        # Devrait retourner une liste vide, pas lever d'exception
        assert result == []

    @patch('core.services.rh_service.DatabaseCursor')
    def test_get_operateur_erreur_db(self, mock_cursor_class):
        """Test gestion erreur DB dans get_operateur"""
        from core.services.rh_service import get_operateur_by_id

        mock_cursor_class.return_value.__enter__ = MagicMock(side_effect=Exception("DB Error"))

        result = get_operateur_by_id(1)

        # Devrait retourner None, pas lever d'exception
        assert result is None


# =============================================================================
# TESTS : STATUTS PERSONNEL
# =============================================================================

class TestStatutsPersonnel:
    """Tests pour les différents statuts de personnel"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_filtre_statut_actif(self, mock_cursor_class):
        """Test filtrage par statut ACTIF"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        rechercher_operateurs(statut="ACTIF")

        call_args = mock_cursor.execute.call_args
        # ACTIF devrait être dans les paramètres
        assert "ACTIF" in call_args[0][1]

    @patch('core.services.rh_service.DatabaseCursor')
    def test_filtre_statut_inactif(self, mock_cursor_class):
        """Test filtrage par statut INACTIF"""
        from core.services.rh_service import rechercher_operateurs

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []

        rechercher_operateurs(statut="INACTIF")

        call_args = mock_cursor.execute.call_args
        assert "INACTIF" in call_args[0][1]


# =============================================================================
# TESTS : NOM COMPLET
# =============================================================================

class TestNomComplet:
    """Tests pour la construction du nom complet"""

    @patch('core.services.rh_service.DatabaseCursor')
    def test_nom_complet_format(self, mock_cursor_class):
        """Test format du nom complet (prénom + nom)"""
        from core.services.rh_service import get_operateur_by_id

        mock_cursor = MagicMock()
        mock_cursor_class.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor_class.return_value.__exit__ = MagicMock(return_value=False)

        mock_cursor.fetchone.return_value = {
            'id': 1,
            'nom': 'Dupont',
            'prenom': 'Jean',
            'nom_complet': 'Jean Dupont'  # CONCAT(prenom, ' ', nom)
        }

        result = get_operateur_by_id(1)

        assert result['nom_complet'] == 'Jean Dupont'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
