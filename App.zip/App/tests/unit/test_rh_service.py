# -*- coding: utf-8 -*-
"""
Tests unitaires pour le service RH (rh_service_refactored.py)

Couvre:
- Recherche d'opérateurs
- Récupération des données par domaine (général, contrat, compétences, etc.)
- Mapping des catégories de documents
- Gestion des différents domaines RH
"""

import pytest
from unittest.mock import patch, MagicMock
from datetime import date, timedelta

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# =============================================================================
# TESTS : DOMAINES RH
# =============================================================================

class TestDomaineRH:
    """Tests pour l'énumération DomaineRH"""

    def test_domaines_disponibles(self):
        """Test que tous les domaines RH sont disponibles"""
        from core.services.rh_service_refactored import DomaineRH

        expected_domaines = [
            'GENERAL', 'CONTRAT', 'DECLARATION',
            'COMPETENCES', 'FORMATION', 'MEDICAL', 'VIE_SALARIE'
        ]

        for domaine in expected_domaines:
            assert hasattr(DomaineRH, domaine), f"Domaine {domaine} manquant"

    def test_domaine_values(self):
        """Test les valeurs des domaines"""
        from core.services.rh_service_refactored import DomaineRH

        assert DomaineRH.GENERAL.value == "general"
        assert DomaineRH.CONTRAT.value == "contrat"
        assert DomaineRH.COMPETENCES.value == "competences"


class TestCategorieMapping:
    """Tests pour le mapping catégories -> domaines"""

    def test_mapping_contrat(self):
        """Test mapping catégorie contrat"""
        from core.services.rh_service_refactored import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Contrats de travail"] == DomaineRH.CONTRAT

    def test_mapping_medical(self):
        """Test mapping catégorie médical"""
        from core.services.rh_service_refactored import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Certificats médicaux"] == DomaineRH.MEDICAL

    def test_mapping_formation(self):
        """Test mapping catégorie formation"""
        from core.services.rh_service_refactored import CATEGORIE_TO_DOMAINE, DomaineRH

        assert CATEGORIE_TO_DOMAINE["Diplômes et formations"] == DomaineRH.FORMATION


# =============================================================================
# TESTS : RECHERCHE OPERATEURS
# =============================================================================

class TestRechercherOperateurs:
    """Tests pour rechercher_operateurs"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'},
        {'id': 2, 'nom': 'Martin', 'prenom': 'Marie', 'matricule': 'OP002', 'statut': 'ACTIF'}
    ])
    def test_recherche_tous_actifs(self, mock_fetch):
        """Test recherche de tous les opérateurs actifs"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs()

        assert len(result) == 2
        assert result[0]['nom'] == 'Dupont'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'}
    ])
    def test_recherche_par_nom(self, mock_fetch):
        """Test recherche par nom"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(recherche="Dupont")

        assert len(result) == 1
        assert result[0]['nom'] == 'Dupont'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'nom': 'Dupont', 'prenom': 'Jean', 'matricule': 'OP001', 'statut': 'ACTIF'}
    ])
    def test_recherche_par_matricule(self, mock_fetch):
        """Test recherche par matricule"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(recherche="OP001")

        assert len(result) == 1

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 3, 'nom': 'Durand', 'prenom': 'Pierre', 'matricule': 'OP003', 'statut': 'INACTIF'}
    ])
    def test_recherche_inactifs(self, mock_fetch):
        """Test recherche des inactifs uniquement"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(statut="INACTIF")

        assert len(result) == 1
        assert result[0]['statut'] == 'INACTIF'

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[
        {'id': 1, 'nom': 'Dupont', 'statut': 'ACTIF'},
        {'id': 2, 'nom': 'Martin', 'statut': 'INACTIF'}
    ])
    def test_recherche_tous_statuts(self, mock_fetch):
        """Test recherche sans filtre de statut"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(statut=None)

        assert len(result) == 2

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[{'id': 1}])
    def test_recherche_avec_limite(self, mock_fetch):
        """Test recherche avec limite personnalisée"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(limit=10)

        assert len(result) == 1
        assert mock_fetch.called

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_recherche_vide(self, mock_fetch):
        """Test recherche sans résultat"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs(recherche="Inexistant")

        assert result == []


# =============================================================================
# TESTS : GET OPERATEUR
# =============================================================================

class TestGetOperateurById:
    """Tests pour get_operateur_by_id"""

    @patch('core.services.rh_service_refactored.PersonnelService.get_by_id', return_value={
        'id': 1,
        'nom': 'Dupont',
        'prenom': 'Jean',
        'matricule': 'OP001',
        'statut': 'ACTIF'
    })
    def test_get_operateur_found(self, mock_get):
        """Test récupération opérateur existant"""
        from core.services.rh_service_refactored import get_operateur_by_id

        result = get_operateur_by_id(1)

        assert result is not None
        assert result['nom'] == 'Dupont'
        assert result['nom_complet'] == 'Jean Dupont'

    @patch('core.services.rh_service_refactored.PersonnelService.get_by_id', return_value=None)
    def test_get_operateur_not_found(self, mock_get):
        """Test opérateur non trouvé"""
        from core.services.rh_service_refactored import get_operateur_by_id

        result = get_operateur_by_id(999)

        assert result is None

    @patch('core.services.rh_service_refactored.PersonnelService.get_by_id',
           side_effect=Exception("DB Error"))
    def test_get_operateur_db_error(self, mock_get):
        """Test gestion erreur DB"""
        from core.services.rh_service_refactored import get_operateur_by_id

        result = get_operateur_by_id(1)

        assert result is None


class TestGetOperateurByMatricule:
    """Tests pour get_operateur_by_matricule"""

    @patch('core.db.query_executor.QueryExecutor.fetch_one', return_value={
        'id': 1,
        'nom': 'Dupont',
        'matricule': 'OP001'
    })
    def test_get_by_matricule_found(self, mock_fetch):
        """Test récupération par matricule existant"""
        from core.services.rh_service_refactored import get_operateur_by_matricule

        result = get_operateur_by_matricule('OP001')

        assert result is not None
        assert result['matricule'] == 'OP001'

    @patch('core.db.query_executor.QueryExecutor.fetch_one', return_value=None)
    def test_get_by_matricule_not_found(self, mock_fetch):
        """Test matricule non trouvé"""
        from core.services.rh_service_refactored import get_operateur_by_matricule

        result = get_operateur_by_matricule('UNKNOWN')

        assert result is None


# =============================================================================
# TESTS : DONNEES GENERALES (via get_donnees_domaine)
# =============================================================================

class TestGetDonneesGenerales:
    """Tests pour la récupération des données générales"""

    def test_get_donnees_generales(self):
        """Test récupération données générales via get_donnees_domaine"""
        try:
            from core.services.rh_service_refactored import get_donnees_domaine, DomaineRH
        except ImportError:
            pytest.skip("Fonction get_donnees_domaine non disponible")

        with patch('core.db.query_executor.QueryExecutor.fetch_one', return_value={
            'id': 1,
            'nom': 'Dupont',
            'prenom': 'Jean',
            'date_naissance': date(1985, 5, 15),
            'adresse': '123 Rue Test'
        }):
            with patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[]):
                result = get_donnees_domaine(1, DomaineRH.GENERAL)
                assert result is not None


# =============================================================================
# TESTS : CONTRATS
# =============================================================================

class TestGetContratOperateur:
    """Tests pour la récupération des contrats"""

    def test_get_contrat_actif(self):
        """Test récupération contrat actif via get_donnees_domaine"""
        try:
            from core.services.rh_service_refactored import get_donnees_domaine, DomaineRH
        except ImportError:
            pytest.skip("Fonction non disponible")

        with patch('core.services.rh_service_refactored.ContratServiceCRUD.get_by_operateur',
                   return_value=[
                       {'id': 1, 'type_contrat': 'CDI',
                        'date_debut': date.today() - timedelta(days=365), 'actif': 1}
                   ]):
            with patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[]):
                result = get_donnees_domaine(1, DomaineRH.CONTRAT)
                assert result is not None


# =============================================================================
# TESTS : GESTION ERREURS
# =============================================================================

class TestErrorHandling:
    """Tests pour la gestion des erreurs"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', side_effect=Exception("DB Error"))
    def test_recherche_erreur_db(self, mock_fetch):
        """Test gestion erreur DB dans recherche"""
        from core.services.rh_service_refactored import rechercher_operateurs

        result = rechercher_operateurs()

        # Devrait retourner une liste vide, pas lever d'exception
        assert result == []

    @patch('core.services.rh_service_refactored.PersonnelService.get_by_id',
           side_effect=Exception("DB Error"))
    def test_get_operateur_erreur_db(self, mock_get):
        """Test gestion erreur DB dans get_operateur"""
        from core.services.rh_service_refactored import get_operateur_by_id

        result = get_operateur_by_id(1)

        # Devrait retourner None, pas lever d'exception
        assert result is None


# =============================================================================
# TESTS : STATUTS PERSONNEL
# =============================================================================

class TestStatutsPersonnel:
    """Tests pour les différents statuts de personnel"""

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_filtre_statut_actif(self, mock_fetch):
        """Test filtrage par statut ACTIF"""
        from core.services.rh_service_refactored import rechercher_operateurs

        rechercher_operateurs(statut="ACTIF")

        assert mock_fetch.called

    @patch('core.db.query_executor.QueryExecutor.fetch_all', return_value=[])
    def test_filtre_statut_inactif(self, mock_fetch):
        """Test filtrage par statut INACTIF"""
        from core.services.rh_service_refactored import rechercher_operateurs

        rechercher_operateurs(statut="INACTIF")

        assert mock_fetch.called


# =============================================================================
# TESTS : NOM COMPLET
# =============================================================================

class TestNomComplet:
    """Tests pour la construction du nom complet"""

    @patch('core.services.rh_service_refactored.PersonnelService.get_by_id', return_value={
        'id': 1,
        'nom': 'Dupont',
        'prenom': 'Jean',
    })
    def test_nom_complet_format(self, mock_get):
        """Test format du nom complet (prénom + nom)"""
        from core.services.rh_service_refactored import get_operateur_by_id

        result = get_operateur_by_id(1)

        assert result['nom_complet'] == 'Jean Dupont'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
