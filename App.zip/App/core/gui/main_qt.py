import sys, os, datetime as dt, time, traceback
from dataclasses import dataclass

# Ajouter le répertoire App au PYTHONPATH pour cx_Freeze
if getattr(sys, 'frozen', False):
    # En mode exécutable compilé
    app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, app_dir)
else:
    # En mode développement
    app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QListWidget, QScrollArea,
    QVBoxLayout, QHBoxLayout, QGridLayout, QComboBox, QMessageBox, QFrame, QDialog
)
from PyQt5.QtCore import (
    Qt, QUrl, QPropertyAnimation, QEasingCurve, QTimer, QPoint, QEvent,
    qInstallMessageHandler, QtMsgType, QObject, pyqtSignal, QRunnable, QThreadPool
)
from PyQt5.QtGui import QDesktopServices

# ✅ Import optionnel
try:
    from core.services.log_exporter import export_day
except Exception:
    export_day = None

# ✅ OPTIMISATION : Monitoring de performance
try:
    from core.utils.performance_monitor import print_performance_report, export_performance_stats
except ImportError:
    print_performance_report = None
    export_performance_stats = None


# ===========================
#  Workers (ThreadPool) - ✅ Utilisation du nouveau module db_worker
# ===========================

# Import du système de workers optimisé
try:
    from core.gui.db_worker import (
        DbWorker, DbThreadPool, run_in_background,
        show_loading_placeholder, show_error_placeholder
    )
    # Initialiser le pool avec la bonne configuration
    _thread_pool = DbThreadPool.get_pool()
    if _thread_pool:
        print(f"[OK] DbThreadPool initialise : {_thread_pool.maxThreadCount()} threads max")
except ImportError:
    # Fallback si le module n'existe pas encore
    class WorkerSignals(QObject):
        result = pyqtSignal(object)
        error = pyqtSignal(str)

    class DbWorker(QRunnable):
        """Exécute une fonction DB en background et renvoie le résultat."""
        def __init__(self, fn, *args, **kwargs):
            super().__init__()
            self.fn = fn
            self.args = args
            self.kwargs = kwargs
            self.signals = WorkerSignals()

        def run(self):
            try:
                res = self.fn(*self.args, **self.kwargs)
                self.signals.result.emit(res)
            except Exception:
                self.signals.error.emit(traceback.format_exc())

    _thread_pool = QThreadPool.globalInstance()
    # Limiter à 4 threads par défaut
    _thread_pool.setMaxThreadCount(4)


# ===========================
#  Fonctions lazy (DB/Auth/Theme)
# ===========================

def _lazy_auth():
    from core.services import auth_service
    return auth_service

def _lazy_theme():
    from core.gui import ui_theme
    return ui_theme

# Cache pour éviter de réimporter à chaque appel
_theme_cache = None

def get_theme_components():
    """Retourne les composants du thème (EmacTheme, EmacButton, etc.)"""
    global _theme_cache
    if _theme_cache is None:
        theme_module = _lazy_theme()
        _theme_cache = {
            'EmacTheme': theme_module.EmacTheme,
            'EmacButton': theme_module.EmacButton,
            'EmacCard': theme_module.EmacCard,
            'EmacStatusCard': theme_module.EmacStatusCard,
            'HamburgerButton': theme_module.HamburgerButton,
        }
    return _theme_cache


# ===========================
#  Main Window
# ===========================

class MainWindow(QMainWindow):
    DRAWER_WIDTH = 280

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestion du Personnel")
        self.setGeometry(80, 80, 1180, 720)

        # ThreadPool global pour éviter les freezes UI
        self.pool = QThreadPool.globalInstance()

        # Drawer
        self.drawer = None
        self.is_drawer_open = False
        self.installEventFilter(self)

        # Cache postes
        self._postes_cache = None
        self._postes_cache_time = None

        # ✅ Charger les composants du thème
        theme = get_theme_components()
        EmacStatusCard = theme['EmacStatusCard']
        EmacButton = theme['EmacButton']
        EmacCard = theme['EmacCard']
        HamburgerButton = theme['HamburgerButton']

        # UI
        rootw = QWidget()
        self.setCentralWidget(rootw)
        root = QGridLayout(rootw)
        root.setContentsMargins(18, 18, 18, 18)
        root.setHorizontalSpacing(18)
        root.setVerticalSpacing(18)
        rootw.setLayout(root)

        left = QVBoxLayout()
        left.setSpacing(18)

        self.retard_card = EmacStatusCard("Retard Évaluations", variant='danger')
        self.retard_filter = QComboBox()
        self.retard_filter.addItem("Tous les postes", "")
        self.retard_filter.currentIndexChanged.connect(self.load_evaluations_async)
        self.retard_scroll, self.retard_list = self.create_scrollable_list()
        self.retard_card.body.addWidget(self.retard_filter)
        self.retard_card.body.addWidget(self.retard_scroll)

        btn_voir_retards = EmacButton("📋 Voir tout", variant='ghost')
        btn_voir_retards.clicked.connect(lambda: self.ouvrir_gestion_evaluations("En retard"))
        self.retard_card.body.addWidget(btn_voir_retards)

        left.addWidget(self.retard_card)

        self.next_card = EmacStatusCard("Prochaines Évaluations", variant='success', subtitle="À planifier (30j)")
        self.next_eval_filter = QComboBox()
        self.next_eval_filter.addItem("Tous les postes", "")
        self.next_eval_filter.currentIndexChanged.connect(self.load_evaluations_async)
        self.next_eval_scroll, self.next_eval_list = self.create_scrollable_list()
        self.next_card.body.addWidget(self.next_eval_filter)
        self.next_card.body.addWidget(self.next_eval_scroll)

        btn_voir_prochaines = EmacButton("📋 Voir tout", variant='ghost')
        btn_voir_prochaines.clicked.connect(lambda: self.ouvrir_gestion_evaluations("À planifier (30j)"))
        self.next_card.body.addWidget(btn_voir_prochaines)

        left.addWidget(self.next_card)

        root.addLayout(left, 0, 0, 2, 1)

        right = QVBoxLayout()
        right.setSpacing(18)

        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(0, 0, 0, 8)
        header_layout.setSpacing(12)

        title_layout = QVBoxLayout()
        title_layout.setSpacing(2)

        h1 = QLabel("Gestion du Personnel")
        h1.setProperty('class', 'h1')
        title_layout.addWidget(h1)

        # ✅ IMPORTANT: ne pas appeler get_current_user() ici (peut toucher DB/session)
        # On met un placeholder et on remplira après (async)
        self.user_info = QLabel("👤 ...")
        self.user_info.setStyleSheet("color: #666; font-size: 12px;")
        title_layout.addWidget(self.user_info)

        header_layout.addLayout(title_layout, 1)

        self.menu_btn = HamburgerButton(self, variant="default")
        self.menu_btn.setToolTip("Menu")
        self.menu_btn.clicked.connect(self.toggle_drawer)
        header_layout.addWidget(self.menu_btn, 0, Qt.AlignRight | Qt.AlignVCenter)

        right.addWidget(header_widget)

        self.actions_wrap = EmacCard()
        title = QLabel("Actions rapides")
        title.setProperty('class', 'h2')
        self.actions_wrap.body.addWidget(title)

        # ✅ IMPORTANT: ne pas appeler has_permission() ici (peut toucher DB)
        # On construit un layout minimal et on l’enrichit après (async).
        self.rows = QVBoxLayout()
        self.rows.setSpacing(8)

        r1 = QHBoxLayout()
        b1 = EmacButton("Liste du Personnel", 'primary')
        b1.clicked.connect(self.show_liste_personnel)
        r1.addWidget(b1)
        self.rows.addLayout(r1)

        r_quit = QHBoxLayout()
        bq = EmacButton("Quitter", 'ghost')
        bq.clicked.connect(self.close)
        r_quit.addWidget(bq)
        self.rows.addLayout(r_quit)

        self.actions_wrap.body.addLayout(self.rows)
        right.addWidget(self.actions_wrap)

        root.addLayout(right, 0, 1)

        # ✅ Lancement ultra rapide : on affiche, puis on charge le reste en background
        QTimer.singleShot(0, self.bootstrap_async)

    # ---------------------------
    # Bootstrap async
    # ---------------------------

    def bootstrap_async(self):
        """Charge user + permissions + filtres + evals sans bloquer l'UI."""
        print("[DEBUG] bootstrap_async démarré")
        self.load_user_and_permissions_async()
        self.populate_filters_async()
        self.load_evaluations_async()
        print("[DEBUG] bootstrap_async terminé (tâches lancées)")

    def load_user_and_permissions_async(self):
        w = DbWorker(self._fetch_user_and_perms)
        w.signals.result.connect(self._apply_user_and_perms)
        w.signals.error.connect(self._on_bg_error)
        self.pool.start(w)

    def _fetch_user_and_perms(self, progress_callback=None):
        print("[DEBUG] _fetch_user_and_perms appelée")
        auth = _lazy_auth()
        current_user = auth.get_current_user()
        print(f"[DEBUG] Utilisateur récupéré: {current_user}")

        # Permissions (⚠️ selon ton implémentation, ça peut être DB → ok en thread)
        perms = {
            "grilles_lecture": auth.has_permission('grilles', 'lecture'),
            "evaluations_lecture": auth.has_permission('evaluations', 'lecture'),
            "personnel_ecriture": auth.has_permission('personnel', 'ecriture'),
            "postes_ecriture": auth.has_permission('postes', 'ecriture'),
            "contrats_ecriture": auth.has_permission('contrats', 'ecriture'),
            "documentsrh_lecture": auth.has_permission('documents_rh', 'lecture'),
            "planning_lecture": auth.has_permission('planning', 'lecture'),
            "historique_lecture": auth.has_permission('historique', 'lecture'),
            "is_admin": auth.is_admin(),
        }
        print(f"[DEBUG] Permissions calculées: {sum(1 for v in perms.values() if v)} actives")
        return {"user": current_user, "perms": perms}

    def _apply_user_and_perms(self, payload):
        print(f"[DEBUG] _apply_user_and_perms appelée avec payload: {type(payload)}")
        user = payload.get("user")
        perms = payload.get("perms", {})
        print(f"[DEBUG] User: {user}")
        print(f"[DEBUG] Perms: {perms}")

        # User label
        if user:
            user_text = f"👤 {user.get('prenom','')} {user.get('nom','')} - {user.get('role_nom','')}"
            self.user_info.setText(user_text)
            print(f"[DEBUG] Label utilisateur mis à jour: {user_text}")
        else:
            self.user_info.setText("👤 Non connecté")
            print("[DEBUG] Aucun utilisateur connecté")

        # Charger EmacButton
        theme = get_theme_components()
        EmacButton = theme['EmacButton']

        # Actions rapides : on ajoute les boutons conditionnels
        # (on évite de les créer au démarrage)
        if perms.get("grilles_lecture"):
            r2 = QHBoxLayout()
            b2 = EmacButton("Liste et Grilles", 'ghost')
            b2.clicked.connect(self.show_listes_grilles_dialog)
            r2.addWidget(b2)
            self.rows.insertLayout(1, r2)

        if perms.get("evaluations_lecture"):
            r3 = QHBoxLayout()
            b3 = EmacButton("Gestion des Évaluations", 'ghost')
            b3.clicked.connect(self.show_gestion_evaluations)
            r3.addWidget(b3)
            self.rows.insertLayout(2, r3)

        # Drawer : on le construit au premier clic, mais on garde les perms en mémoire
        self._perms_cache = perms

    # ---------------------------
    # Event filter
    # ---------------------------

    def eventFilter(self, source, event):
        if self.drawer is not None and self.is_drawer_open and event.type() == QEvent.MouseButtonPress:
            if not self.drawer.geometry().contains(self.mapFromGlobal(event.globalPos())):
                if source is not self.menu_btn:
                    self.toggle_drawer()
                    return True
        return super().eventFilter(source, event)

    # ---------------------------
    # Drawer
    # ---------------------------

    def create_drawer(self):
        if self.drawer is not None:
            return

        # Charger les composants du thème
        theme = get_theme_components()
        EmacTheme = theme['EmacTheme']
        EmacButton = theme['EmacButton']

        self.drawer = QFrame(self)
        self.drawer.setObjectName("card")
        self.drawer.setFixedSize(self.DRAWER_WIDTH, self.height())

        ThemeCls = EmacTheme
        border_color = ThemeCls.BDR
        bg_card = ThemeCls.BG_CARD

        self.drawer.setStyleSheet(f"""
            QFrame#card {{
                background: {bg_card};
                border-left: 1px solid {border_color};
                border-top: 1px solid {border_color};
                border-bottom: 1px solid {border_color};
                border-right: 0px;
                border-top-left-radius: 0px;
                border-bottom-left-radius: 0px;
                border-top-right-radius: 14px;
                border-bottom-right-radius: 14px;
            }}
        """)

        self.drawer.move(self.width(), 0)
        self.drawer.hide()

        drawer_layout = QVBoxLayout(self.drawer)
        drawer_layout.setContentsMargins(16, 16, 16, 16)
        drawer_layout.setAlignment(Qt.AlignTop)

        title = QLabel("Menu")
        title.setProperty('class', 'h2')
        drawer_layout.addWidget(title)
        drawer_layout.addSpacing(15)

        # ✅ Permissions depuis cache si dispo, sinon fallback lazy (sans bloquer)
        perms = getattr(self, "_perms_cache", None)
        if perms is None:
            # fallback minimal (si jamais)
            perms = {"is_admin": False}

        def add_btn(text, fn, variant='ghost'):
            btn = EmacButton(text, variant=variant)
            btn.setFixedHeight(44)
            btn.clicked.connect(fn)
            if fn not in (self.close, self.export_logs_today):
                btn.clicked.connect(self.toggle_drawer)
            drawer_layout.addWidget(btn)

        if perms.get("personnel_ecriture"):
            add_btn("Ajouter du personnel", self.show_manage_operator)
        if perms.get("postes_ecriture"):
            add_btn("Création/Suppression de poste", self.show_poste_form)
        if perms.get("contrats_ecriture") or perms.get("documentsrh_lecture"):
            add_btn("Gestion RH (Contrats & Documents)", self.show_contract_management)
        if perms.get("documentsrh_lecture") or perms.get("formations_lecture"):
            add_btn("Gestion des Formations", self.show_gestion_formations)
        if perms.get("planning_lecture"):
            add_btn("Planning & Évaluations", self.show_regularisation)
        if perms.get("historique_lecture"):
            add_btn("Historique", self.show_historique)

        if perms.get("is_admin"):
            drawer_layout.addSpacing(10)
            sep = QFrame()
            sep.setFrameShape(QFrame.HLine)
            sep.setStyleSheet("color: #ddd;")
            drawer_layout.addWidget(sep)
            drawer_layout.addSpacing(10)
            add_btn("Gestion des Utilisateurs", self.show_user_management)

        drawer_layout.addStretch(1)

        drawer_layout.addSpacing(10)
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.HLine)
        sep2.setStyleSheet("color: #ddd;")
        drawer_layout.addWidget(sep2)
        drawer_layout.addSpacing(10)
        add_btn("🚪 Déconnexion", self.logout)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.drawer is not None:
            self.drawer.setFixedHeight(self.height())
            current_x = self.width() - self.DRAWER_WIDTH if self.is_drawer_open else self.width()
            self.drawer.move(current_x, 0)

    def toggle_drawer(self):
        if self.drawer is None:
            self.create_drawer()
        if self.drawer is None:
            print("[ERREUR] Impossible de creer le drawer")
            return

        self.is_drawer_open = not self.is_drawer_open
        end_x = self.width() - self.DRAWER_WIDTH if self.is_drawer_open else self.width()

        if hasattr(self, 'animation') and self.animation is not None:
            self.animation.stop()
            try:
                self.animation.finished.disconnect()
            except Exception:
                pass

        self.animation = QPropertyAnimation(self.drawer, b"pos")
        self.animation.setDuration(250)
        self.animation.setEasingCurve(QEasingCurve.OutCubic)
        self.animation.setStartValue(self.drawer.pos())
        self.animation.setEndValue(QPoint(end_x, 0))

        if self.is_drawer_open:
            self.drawer.show()
            self.drawer.raise_()
        else:
            self.animation.finished.connect(self.drawer.hide)

        self.animation.start()

    # ---------------------------
    # UI helpers
    # ---------------------------

    def create_scrollable_list(self):
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        lw = QListWidget()
        sc.setWidget(lw)
        return sc, lw

    # ---------------------------
    # Dialogs (lazy imports)
    # ---------------------------

    def show_liste_personnel(self):
        from core.gui.gestion_personnel import GestionPersonnelDialog
        GestionPersonnelDialog(self).exec_()

    def show_manage_operator(self):
        from core.gui.manage_operateur import ManageOperatorsDialog
        ManageOperatorsDialog().exec_()

    def show_gestion_evaluations(self):
        """Ouvre le dialogue de gestion des évaluations"""
        try:
            from core.gui.gestion_evaluation import GestionEvaluationDialog
            dialog = GestionEvaluationDialog()
            dialog.exec_()
        except Exception as e:
            from PyQt5.QtWidgets import QMessageBox
            import traceback
            error_msg = f"Erreur lors de l'ouverture de la gestion des évaluations :\n\n{str(e)}\n\n"
            error_msg += f"Type: {type(e).__name__}\n\n"
            error_msg += "Stack trace:\n" + traceback.format_exc()
            QMessageBox.critical(self, "Erreur - Gestion Évaluations", error_msg)
            print(f"[ERREUR] show_gestion_evaluations: {e}")
            traceback.print_exc()

    def ouvrir_gestion_evaluations(self, filtre_statut):
        try:
            from core.gui.gestion_evaluation import GestionEvaluationDialog
            dialog = GestionEvaluationDialog()
            if hasattr(dialog, 'status_filter'):
                index = dialog.status_filter.findText(filtre_statut)
                if index >= 0:
                    dialog.status_filter.setCurrentIndex(index)
            dialog.exec_()
            self.load_evaluations_async()
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Impossible d'ouvrir la gestion des évaluations :\n{e}")

    def show_listes_grilles_dialog(self):
        from core.gui.liste_et_grilles import GrillesDialog
        GrillesDialog().exec_()

    def show_poste_form(self):
        from core.gui.creation_modification_poste import CreationModificationPosteDialog
        CreationModificationPosteDialog().exec_()
        self._postes_cache = None
        self._postes_cache_time = None
        self.populate_filters_async()

    def show_historique(self):
        from core.gui.historique import HistoriqueDialog
        HistoriqueDialog().exec_()

    def show_regularisation(self):
        # ⚠️ DB => on passe en background, puis on ouvre le dialog sur le thread UI
        w = DbWorker(self._fetch_one_actif_personnel_id)
        w.signals.result.connect(self._open_regularisation)
        w.signals.error.connect(self._on_bg_error)
        self.pool.start(w)

    def _fetch_one_actif_personnel_id(self, progress_callback=None):
        from core.db.configbd import DatabaseCursor

        with DatabaseCursor() as cur:
            cur.execute("SELECT id FROM personnel WHERE statut = 'ACTIF' LIMIT 1")
            r = cur.fetchone()
            return r[0] if r else None

    def _open_regularisation(self, personnel_id):
        if not personnel_id:
            QMessageBox.warning(self, "Erreur", "Aucun personnel actif trouvé")
            return
        from core.gui.planning_absences import PlanningAbsencesDialog
        PlanningAbsencesDialog(personnel_id=personnel_id, parent=self).exec_()

    def show_contract_management(self):
        # Forcer le rechargement du module pour voir les modifications
        import sys
        import importlib
        if 'core.gui.contract_management' in sys.modules:
            importlib.reload(sys.modules['core.gui.contract_management'])

        from core.gui.contract_management import ContractManagementDialog
        ContractManagementDialog(self).exec_()

    def show_gestion_documentaire(self):
        from core.gui.gestion_documentaire import GestionDocumentaireDialog
        GestionDocumentaireDialog(self).exec_()

    def show_gestion_formations(self):
        from core.gui.gestion_formations import GestionFormationsDialog
        GestionFormationsDialog(self).exec_()

    # ---------------------------
    # DB async (filters + evaluations)
    # ---------------------------

    def populate_filters_async(self):
        w = DbWorker(self._fetch_postes_cached)
        w.signals.result.connect(self._apply_postes_to_filters)
        w.signals.error.connect(self._on_bg_error)
        self.pool.start(w)

    def _fetch_postes_cached(self, progress_callback=None):
        # Cache 5 minutes
        if self._postes_cache is not None and self._postes_cache_time is not None:
            if (time.time() - self._postes_cache_time) < 300:
                return self._postes_cache

        from core.db.configbd import DatabaseCursor

        with DatabaseCursor() as cur:
            cur.execute("SELECT DISTINCT poste_code FROM postes WHERE visible = 1 ORDER BY poste_code;")
            postes = cur.fetchall()
            self._postes_cache = postes
            self._postes_cache_time = time.time()
            return postes

    def _apply_postes_to_filters(self, postes):
        try:
            for (poste,) in postes:
                if self.retard_filter.findData(poste) == -1:
                    self.retard_filter.addItem(poste, poste)
                if self.next_eval_filter.findData(poste) == -1:
                    self.next_eval_filter.addItem(poste, poste)
        except Exception as e:
            print(f"[WARN] Erreur apply filtres: {e}")

    def load_evaluations_async(self):
        print("[DEBUG] load_evaluations_async appelée")
        poste_retard = self.retard_filter.currentData()
        poste_next = self.next_eval_filter.currentData()
        print(f"[DEBUG] Filtres: retard={poste_retard}, next={poste_next}")

        w = DbWorker(self._fetch_evaluations, poste_retard, poste_next)
        w.signals.result.connect(self._apply_evaluations_to_ui)
        w.signals.error.connect(self._on_bg_error)
        self.pool.start(w)
        print("[DEBUG] Worker lancé pour charger les évaluations")

    def _fetch_evaluations(self, poste_retard, poste_next, progress_callback=None):
        print(f"[DEBUG] _fetch_evaluations appelée avec retard={poste_retard}, next={poste_next}")
        from core.db.configbd import DatabaseCursor

        try:
            with DatabaseCursor(dictionary=True) as cur:
                query_retard = """
                    SELECT p.nom, p.prenom, pos.poste_code, poly.prochaine_evaluation
                    FROM polyvalence poly
                    INNER JOIN personnel p ON p.id = poly.operateur_id
                    LEFT JOIN postes pos ON pos.id = poly.poste_id
                    WHERE poly.prochaine_evaluation < CURDATE()
                      AND p.statut = 'ACTIF'
                      {retard_filter}
                    ORDER BY poly.prochaine_evaluation ASC
                    LIMIT 10
                """
                retard_filter = "AND pos.poste_code = %s" if poste_retard else ""
                query_retard = query_retard.format(retard_filter=retard_filter)
                params_retard = (poste_retard,) if poste_retard else ()
                cur.execute(query_retard, params_retard)
                retard = cur.fetchall()
                print(f"[DEBUG] Requête retard: {len(retard)} résultats")

                query_next = """
                    SELECT p.nom, p.prenom, pos.poste_code, poly.prochaine_evaluation
                    FROM polyvalence poly
                    INNER JOIN personnel p ON p.id = poly.operateur_id
                    LEFT JOIN postes pos ON pos.id = poly.poste_id
                    WHERE poly.prochaine_evaluation BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                      AND p.statut = 'ACTIF'
                      {next_filter}
                    ORDER BY poly.prochaine_evaluation ASC
                    LIMIT 10
                """
                next_filter = "AND pos.poste_code = %s" if poste_next else ""
                query_next = query_next.format(next_filter=next_filter)
                params_next = (poste_next,) if poste_next else ()
                cur.execute(query_next, params_next)
                prochaines = cur.fetchall()
                print(f"[DEBUG] Requête prochaines: {len(prochaines)} résultats")

                result = {"retard": retard, "prochaines": prochaines}
                print(f"[DEBUG] _fetch_evaluations retourne: {len(retard)} retards, {len(prochaines)} prochaines")
                return result
        except Exception as e:
            print(f"[ERROR] Erreur dans _fetch_evaluations: {e}")
            import traceback
            traceback.print_exc()
            raise

    def _apply_evaluations_to_ui(self, payload):
        try:
            print(f"[DEBUG] _apply_evaluations_to_ui appelée avec payload: {type(payload)}")
            retard = payload.get("retard", [])
            prochaines = payload.get("prochaines", [])
            print(f"[DEBUG] Retard: {len(retard)} éléments, Prochaines: {len(prochaines)} éléments")

            self.retard_list.clear()
            for r in retard:
                nom = r.get('nom', '')
                prenom = r.get('prenom', '')
                poste = r.get('poste_code', '')
                date_ev = r.get('prochaine_evaluation')
                date_txt = date_ev.strftime('%d/%m/%Y') if hasattr(date_ev, 'strftime') else str(date_ev)
                self.retard_list.addItem(f"{nom} {prenom} · {poste or ''}  —  Retard: {date_txt}")

            self.next_eval_list.clear()
            for r in prochaines:
                nom = r.get('nom', '')
                prenom = r.get('prenom', '')
                poste = r.get('poste_code', '')
                date_ev = r.get('prochaine_evaluation')
                date_txt = date_ev.strftime('%d/%m/%Y') if hasattr(date_ev, 'strftime') else str(date_ev)
                self.next_eval_list.addItem(f"{nom} {prenom} · {poste or ''}  —  Prévu: {date_txt}")

            print(f"[DEBUG] UI mise à jour avec succès: {self.retard_list.count()} en retard, {self.next_eval_list.count()} à venir")
        except Exception as e:
            print(f"[ERROR] Erreur dans _apply_evaluations_to_ui: {e}")
            import traceback
            traceback.print_exc()

    def _on_bg_error(self, tb):
        # Ne bloque pas l'app au démarrage
        print("[ERROR] Erreur background:\n", tb)
        # Afficher également dans la console système
        import traceback
        traceback.print_stack()

        # Afficher un message à l'utilisateur si possible
        try:
            QMessageBox.warning(
                self,
                "Erreur de chargement",
                "Une erreur s'est produite lors du chargement des données.\n\n"
                "L'application peut continuer à fonctionner mais certaines données\n"
                "peuvent être manquantes.\n\n"
                "Vérifiez les logs pour plus de détails.",
                QMessageBox.Ok
            )
        except:
            pass  # Si on ne peut même pas afficher le message, tant pis

    # ---------------------------
    # Export
    # ---------------------------

    def export_logs_today(self):
        if not export_day:
            QMessageBox.warning(self, "Non disponible", "Module d'export non chargé.")
            return
        try:
            paths = export_day(dt.date.today(), base_dir="logs", make_zip=False)
            dossier = os.path.dirname(paths["csv"])
            QMessageBox.information(self, "Export", f"Export terminé ✅\n\nCSV : {paths['csv']}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(dossier))
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Export impossible : {e}")

    # ---------------------------
    # Auth
    # ---------------------------

    def logout(self):
        reply = QMessageBox.question(
            self, "Déconnexion", "Voulez-vous vraiment vous déconnecter?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            auth = _lazy_auth()
            auth.logout_user()
            self.close()

            from core.gui.login_dialog import LoginDialog
            login_dialog = LoginDialog()
            if login_dialog.exec_() == QDialog.Accepted:
                new_window = MainWindow()
                new_window.show()

    def show_user_management(self):
        auth = _lazy_auth()
        if not auth.is_admin():
            QMessageBox.warning(self, "Accès refusé", "Seuls les administrateurs peuvent gérer les utilisateurs.")
            return
        from core.gui.user_management import UserManagementDialog
        UserManagementDialog(self).exec_()

    def closeEvent(self, event):
        """
        Gère la fermeture de l'application.
        Affiche le rapport de performance et exporte les stats.
        """
        # ✅ OPTIMISATION : Rapport de performance en fin de session
        if print_performance_report:
            try:
                print("\n" + "="*80)
                print("📊 RAPPORT DE PERFORMANCE DE LA SESSION")
                print("="*80)
                print_performance_report()

                # Export des stats dans un fichier CSV
                if export_performance_stats:
                    timestamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
                    export_performance_stats(f'session_{timestamp}.csv')
            except Exception as e:
                print(f"Erreur lors du rapport de performance: {e}")

        # Fermeture normale
        event.accept()


# ===========================
#  Qt message handler
# ===========================

def qt_message_handler(msg_type, context, message):
    if "Unknown property" in message:
        return
    if msg_type == QtMsgType.QtWarningMsg:
        print(f"Qt Warning: {message}")
    elif msg_type == QtMsgType.QtCriticalMsg:
        print(f"Qt Critical: {message}")
    elif msg_type == QtMsgType.QtFatalMsg:
        print(f"Qt Fatal: {message}")


# ===========================
#  Entry point
# ===========================

if __name__ == "__main__":
    qInstallMessageHandler(qt_message_handler)

    app = QApplication(sys.argv)

    # ✅ Charger et appliquer le thème (lazy)
    theme = get_theme_components()
    EmacTheme = theme['EmacTheme']
    EmacTheme.apply(app)

    # ✅ Login (lazy)
    from core.gui.login_dialog import LoginDialog
    login_dialog = LoginDialog()

    if login_dialog.exec_() == LoginDialog.Accepted:
        win = MainWindow()
        win.show()
        sys.exit(app.exec_())
    else:
        sys.exit(0)