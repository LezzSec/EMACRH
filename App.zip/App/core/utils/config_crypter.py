# -*- coding: utf-8 -*-
"""
Module de chiffrement/dechiffrement de la configuration DB.
Permet d'integrer les identifiants de maniere securisee dans l'exe.

La cle est embarquee dans le code (obfusquee) pour que l'exe soit autonome.
"""

import base64
import os
from cryptography.fernet import Fernet

# ============================================================================
# Cle de chiffrement embarquee (obfusquee en 3 morceaux + XOR)
# Generee une seule fois, ne pas modifier sauf si on re-chiffre tout.
# ============================================================================
_KEY_PARTS = [
    b'a0J5MjFaSnEzV09QMUZuMw==',  # partie 1
    b'aS1YVnF3T2VQdkh4MXphZw==',  # partie 2
    b'QmhlQXBMNjdrRTA9',           # partie 3
]
_KEY_XOR = 0  # pas de XOR pour Fernet (la cle doit etre exacte)


def _get_embedded_key() -> bytes:
    """Reconstitue la cle Fernet a partir des morceaux embarques."""
    raw = b''
    for part in _KEY_PARTS:
        raw += base64.b64decode(part)
    # La cle Fernet fait exactement 44 caracteres en base64
    return raw[:44]


_ENCRYPTION_KEY = None


def _get_encryption_key() -> bytes:
    """Recupere la cle: variable d'environnement (prioritaire) ou cle embarquee."""
    global _ENCRYPTION_KEY
    if _ENCRYPTION_KEY is None:
        # Priorite 1: variable d'environnement (pour tests/dev)
        key = os.getenv('EMAC_ENCRYPTION_KEY')
        if key:
            _ENCRYPTION_KEY = key.encode() if isinstance(key, str) else key
        else:
            # Priorite 2: cle embarquee dans le code
            _ENCRYPTION_KEY = _get_embedded_key()
    return _ENCRYPTION_KEY


def encrypt_config(plain_text: str) -> str:
    """Chiffre une chaine de configuration."""
    f = Fernet(_get_encryption_key())
    encrypted = f.encrypt(plain_text.encode())
    return base64.urlsafe_b64encode(encrypted).decode()


def decrypt_config(encrypted_text: str) -> str:
    """Dechiffre une chaine de configuration."""
    f = Fernet(_get_encryption_key())
    encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
    decrypted = f.decrypt(encrypted_bytes)
    return decrypted.decode()


def encrypt_env_file(env_file_path: str, output_file: str = None) -> str:
    """Chiffre un fichier .env entier."""
    content = None
    for encoding in ['utf-8', 'cp1252', 'latin-1']:
        try:
            with open(env_file_path, 'r', encoding=encoding) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise ValueError(f"Impossible de lire {env_file_path}")

    encrypted = encrypt_config(content)

    output = output_file or env_file_path + '.encrypted'
    with open(output, 'w', encoding='ascii') as f:
        f.write(encrypted)

    print(f"[OK] Fichier chiffre: {output}")
    return output


def decrypt_env_file(encrypted_file_path: str, output_file: str = None) -> str:
    """Dechiffre un fichier .env.encrypted."""
    with open(encrypted_file_path, 'r', encoding='ascii') as f:
        encrypted = f.read()

    decrypted = decrypt_config(encrypted)

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(decrypted)
        print(f"[OK] Fichier dechiffre: {output_file}")

    return decrypted


def generate_key_and_split():
    """Genere une nouvelle cle Fernet et l'affiche en morceaux pour embarquer."""
    key = Fernet.generate_key()  # 44 bytes base64
    print(f"Cle Fernet brute: {key.decode()}")
    # Decouper en 3 morceaux de ~15 chars
    raw = key.decode()
    parts = [raw[:16], raw[16:32], raw[32:]]
    print("\n_KEY_PARTS = [")
    for i, part in enumerate(parts):
        encoded = base64.b64encode(part.encode()).decode()
        print(f"    b'{encoded}',  # partie {i+1}")
    print("]")
    return key


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'generate-key':
        generate_key_and_split()
    elif len(sys.argv) > 1 and sys.argv[1] == 'encrypt':
        env_path = sys.argv[2] if len(sys.argv) > 2 else 'App/.env'
        encrypt_env_file(env_path)
    elif len(sys.argv) > 1 and sys.argv[1] == 'test':
        # Test round-trip
        test_text = "EMAC_DB_PASSWORD=test123"
        encrypted = encrypt_config(test_text)
        decrypted = decrypt_config(encrypted)
        assert decrypted == test_text
        print("[OK] Test chiffrement/dechiffrement reussi")
    else:
        print("Usage:")
        print("  python config_crypter.py generate-key   # Genere une nouvelle cle")
        print("  python config_crypter.py encrypt [path]  # Chiffre un .env")
        print("  python config_crypter.py test            # Test round-trip")
