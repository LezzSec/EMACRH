# -*- coding: utf-8 -*-
"""
Module de chiffrement/déchiffrement de la configuration DB.
Permet d'intégrer les identifiants de manière sécurisée dans l'exe.
"""

import base64
import os
from cryptography.fernet import Fernet

# Clé de chiffrement unique à votre application
# IMPORTANT: Gardez cette clé secrète ! Ne la commitez jamais dans Git !
# Cette clé a été générée le 2026-01-13
ENCRYPTION_KEY = b'yAfLTI6GpL1rMBdtCXUOoq-NfYquO5tyo_8TB27bGOY='


def encrypt_config(plain_text: str) -> str:
    """
    Chiffre une chaîne de configuration.

    Args:
        plain_text: Texte en clair à chiffrer

    Returns:
        Texte chiffré encodé en base64
    """
    f = Fernet(ENCRYPTION_KEY)
    encrypted = f.encrypt(plain_text.encode())
    return base64.urlsafe_b64encode(encrypted).decode()


def decrypt_config(encrypted_text: str) -> str:
    """
    Déchiffre une chaîne de configuration.

    Args:
        encrypted_text: Texte chiffré en base64

    Returns:
        Texte en clair
    """
    f = Fernet(ENCRYPTION_KEY)
    encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
    decrypted = f.decrypt(encrypted_bytes)
    return decrypted.decode()


def encrypt_env_file(env_file_path: str, output_file: str = None):
    """
    Chiffre un fichier .env entier.

    Args:
        env_file_path: Chemin vers le fichier .env
        output_file: Chemin de sortie (optionnel)
    """
    # Lire avec plusieurs encodages possibles
    content = None
    for encoding in ['utf-8', 'cp1252', 'latin-1']:
        try:
            with open(env_file_path, 'r', encoding=encoding) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise ValueError(f"Impossible de lire {env_file_path}")

    encrypted = encrypt_config(content)

    output = output_file or env_file_path + '.encrypted'
    # Écrire en ASCII car base64 est ASCII pur
    with open(output, 'w', encoding='ascii') as f:
        f.write(encrypted)

    print(f"[OK] Fichier chiffre: {output}")
    return output


def decrypt_env_file(encrypted_file_path: str, output_file: str = None):
    """
    Déchiffre un fichier .env.encrypted.

    Args:
        encrypted_file_path: Chemin vers le fichier chiffré
        output_file: Chemin de sortie (optionnel)
    """
    # Lire en ASCII car le fichier chiffré est en base64 (ASCII pur)
    with open(encrypted_file_path, 'r', encoding='ascii') as f:
        encrypted = f.read()

    decrypted = decrypt_config(encrypted)

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(decrypted)
        print(f"[OK] Fichier dechiffre: {output_file}")

    return decrypted


if __name__ == '__main__':
    # Test: Générer une nouvelle clé
    print("Nouvelle clé de chiffrement (à copier dans ENCRYPTION_KEY):")
    print(Fernet.generate_key())
