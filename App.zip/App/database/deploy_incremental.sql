-- ============================================================================
-- EMAC - Script de déploiement incrémental
-- Date: 2024-12-18
-- Description: Ajoute uniquement les nouvelles tables sans écraser les données
-- ============================================================================
-- ATTENTION: Ce script utilise CREATE TABLE IF NOT EXISTS et INSERT IGNORE
-- pour ne PAS écraser les données existantes
-- ============================================================================

USE emac_db;

-- ============================================================================
-- 1. SYSTÈME DE GESTION DES UTILISATEURS
-- ============================================================================

-- Table des rôles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL UNIQUE,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL UNIQUE,
  `password_hash` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `role_id` int NOT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `derniere_connexion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `utilisateurs_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des permissions
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `module` varchar(100) NOT NULL,
  `lecture` tinyint(1) DEFAULT 1,
  `ecriture` tinyint(1) DEFAULT 0,
  `suppression` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des logs de connexion
CREATE TABLE IF NOT EXISTS `logs_connexion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int NOT NULL,
  `date_connexion` datetime NOT NULL,
  `date_deconnexion` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `logs_connexion_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 2. DONNÉES INITIALES (INSERT IGNORE = n'insère que si n'existe pas)
-- ============================================================================

-- Insertion des rôles de base (IGNORE = ne duplique pas si existe déjà)
INSERT IGNORE INTO `roles` (`id`, `nom`, `description`) VALUES
(1, 'admin', 'Administrateur - Accès complet à toutes les fonctionnalités'),
(2, 'gestion_production', 'Gestion Production - Accès aux évaluations et polyvalence (lecture seule sur les contrats)'),
(3, 'gestion_rh', 'Gestion RH - Accès aux contrats et documents administratifs (lecture seule sur la polyvalence)');

-- Configuration des permissions pour le rôle admin
INSERT IGNORE INTO `permissions` (`role_id`, `module`, `lecture`, `ecriture`, `suppression`) VALUES
(1, 'personnel', 1, 1, 1),
(1, 'evaluations', 1, 1, 1),
(1, 'polyvalence', 1, 1, 1),
(1, 'contrats', 1, 1, 1),
(1, 'documents_rh', 1, 1, 1),
(1, 'planning', 1, 1, 1),
(1, 'postes', 1, 1, 1),
(1, 'historique', 1, 1, 1),
(1, 'grilles', 1, 1, 1),
(1, 'gestion_utilisateurs', 1, 1, 1);

-- Configuration des permissions pour le rôle gestion_production
INSERT IGNORE INTO `permissions` (`role_id`, `module`, `lecture`, `ecriture`, `suppression`) VALUES
(2, 'personnel', 1, 1, 1),
(2, 'evaluations', 1, 1, 1),
(2, 'polyvalence', 1, 1, 1),
(2, 'contrats', 1, 0, 0),
(2, 'documents_rh', 0, 0, 0),
(2, 'planning', 1, 0, 0),
(2, 'postes', 1, 1, 1),
(2, 'historique', 1, 0, 0),
(2, 'grilles', 1, 1, 1),
(2, 'gestion_utilisateurs', 0, 0, 0);

-- Configuration des permissions pour le rôle gestion_rh
INSERT IGNORE INTO `permissions` (`role_id`, `module`, `lecture`, `ecriture`, `suppression`) VALUES
(3, 'personnel', 1, 1, 1),
(3, 'evaluations', 0, 0, 0),
(3, 'polyvalence', 1, 0, 0),
(3, 'contrats', 1, 1, 1),
(3, 'documents_rh', 1, 1, 1),
(3, 'planning', 0, 0, 0),
(3, 'postes', 1, 0, 0),
(3, 'historique', 1, 0, 0),
(3, 'grilles', 0, 0, 0),
(3, 'gestion_utilisateurs', 0, 0, 0);

-- Création d'un utilisateur admin par défaut (IGNORE = ne crée pas si existe déjà)
-- Mot de passe par défaut: "admin123" (à changer lors de la première connexion)
-- Hash généré avec bcrypt
INSERT IGNORE INTO `utilisateurs` (`username`, `password_hash`, `nom`, `prenom`, `role_id`, `actif`) VALUES
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5yrOvnN6G/mFa', 'Administrateur', 'Système', 1, 1);

-- ============================================================================
-- 3. VÉRIFICATION DES COLONNES MANQUANTES DANS LA TABLE HISTORIQUE
-- ============================================================================

-- Ajouter les colonnes utilisateur et table_name/record_id si elles n'existent pas
-- Note: MySQL ne supporte pas "ADD COLUMN IF NOT EXISTS", donc on utilise une procédure

DELIMITER $$

CREATE PROCEDURE add_historique_columns()
BEGIN
    -- Vérifier et ajouter la colonne 'utilisateur'
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = 'emac_db'
        AND TABLE_NAME = 'historique'
        AND COLUMN_NAME = 'utilisateur'
    ) THEN
        ALTER TABLE `historique` ADD COLUMN `utilisateur` varchar(100) DEFAULT NULL AFTER `description`;
    END IF;

    -- Vérifier et ajouter la colonne 'table_name'
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = 'emac_db'
        AND TABLE_NAME = 'historique'
        AND COLUMN_NAME = 'table_name'
    ) THEN
        ALTER TABLE `historique` ADD COLUMN `table_name` varchar(100) DEFAULT NULL AFTER `utilisateur`;
    END IF;

    -- Vérifier et ajouter la colonne 'record_id'
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = 'emac_db'
        AND TABLE_NAME = 'historique'
        AND COLUMN_NAME = 'record_id'
    ) THEN
        ALTER TABLE `historique` ADD COLUMN `record_id` int DEFAULT NULL AFTER `table_name`;
    END IF;
END$$

DELIMITER ;

-- Exécuter la procédure
CALL add_historique_columns();

-- Supprimer la procédure après utilisation
DROP PROCEDURE IF EXISTS add_historique_columns;

-- ============================================================================
-- FIN DU SCRIPT
-- ============================================================================

SELECT 'Déploiement incrémental terminé avec succès!' as message;
SELECT 'Vérifiez que les nouvelles tables existent:' as info;
SHOW TABLES LIKE '%utilisateurs%';
SHOW TABLES LIKE '%roles%';
SHOW TABLES LIKE '%permissions%';
SHOW TABLES LIKE '%logs_connexion%';
