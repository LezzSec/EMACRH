-- =====================================================================
-- DIAGNOSTIC PERFORMANCE EMAC — emac_db (MariaDB)
-- Généré le 2026-02-26
-- Usage : Coller dans MySQL Workbench ou DBeaver sur la base emac_db
-- =====================================================================

USE emac_db;

-- =====================================================================
-- SECTION 1 : INDEX EXISTANTS SUR LES TABLES CRITIQUES
-- =====================================================================
-- Objectif : Vérifier que les index essentiels sont bien en place.
-- Résultat attendu : toutes les tables ci-dessous doivent avoir leurs
-- colonnes critiques indexées.

SELECT
    TABLE_NAME       AS `Table`,
    INDEX_NAME       AS `Index`,
    GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX SEPARATOR ', ') AS `Colonnes`,
    IF(NON_UNIQUE = 0, 'UNIQUE', 'Normal')  AS `Type`,
    INDEX_TYPE       AS `Méthode`
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'emac_db'
  AND TABLE_NAME IN ('personnel','polyvalence','contrat','historique','postes','utilisateurs','declaration','formation')
GROUP BY TABLE_NAME, INDEX_NAME, NON_UNIQUE, INDEX_TYPE
ORDER BY TABLE_NAME, INDEX_NAME;


-- =====================================================================
-- SECTION 2 : INDEX MANQUANTS — CRITIQUE
-- =====================================================================
-- Vérifie la présence de l'index composite (personnel_id, actif)
-- sur la table contrat, utilisé dans CHAQUE appel de get_paginated().
-- La requête : LEFT JOIN contrat ct ON ct.personnel_id = p.id AND ct.actif = 1
-- Sans cet index composite, MariaDB doit charger TOUTES les lignes
-- du personnel puis filtrer actif=1 en mémoire.

SELECT
    CASE
        WHEN COUNT(*) > 0 THEN '✅ OK — index composite (personnel_id, actif) PRÉSENT sur contrat'
        ELSE              '❌ MANQUANT — index composite (personnel_id, actif) sur contrat — AJOUTER (voir Section 6)'
    END AS `Diagnostic contrat(personnel_id, actif)`
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'emac_db'
  AND TABLE_NAME = 'contrat'
  AND INDEX_NAME IN (
      SELECT INDEX_NAME FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = 'emac_db'
        AND TABLE_NAME = 'contrat'
        AND COLUMN_NAME = 'personnel_id'
  )
  AND COLUMN_NAME = 'actif';


-- Vérifie l'index sur historique.utilisateur (filtre par utilisateur dans l'écran historique)
SELECT
    CASE
        WHEN COUNT(*) > 0 THEN '✅ OK — index (utilisateur) PRÉSENT sur historique'
        ELSE              '⚠️  ABSENT — index (utilisateur) sur historique (impact modéré si > 50k lignes)'
    END AS `Diagnostic historique(utilisateur)`
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'emac_db'
  AND TABLE_NAME   = 'historique'
  AND COLUMN_NAME  = 'utilisateur'
  AND SEQ_IN_INDEX = 1;


-- Vérifie l'index sur historique.table_name (filtre par type d'action)
SELECT
    CASE
        WHEN COUNT(*) > 0 THEN '✅ OK — index (table_name) PRÉSENT sur historique'
        ELSE              '⚠️  ABSENT — index (table_name) sur historique (filtre par module dans écran historique)'
    END AS `Diagnostic historique(table_name)`
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'emac_db'
  AND TABLE_NAME   = 'historique'
  AND COLUMN_NAME  = 'table_name'
  AND SEQ_IN_INDEX = 1;


-- =====================================================================
-- SECTION 3 : TAILLE ET VOLUME DES TABLES
-- =====================================================================
-- Permet d'anticiper les problèmes de performance au fil du temps.
-- Seuils d'alerte indicatifs :
--   personnel  > 5 000 lignes → get_paginated() commence à peser
--   polyvalence > 50 000 lignes → JOINs de la grille ralentissent
--   historique  > 100 000 lignes → filtre par date sans index = lent

SELECT
    t.TABLE_NAME                                  AS `Table`,
    t.TABLE_ROWS                                  AS `Lignes (estimé)`,
    ROUND((t.DATA_LENGTH) / 1024 / 1024, 2)       AS `Données (Mo)`,
    ROUND((t.INDEX_LENGTH) / 1024 / 1024, 2)      AS `Index (Mo)`,
    ROUND((t.DATA_LENGTH + t.INDEX_LENGTH) / 1024 / 1024, 2) AS `Total (Mo)`,
    CASE
        WHEN t.TABLE_NAME = 'personnel'   AND t.TABLE_ROWS > 5000   THEN '⚠️  Pagination critique'
        WHEN t.TABLE_NAME = 'polyvalence' AND t.TABLE_ROWS > 50000  THEN '⚠️  JOINs à surveiller'
        WHEN t.TABLE_NAME = 'historique'  AND t.TABLE_ROWS > 100000 THEN '⚠️  Archivage conseillé'
        WHEN t.TABLE_NAME = 'contrat'     AND t.TABLE_ROWS > 20000  THEN '⚠️  Nettoyage contrats inactifs'
        ELSE '✅ Volume OK'
    END AS `Alerte`
FROM information_schema.TABLES t
WHERE t.TABLE_SCHEMA = 'emac_db'
  AND t.TABLE_NAME IN ('personnel','polyvalence','contrat','historique','postes',
                       'formation','declaration','documents','historique_polyvalence')
ORDER BY (t.DATA_LENGTH + t.INDEX_LENGTH) DESC;


-- =====================================================================
-- SECTION 4 : EXPLAIN SUR LES REQUÊTES CRITIQUES
-- =====================================================================
-- Analyse le plan d'exécution des 3 requêtes les plus lourdes.
-- Colonnes à surveiller :
--   type = 'ALL'     → scan complet = PROBLÈME (sauf petites tables)
--   type = 'ref'     → utilise un index = BON
--   type = 'range'   → utilise un index avec plage = BON
--   rows             → nombre de lignes examinées (plus c'est bas, mieux c'est)
--   Extra = 'Using filesort' → tri en mémoire = peut être lent sur grands volumes
--   Extra = 'Using temporary' → table temporaire = souvent lent


-- 4a. Requête get_paginated() — Liste principale du personnel (page 1, 50 lignes)
SELECT '=== EXPLAIN : get_paginated() — Liste personnel ===' AS ``;

EXPLAIN
SELECT
    p.id, p.nom, p.prenom, p.matricule, p.numposte,
    UPPER(p.statut) AS statut,
    ct.type_contrat,
    COUNT(poly.id) AS nb_postes,
    SUM(CASE WHEN poly.niveau = 1 THEN 1 ELSE 0 END) AS n1,
    SUM(CASE WHEN poly.niveau = 2 THEN 1 ELSE 0 END) AS n2,
    SUM(CASE WHEN poly.niveau = 3 THEN 1 ELSE 0 END) AS n3,
    SUM(CASE WHEN poly.niveau = 4 THEN 1 ELSE 0 END) AS n4
FROM personnel p
LEFT JOIN polyvalence poly ON p.id = poly.operateur_id
LEFT JOIN contrat ct ON ct.personnel_id = p.id AND ct.actif = 1
WHERE p.statut = 'ACTIF'
GROUP BY p.id, p.nom, p.prenom, p.matricule, p.numposte, p.statut, ct.type_contrat
ORDER BY p.nom, p.prenom
LIMIT 50 OFFSET 0;


-- 4b. Requête get_en_retard() — Tableau de bord évaluations en retard
SELECT '=== EXPLAIN : get_en_retard() — Évaluations en retard ===' AS ``;

EXPLAIN
SELECT
    p.id AS polyvalence_id,
    p.operateur_id,
    pers.nom AS operateur_nom,
    pers.prenom AS operateur_prenom,
    pos.poste_code,
    p.niveau,
    p.prochaine_evaluation,
    DATEDIFF(CURDATE(), p.prochaine_evaluation) AS jours_retard
FROM polyvalence p
JOIN personnel pers ON p.operateur_id = pers.id
JOIN postes pos ON p.poste_id = pos.id
WHERE pers.statut = 'ACTIF'
  AND p.prochaine_evaluation < CURDATE()
ORDER BY jours_retard DESC
LIMIT 100;


-- 4c. Requête fetch_historique_paginated() — Écran historique (filtré par date)
SELECT '=== EXPLAIN : fetch_historique_paginated() — Historique ===' AS ``;

EXPLAIN
SELECT
    h.id, h.date_time, h.action, h.table_name, h.record_id,
    h.operateur_id, h.poste_id, h.description, h.utilisateur,
    CONCAT(p.prenom, ' ', p.nom) AS op_name,
    pos.poste_code AS po_name
FROM historique h
LEFT JOIN personnel p ON h.operateur_id = p.id
LEFT JOIN postes pos ON h.poste_id = pos.id
WHERE h.date_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
ORDER BY h.date_time DESC, h.id DESC
LIMIT 100 OFFSET 0;


-- 4d. Requête count pour get_paginated() — Comptage total (appelé à chaque page)
SELECT '=== EXPLAIN : count total personnel (appelé à chaque changement de page) ===' AS ``;

EXPLAIN
SELECT COUNT(DISTINCT p.id) AS total
FROM personnel p
WHERE p.statut = 'ACTIF';


-- =====================================================================
-- SECTION 5 : COMPTAGES RÉELS (pour calibrer les alertes)
-- =====================================================================

SELECT 'Comptages réels par table' AS ``;

SELECT 'personnel ACTIF'     AS `Entité`, COUNT(*) AS `Nombre` FROM personnel WHERE statut = 'ACTIF'
UNION ALL
SELECT 'personnel INACTIF',              COUNT(*) FROM personnel WHERE statut = 'INACTIF'
UNION ALL
SELECT 'polyvalence (total)',            COUNT(*) FROM polyvalence
UNION ALL
SELECT 'polyvalence en retard',          COUNT(*) FROM polyvalence WHERE prochaine_evaluation < CURDATE()
UNION ALL
SELECT 'contrat actif',                  COUNT(*) FROM contrat WHERE actif = 1
UNION ALL
SELECT 'contrat inactif',                COUNT(*) FROM contrat WHERE actif = 0
UNION ALL
SELECT 'historique (total)',             COUNT(*) FROM historique
UNION ALL
SELECT 'historique (30 derniers jours)', COUNT(*) FROM historique WHERE date_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
UNION ALL
SELECT 'postes visibles',                COUNT(*) FROM postes WHERE visible = 1
UNION ALL
SELECT 'formation (total)',              COUNT(*) FROM formation;


-- =====================================================================
-- SECTION 6 : CORRECTIFS À APPLIQUER SI NÉCESSAIRE
-- =====================================================================
-- Décommenter et exécuter uniquement les ALTER TABLE dont le diagnostic
-- (Section 2) a indiqué "MANQUANT" ou "ABSENT".


-- CORRECTIF A — Index composite (personnel_id, actif) sur contrat
-- Impact : accélère CHAQUE appel à get_paginated() (liste du personnel)
-- À appliquer si Section 2 indique ❌ MANQUANT
/*
ALTER TABLE contrat
    ADD INDEX idx_contrat_personnel_actif (personnel_id, actif);
*/


-- CORRECTIF B — Index sur historique.utilisateur
-- Impact : accélère le filtre "par utilisateur" dans l'écran historique
-- À appliquer si Section 2 indique ⚠️ ABSENT et historique > 50 000 lignes
/*
ALTER TABLE historique
    ADD INDEX idx_historique_utilisateur (utilisateur);
*/


-- CORRECTIF C — Index sur historique.table_name
-- Impact : accélère le filtre par module (ex: "afficher seulement les actions sur personnel")
-- À appliquer si Section 2 indique ⚠️ ABSENT et historique > 50 000 lignes
/*
ALTER TABLE historique
    ADD INDEX idx_historique_table_name (table_name);
*/


-- =====================================================================
-- FIN DU DIAGNOSTIC
-- =====================================================================
-- Interpréter les résultats :
--
-- Section 1 → Vérifier que les colonnes critiques ci-dessous sont indexées :
--   personnel   : statut, matricule, nom+prenom
--   polyvalence : operateur_id, poste_id, prochaine_evaluation, operateur_id+prochaine_evaluation
--   contrat     : personnel_id, actif (idéalement : personnel_id+actif ensemble)
--   historique  : date_time, action+date_time
--   postes      : poste_code, atelier_id
--
-- Section 4 → Si EXPLAIN montre type='ALL' sur une grande table :
--   → Un index manque → ajouter le correctif correspondant (Section 6)
--
-- Section 3 → Si une table dépasse son seuil d'alerte :
--   → Envisager une purge/archivage (historique > 100k)
--   → Ou un cache applicatif (polyvalence > 50k)
--
-- Section 6 → Correctifs prêts à décommenter si diagnostic négatif.
-- =====================================================================
